(() => {
  const modes = {walk: '步行', bus: '公車', taxi: '車行', rail: 'JR', subway: '地下鐵', tram: '市電', ropeway: '纜車'};
  const photoCatalog = {
    '二見吊橋': ['jozankei-woods.jpg', '豐平川上的紅色二見吊橋'],
    '札幌電視塔': ['d3-sapporo-tv-tower.webp', '札幌電視塔夜間點燈'],
    '二條市場': ['d3-nijo-market.webp', '二條市場街角的店面'],
    '北海道神宮': ['d4-hokkaido-shrine.webp', '北海道神宮拜殿'],
    '札幌伏見稻荷神社': ['d4-fushimi-inari.webp', '札幌伏見稻荷神社的鳥居步道'],
    '札幌伏見稻荷': ['d4-fushimi-inari.webp', '札幌伏見稻荷神社的鳥居步道'],
    '伏見稻荷鳥居入口': ['d4-fushimi-inari.webp', '札幌伏見稻荷神社的鳥居步道'],
    '札幌站': ['d4-sapporo-station.webp', 'JR 札幌站南口'],
    'JR 札幌站': ['d4-sapporo-station.webp', 'JR 札幌站南口'],
    '小樽水族館': ['d5-otaru-aquarium.webp', '小樽水族館的海獸公園與祝津海岸'],
    '海獸公園': ['d5-otaru-aquarium.webp', '小樽水族館的海獸公園與祝津海岸'],
    '日和山燈塔': ['d5-hiyoriyama.webp', '祝津海岬上的日和山燈塔'],
    '小樽運河・淺草橋': ['d5-otaru-canal.webp', '小樽運河夜色與河畔石造倉庫'],
    '藻岩山': ['moiwa.jpg', '從藻岩山山頂俯瞰札幌夜景'],
    '山頂展望台': ['moiwa.jpg', '從藻岩山山頂俯瞰札幌夜景'],
    '昭和新山': ['d6-showashinzan.jpg', '昭和新山的山體與山麓'],
  };
  const photoReferences = {
    '松尾成吉思汗・定山溪': ['https://jozankei.jp/store/matsuo-jingisukan/', '觀光協會店面照片'],
    'MEGA 唐吉訶德': ['https://www.flickr.com/photos/104519500@N03/53106330840/', '查看本店外觀照片'],
    '光之隧道': ['https://www.laketoya.com/event/illumination/', '官方光之隧道照片'],
  };
  const width = 450;
  const height = 420;
  const ink = '#355d4b';
  const paper = '#f5f2e9';
  const tileSize = 256;
  const sapporoBase = {
    src: 'maps/guide-sapporo-center.webp',
    bounds: [[43.04480541304369, 141.3336181640625], [43.072900581493215, 141.3720703125]],
  };
  // Pedestrian geometry from the OSM foot network, between Exit 3 and the Premier entrance.
  const parkWalk = {mode: 'walk', coords: [
    [141.355105,43.04783],[141.355015,43.047827],[141.355021,43.047759],
    [141.354996,43.047693],[141.35497,43.047571],[141.354952,43.047559],
    [141.354961,43.047499],[141.354975,43.047459],[141.35494,43.047418],
    [141.354921,43.047455],[141.354875,43.047469],[141.354875,43.047375],
    [141.354773,43.047371],[141.354782,43.047338],[141.354757,43.047316],
    [141.354721,43.047316],[141.354742,43.047202],[141.354714,43.047194],
    [141.354597,43.047184],[141.354372,43.047165],[141.354032,43.047154],
    [141.35367,43.047082],[141.353565,43.047079],[141.353466,43.047102],
    [141.353377,43.047167],[141.353183,43.047285],[141.353025,43.047376],
    [141.352895,43.047467],[141.352465,43.047812],[141.35194,43.047921],
    [141.351914,43.047783],[141.351894,43.047652],
  ]};
  const premier = {label:'Premier 中島公園', position:[43.04765,141.35192]};
  const tiles = new Map();
  const localBases = new Map();
  const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;'})[char]);

  function loadTile(zoom, x, y) {
    const url = `https://cyberjapandata.gsi.go.jp/xyz/pale/${zoom}/${x}/${y}.png`;
    if (!tiles.has(url)) {
      const image = new Image();
      image.crossOrigin = 'anonymous';
      image.src = url;
      let timeout;
      const ready = Promise.race([
        image.decode().then(() => image, () => null),
        new Promise(resolve => { timeout = setTimeout(() => resolve(null), 1150); }),
      ]).then(tile => {
        clearTimeout(timeout);
        if (!tile) tiles.delete(url);
        return tile;
      });
      if (tiles.size >= 72) tiles.delete(tiles.keys().next().value);
      tiles.set(url, ready);
    }
    return tiles.get(url);
  }

  function mapImageUrl(canvas, quality) {
    return new Promise(resolve => canvas.toBlob(blob => {
      if (!blob) {
        resolve(undefined);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => resolve(undefined);
      reader.readAsDataURL(blob);
    }, 'image/webp', quality));
  }

  async function basemap({zoom, corner, point}, fallback) {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d');
    context.filter = 'saturate(.42) contrast(.82)';
    async function drawLocal(base, requireCoverage = false) {
      if (!base?.src || !base.bounds) return false;
      const [southWest, northEast] = base.bounds.map(position => window.L.latLng(position));
      const [left, top] = point([northEast.lat, southWest.lng]);
      const [right, bottom] = point([southWest.lat, northEast.lng]);
      if (requireCoverage && (left > 0 || top > 0 || right < width || bottom < height)) return false;
      if (!localBases.has(base.src)) {
        const image = new Image();
        image.src = base.src;
        localBases.set(base.src, image.decode().then(() => image, () => null));
      }
      const image = await localBases.get(base.src);
      if (!image) return false;
      context.drawImage(image, left, top, right - left, bottom - top);
      return true;
    }
    if (!(await drawLocal(sapporoBase, true))) {
      const tileRequests = [];
      for (let x = Math.floor(corner.x / tileSize); x * tileSize < corner.x + width; x++) {
        for (let y = Math.floor(corner.y / tileSize); y * tileSize < corner.y + height; y++) {
          tileRequests.push(loadTile(zoom, x, y).then(tile => {
            if (tile) context.drawImage(tile, x * tileSize - corner.x, y * tileSize - corner.y);
            return tile;
          }));
        }
      }
      if (!(await Promise.all(tileRequests)).some(Boolean) && !(await drawLocal(fallback))) return {};
    }
    try {
      const paper = mapImageUrl(canvas, .78);
      const image = context.getImageData(0, 0, width, height);
      for (let i = 0; i < image.data.length; i += 4) {
        const luma = .21 * image.data[i] + .72 * image.data[i + 1] + .07 * image.data[i + 2];
        image.data[i + 3] *= Math.max(0, Math.min(.78, (227 - luma) / 173));
        image.data[i] = 211;
        image.data[i + 1] = 223;
        image.data[i + 2] = 206;
      }
      context.putImageData(image, 0, 0);
      const [paperImage, inkImage] = await Promise.all([paper, mapImageUrl(canvas, .83)]);
      return {paperImage, inkImage};
    } catch { return {}; }
  }

  function closestRoute(routes, position) {
    const origin = window.L.latLng(position);
    let nearest;
    for (const route of routes) {
      const points = route.coords.map(([lng, lat]) => window.L.CRS.EPSG3857.project(window.L.latLng(lat, lng)));
      const start = window.L.CRS.EPSG3857.project(origin);
      for (let index = 1; index < points.length; index++) {
        const distance = window.L.LineUtil.pointToSegmentDistance(start, points[index - 1], points[index]);
        if (!nearest || distance < nearest.distance) nearest = {route, distance};
      }
    }
    return nearest?.distance < 260 ? nearest.route : null;
  }

  async function routeImage(position, pin, points, routes, active, target, fallback) {
    const L = window.L;
    const origin = L.latLng(position);
    const other = target && L.latLng(target.position);
    const distance = other ? origin.distanceTo(other) : 0;
    const groundScale = 156543.034 * Math.cos(origin.lat * Math.PI / 180);
    const zoom = Math.max(7, Math.min(17, Math.floor(Math.log2(groundScale * 270 / Math.max(230, distance)))));
    const world = coordinates => L.CRS.EPSG3857.latLngToPoint(L.latLng(coordinates), zoom);
    const center = other ? world(origin).add(world(other)).divideBy(2) : world(origin);
    const corner = center.subtract([width / 2, height / 2]).round();
    const point = coordinates => {
      const pixel = world(coordinates).subtract(corner);
      return [pixel.x.toFixed(1), pixel.y.toFixed(1)].map(Number);
    };
    const bases = await basemap({zoom, corner, point}, fallback);
    const paths = routes.map(route => {
      const d = route.coords.map(([lng, lat], index) => `${index ? 'L' : 'M'}${point([lat, lng]).join(' ')}`).join('');
      const dash = route.mode === 'walk' ? '1.5 4.4' : /^(rail|subway|tram|ropeway)$/.test(route.mode) ? '6 4' : '';
      return {d, dash, focus:route===active};
    }).sort((a,b) => Number(a.focus)-Number(b.focus));
    const [x, y] = point(position);
    const putOriginBelow = target && Math.abs(point(target.position)[1] - y) < 58;
    const visible = (target ? [target] : points).filter(other => other.label !== pin.label).flatMap(other => {
      const [left, top] = point(other.position);
      if (left < 22 || left > width - 22 || top < 22 || top > height - 22 || Math.hypot(left - x, top - y) < 23) return [];
      return [{left,top,label:other===target ? other.label : null}];
    });
    function render(background, dark = false) {
      const routeInk = dark ? '#b4d0b5' : ink;
      const labelInk = dark ? '#fbf8ed' : ink;
      const outline = dark ? '#324f3d' : paper;
      const lines = paths.map(({d,dash,focus}) => `<path d="${d}" fill="none" stroke="${routeInk}" opacity="${focus ? '.96' : '.49'}" stroke-width="${focus ? '2.6' : '1.65'}" stroke-dasharray="${dash}" stroke-linecap="round" stroke-linejoin="round"/>`).join('');
      const labels = visible.map(({left,top,label}) => `<circle cx="${left}" cy="${top}" r="3.8" fill="${routeInk}"/>` +
        (label ? mapLabel(left,top,label,labelInk,outline) : '')).join('');
      const map = background ? `<image width="${width}" height="${height}" href="${background}" mask="url(#edge)" opacity="${dark ? '.86' : '.76'}"/>` : '';
      const field = dark ? '' : `<rect width="100%" height="100%" fill="${paper}"/>`;
      const markup = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><defs><radialGradient id="fade"><stop offset=".52" stop-color="white"/><stop offset="1" stop-color="white" stop-opacity="0"/></radialGradient><mask id="edge"><rect width="100%" height="100%" fill="url(#fade)"/></mask></defs>${field}${map}${lines}${labels}<circle cx="${x}" cy="${y}" r="11" fill="${routeInk}" opacity=".15"/><circle cx="${x}" cy="${y}" r="5" fill="${routeInk}" stroke="${outline}" stroke-width="1.5"/>${mapLabel(x,y,pin.label,labelInk,outline,putOriginBelow)}</svg>`;
      return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(markup);
    }
    return {routeSrc:render(bases.paperImage), routeInkSrc:render(bases.inkImage,true)};
  }

  function mapLabel(x, y, label, color, outline, below = false) {
    const characters = [...label];
    const text = characters.length > 15 ? characters.slice(0, 14).join('') + '…' : label;
    const anchor = x < width / 3 ? 'start' : x > width * 2 / 3 ? 'end' : 'middle';
    return `<text x="${x}" y="${below || y <= 36 ? y + 29 : y - 17}" text-anchor="${anchor}" font-size="25" font-family="'Noto Serif TC', 'Microsoft JhengHei', serif" fill="${color}" stroke="${outline}" stroke-width="5" paint-order="stroke">${escape(text)}</text>`;
  }

  const isPhoto = path => typeof path === 'string' && !path.startsWith('data:');

  window.folioGuideSlides = (pin, context = {}) => {
    const {day, points = [], routes = [], routeEntry, detailKey, image} = context;
    const configurations = window.folioExtraDetails;
    const entryId = pin.entry ?? routeEntry;
    const configured = configurations?.get(detailKey) ?? configurations?.get(entryId)
      ?? (configurations && [...configurations.values()].find(config => config.entry.id === entryId));
    const exact = window.folioGuideNotes?.[pin.label] ?? [];
    const notes = window.folioEntryNotes?.[detailKey ?? configured?.entry.id ?? entryId];
    const facts = [...(notes?.facts ?? []), ...(notes?.moreFacts ?? [])];
    const relevant = facts.find(([title, text]) => title.includes(pin.label) || text.includes(pin.label));
    const routeSet = routes.length ? routes : (window.folioRoutes?.[day] ?? []).filter(route => route.entry === entryId);
    const closest = closestRoute(routeSet, pin.position);
    const origin = window.L.latLng(pin.position);
    const nearby = points.map(point => ({point, distance: origin.distanceTo(point.position)}))
      .filter(({point, distance}) => point.label !== pin.label && distance > 20 && distance < 3200)
      .sort((a, b) => a.distance - b.distance);
    const next = nearby[0]?.point;
    const shortRoute = closest && (closest.label ?? modes[closest.mode]);
    const lookup = pin.query ?? pin.label;
    const action = relevant?.[1] ?? configured?.entry.text;
    const overview = [
      {title: '位置與地標', text: lookup !== pin.label ? `找現場標示「${lookup}」，並用旁邊的地圖核對位置。` : `地圖墨綠色圓點標示${pin.label}。`},
      {title: closest ? '沿路抵達' : '到達後怎麼走', text: closest ? `圖中加強標示的路線是「${shortRoute}」。${action ?? ''}` : action ?? `到附近後，找「${lookup}」的招牌或站名。`},
      {title: next ? '附近行程地點' : '行程備忘', text: next ? `地圖也標示了同段行程的「${next.label}」，方便核對兩處的相對位置。` : (facts.find(fact => fact !== relevant)?.[1] ?? action ?? `離開時可用「${lookup}」作為導航起點。`)},
    ];
    const catalog = photoCatalog[pin.label];
    const namedPhoto = catalog ? [{image: 'photos/' + catalog[0], alt: catalog[1]}] : [];
    const used = new Set(exact.filter(note => isPhoto(note.image)).map(note => note.image));
    const alternatives = [window.folioVenueGuidePhotos, window.folioMoreGuidePhotos, window.folioGuidePhotos]
      .flatMap(collection => collection?.[pin.label] ?? []).concat(namedPhoto).filter(photo => {
        if (used.has(photo.image)) return false;
        used.add(photo.image);
        return true;
      });
    const available = exact.find(note => isPhoto(note.image)) ?? alternatives[0];
    const reference = !available && photoReferences[pin.label];
    return overview.map((fallback, index) => {
      const note = exact[index] ?? fallback;
      const matched = isPhoto(note.image) ? note : alternatives.shift();
      const photo = matched ?? available;
      const focus = note.position ?? pin.position;
      const useParkWalk = note.target === premier.label && note.position;
      const routeTarget = useParkWalk ? premier : note.target ? points.find(point => point.label === note.target) : index > 0 ? next : null;
      const from = useParkWalk ? {...pin, label:'中島公園站 3 號出口'} : pin;
      const loadRoute = () => routeImage(focus, from, points, useParkWalk ? [parkWalk] : routeSet,
        useParkWalk ? parkWalk : index === 0 ? null : closest, routeTarget, image);
      return {src: photo?.image, alt: photo?.alt, photoSource: photo?.photoSource, photoCredit: photo?.photoCredit,
        photoLicense: photo?.photoLicense, loadRoute, routeAlt: routeTarget ? `${from.label}與${routeTarget.label}的地圖` : `${from.label}的位置地圖`,
        title: exact[index]?.title ?? matched?.guideTitle ?? note.title,
        text: exact[index]?.text ?? matched?.guideText ?? note.text,
        source: note.source ?? reference?.[0], sourceLabel: note.source ? note.sourceLabel : reference?.[1]};
    });
  };
})();
