(() => {
  const tileUrl = 'https://cyberjapandata.gsi.go.jp/xyz/pale/{z}/{x}/{y}.png';
  const ink = '#527360';
  const activeInk = '#315d46';
  const minimumZoom = 6;
  const maximumZoom = 18;
  const travelModes = {
    walk: {label: '步行', dash: '1 5'},
    bus: {label: '公車'},
    taxi: {label: '計程車'},
    rail: {label: 'JR', dash: '7 4'},
    subway: {label: '地下鐵', dash: '7 4'},
    tram: {label: '市電', dash: '7 4'},
    ropeway: {label: '纜車', dash: '7 4'},
  };
  const directions = [[1, -1], [-1, -1], [1, 1], [-1, 1], [0, -1], [0, 1], [1, 0], [-1, 0]];
  const pinSize = 30;
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');

  window.folioTileLegend = (container, routes) => {
    const used = new Set(routes.map(route => route.mode));
    const groups = new Map();
    for (const [mode, {label, dash = ''}] of Object.entries(travelModes)) {
      if (!used.has(mode)) continue;
      if (!groups.has(dash)) groups.set(dash, []);
      groups.get(dash).push(label);
    }
    container.replaceChildren(...[...groups].map(([dash, labels]) => {
      const key = document.createElement('span');
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('viewBox', '0 0 23 6');
      svg.setAttribute('aria-hidden', 'true');
      const line = document.createElementNS(svg.namespaceURI, 'path');
      line.setAttribute('d', 'M1 3H22');
      line.setAttribute('stroke', ink);
      line.setAttribute('stroke-width', '1.5');
      line.setAttribute('stroke-linecap', 'round');
      if (dash) line.setAttribute('stroke-dasharray', dash);
      svg.append(line);
      key.append(svg, labels.join('・'));
      return key;
    }));
    container.hidden = groups.size === 0;
  };

  const overlaps = (first, second) => first.left < second.right && first.right > second.left
    && first.top < second.bottom && first.bottom > second.top;
  const contains = (box, area) => box.left >= area.left && box.right <= area.right
    && box.top >= area.top && box.bottom <= area.bottom;

  function crosses(box, [from, to]) {
    if (!overlaps(box, {left: Math.min(from.x, to.x), right: Math.max(from.x, to.x),
      top: Math.min(from.y, to.y), bottom: Math.max(from.y, to.y)})) return false;
    const halfWidth = (box.right - box.left) / 2;
    const halfHeight = (box.bottom - box.top) / 2;
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const x = box.left + halfWidth - from.x;
    const y = box.top + halfHeight - from.y;
    return Math.abs(dx * y - dy * x) <= Math.abs(dy) * halfWidth + Math.abs(dx) * halfHeight;
  }

  window.createFolioTileMap = (container, {inline = false, onSelect = () => {}, onView = () => {}} = {}) => {
    const L = window.L;
    const map = L.map(container, {
      zoomControl: false,
      attributionControl: false,
      minZoom: minimumZoom,
      maxZoom: maximumZoom,
      zoomSnap: .5,
      zoomDelta: 1,
      dragging: !inline,
      scrollWheelZoom: !inline,
      doubleClickZoom: !inline,
      touchZoom: true,
      boxZoom: !inline,
      zoomAnimation: !reduceMotion.matches,
      zoomAnimationThreshold: maximumZoom - minimumZoom,
      fadeAnimation: !reduceMotion.matches,
      markerZoomAnimation: !reduceMotion.matches,
    });
    const fallbackPane = map.createPane('folioFallback');
    fallbackPane.style.zIndex = '195';
    fallbackPane.style.pointerEvents = 'none';
    const fallback = L.layerGroup().addTo(map);
    const routes = L.layerGroup().addTo(map);
    const pins = L.layerGroup().addTo(map);
    const tiles = L.tileLayer(tileUrl, {
      maxNativeZoom: maximumZoom,
      noWrap: true,
      keepBuffer: 2,
      updateWhenZooming: false,
      className: 'folio-gsi-tiles',
    });
    let availableTile = false;
    let zooming = false;
    let tileFailed = false;
    function settleBasemap() {
      if (zooming || tiles.isLoading()) return;
      container.classList.remove('is-changing-scale');
      fallbackPane.classList.toggle('is-replaced', availableTile && !tileFailed);
    }
    tiles.on('loading', () => {
      availableTile = false;
      tileFailed = false;
    });
    tiles.on('tileload', () => { availableTile = true; });
    tiles.on('tileerror', () => { tileFailed = true; });
    tiles.on('load', settleBasemap);
    tiles.addTo(map);
    let active;
    let initialBounds;
    let routeLayers = [];
    let markers = [];
    let placementFrame = 0;
    let viewFrame = 0;
    let viewRequest;

    function fit(animate = false) {
      if (!initialBounds?.isValid()) return;
      const padding = inline ? [30, 34] : [50, 60];
      const smooth = animate && !reduceMotion.matches;
      map.stop();
      if (smooth) container.classList.add('is-changing-scale');
      map.fitBounds(initialBounds, {padding, maxZoom: 17, animate: smooth, duration: .45});
    }

    function scheduleView() {
      if (viewFrame || zooming || !viewRequest) return;
      viewFrame = requestAnimationFrame(() => {
        viewFrame = 0;
        if (zooming || !viewRequest) return;
        const request = viewRequest;
        viewRequest = undefined;
        if (request.reset) fit(true);
        else map.setZoom(request.zoom, {animate: !reduceMotion.matches});
      });
    }

    function select(point, {center = false, notify = true, trigger} = {}) {
      if (active !== point.id) {
        active = point.id;
        markSelection();
        schedulePins();
      }
      if (center) {
        const padding = inline ? [24, 24] : [48, 42];
        map.panInside(point.position, {padding, animate: !reduceMotion.matches});
      }
      if (notify) onSelect(point, trigger);
    }

    function paintRouteSelection(entry, point) {
      const hasEntry = entry && routeLayers.some(({route}) => route.entry === entry);
      for (const {route, line} of routeLayers) {
        const selected = hasEntry ? route.entry === entry : route.point === point;
        line.setStyle({color: selected ? activeInk : ink, opacity: selected ? .9 : .58, weight: selected ? 2.35 : 1.5});
        if (selected) line.bringToFront();
      }
    }

    function markSelection() {
      for (const {point, marker} of markers) {
        const selected = point.id === active;
        const icon = marker.getElement();
        icon.classList.toggle('is-active', selected);
        icon.setAttribute('aria-pressed', String(selected));
        marker.setZIndexOffset(selected ? 1000 : 0);
      }
    }

    function addPin(point) {
      const content = document.createElement('span');
      content.setAttribute('aria-hidden', 'true');
      const hit = document.createElement('span');
      hit.className = 'folio-tile-pin-hit';
      const label = document.createElement('span');
      label.className = 'folio-tile-pin-label';
      label.textContent = point.label;
      content.append(hit, label);
      const marker = L.marker(point.position, {
        icon: L.divIcon({
          className: 'folio-tile-pin',
          iconSize: [pinSize, pinSize],
          iconAnchor: [pinSize / 2, pinSize / 2],
          html: content,
        }),
        title: point.label,
        keyboard: true,
      }).addTo(pins);
      const icon = marker.getElement();
      icon.dataset.pinId = point.id;
      icon.setAttribute('aria-label', point.label);
      icon.setAttribute('aria-haspopup', 'dialog');
      marker.on('click', () => select(point, {trigger: icon}));
      return {point, marker, label};
    }

    function placePins() {
      const size = map.getSize();
      if (!size.x || !size.y) return;
      const controls = inline
        ? [{left: size.x - 43, right: size.x, top: size.y - 43, bottom: size.y}]
        : container.closest('dialog')?.dataset.mode === 'overview'
          ? [{left: 0, right: size.x, top: size.y - 86, bottom: size.y}] : [];
      const segments = routeLayers.flatMap(({latLngs}) => {
        const positions = latLngs.map(latLng => map.latLngToContainerPoint(latLng));
        return positions.slice(1).map((position, index) => [positions[index], position]);
      });
      const priority = (a, b) => Number(b.point.id === active) - Number(a.point.id === active);
      const positioned = markers.map(pin => {
        pin.marker.getElement().classList.remove('is-labeled');
        return {...pin, pixel: map.latLngToContainerPoint(pin.point.position)};
      }).filter(({pixel: {x, y}}) => x >= 0 && y >= 0 && x <= size.x && y <= size.y).sort(priority);
      // Sharing a screen pixel only shares the dot. Each place still has its own label and keyboard target.
      const distances = (a, b) => Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));
      positioned.forEach((pin, index) => {
        const {marker, pixel} = pin;
        const otherDistances = positioned.map(other => distances(pixel, other.pixel));
        const duplicate = otherDistances.slice(0, index).includes(0);
        pin.hitSize = duplicate ? 0 : Math.min(pinSize, ...otherDistances.filter(distance => distance > 0));
        marker.getElement().style.setProperty('--pin-hit-size', `${pin.hitSize}px`);
      });
      placeLabels(positioned, segments, size, controls);
    }

    function placeLabels(positioned, segments, size, controls) {
      const occupied = positioned.map(({pixel: {x, y}, hitSize}) => {
        const half = Math.max(5, hitSize / 2);
        return {left: x - half, right: x + half, top: y - half, bottom: y + half};
      });
      occupied.push(...controls);
      const area = {left: 5, right: size.x - 5, top: 5, bottom: size.y - 5};
      for (const {pixel, marker, label} of positioned) {
        const width = label.offsetWidth;
        const height = label.offsetHeight;
        let placement;
        for (const gap of [18, 28, 40, 54, 70]) {
          for (const [dx, dy] of directions) {
            const x = dx ? dx * (gap + width / 2) - width / 2 : -width / 2;
            const y = dy ? dy * (gap + height / 2) - height / 2 : -height / 2;
            const box = {left: pixel.x + x - 2, right: pixel.x + x + width + 2,
              top: pixel.y + y - 2, bottom: pixel.y + y + height + 2};
            if (!contains(box, area) || occupied.some(other => overlaps(box, other))
              || segments.some(segment => crosses(box, segment))) continue;
            placement = {x, y, box};
            break;
          }
          if (placement) break;
        }
        if (!placement) continue;
        occupied.push(placement.box);
        label.style.setProperty('--pin-label-x', `${placement.x}px`);
        label.style.setProperty('--pin-label-y', `${placement.y}px`);
        marker.getElement().classList.add('is-labeled');
      }
    }

    function schedulePins() {
      if (placementFrame) return;
      placementFrame = requestAnimationFrame(() => {
        placementFrame = 0;
        if (initialBounds?.isValid() && container.clientWidth && container.clientHeight) placePins();
      });
    }

    function setData({points: nextPoints, routes: nextRoutes = [], active: nextActive,
      entry, point, bounds, image}) {
      viewRequest = undefined;
      routes.clearLayers();
      pins.clearLayers();
      fallback.clearLayers();
      active = nextActive;
      initialBounds = L.latLngBounds(bounds ?? nextPoints.map(item => item.position));
      if (image) L.imageOverlay(image.src, image.bounds, {pane: 'folioFallback', opacity: .8}).addTo(fallback);
      routeLayers = nextRoutes.map(route => {
        const latLngs = route.coords.map(([longitude, latitude]) => [latitude, longitude]);
        if (!bounds) initialBounds.extend(latLngs);
        const line = L.polyline(latLngs, {
          interactive: false, lineCap: 'round', lineJoin: 'round', dashArray: travelModes[route.mode]?.dash,
        }).addTo(routes);
        return {route, line, latLngs};
      });
      paintRouteSelection(entry, point);
      map.invalidateSize({pan: false});
      fit();
      markers = nextPoints.map(addPin);
      markSelection();
      placePins();
      onView(map);
    }

    const resize = new ResizeObserver(() => {
      if (container.clientWidth && container.clientHeight && initialBounds?.isValid()) {
        map.invalidateSize({pan: false, debounceMoveend: true});
      }
    });
    resize.observe(container);
    function tuneBasemap() {
      const zoom = map.getZoom();
      container.classList.toggle('is-dense', zoom >= 15);
      container.classList.toggle('is-close', zoom >= 17);
    }
    map.whenReady(() => {
      tuneBasemap();
      map.on('zoomstart', () => {
        zooming = true;
        container.classList.add('is-changing-scale');
      });
      map.on('zoomend', () => {
        zooming = false;
        tuneBasemap();
        settleBasemap();
        scheduleView();
      });
      map.on('moveend zoomend', () => {
        if (initialBounds?.isValid()) {
          settleBasemap();
          schedulePins();
          onView(map);
        }
      });
    });

    return {
      setData, select, paintRouteSelection,
      reset() {
        viewRequest = {reset: true};
        scheduleView();
      },
      zoom(delta) {
        const zoom = (viewRequest?.zoom ?? map.getZoom()) + delta;
        viewRequest = {zoom: Math.min(maximumZoom, Math.max(minimumZoom, zoom))};
        scheduleView();
      },
      get zoomLevel() { return map.getZoom(); },
      minimumZoom, maximumZoom,
    };
  };
})();
