(() => {
  function photo(asset, alt, file, author, year, photoLicense) {
    return {
      image: `photos/guides/${asset}.webp`, alt,
      photoSource: 'https://commons.wikimedia.org/wiki/File:' + encodeURIComponent(file.replaceAll(' ', '_')),
      photoCredit: `${author} · ${year} · ${photoLicense} · 網頁縮圖`,
      photoLicense,
    };
  }

  const otaruStation = [
    photo('otaru-station', 'JR 小樽站面向站前廣場的正面外觀',
      'Otaru Station 20220626.jpg', '皓月旗', 2022, 'CC BY-SA 4.0'),
  ];
  const marketFile = '三角市場, 小樽, 北海道, 日本, Otaru, Hokkaido, Japan, おたるし, ほっかいどう, にっぽん, にほん';
  window.folioGuidePhotos = {
    'JR 小樽站': otaruStation,
    '小樽站': otaruStation,
    '小樽站前 3 號月台': [
      photo('otaru-bus', '2007 年的小樽站前巴士總站與站前廣場全景',
        '小樽駅前ターミナル.jpg', 'Masanori2000', 2007, 'CC BY-SA 3.0'),
    ],
    '三角市場': [
      photo('otaru-market', '小樽三角市場一側的紅字入口招牌',
        `${marketFile} (47026026894).jpg`, 'bryan...', 2019, 'CC BY-SA 2.0'),
      photo('otaru-market3', '三角市場通道內的海鮮攤與店家招牌',
        `${marketFile} (47026025304).jpg`, 'bryan...', 2019, 'CC BY-SA 2.0'),
    ],
    '祝津全景展望台': [
      photo('otaru-shukutsu-view', '從祝津全景展望台眺望日和山燈塔、海岬與下方港灣',
        'Shukutsu,Otaru 20220626 P2.jpg', '皓月旗', 2022, 'CC BY-SA 4.0'),
    ],
    '小樽運河・中央橋': [
      photo('otaru-chuo-bridge', '從小樽運河中央橋向南看的運河步道與石造倉庫',
        'Otaru Canal Center.jpg', 'Komatta', 2009, '公有領域'),
      photo('otaru-chuo-twilight', '中央橋一帶入夜後的運河與點燈倉庫',
        'Twilight in Otaru - panoramio.jpg', 'Xingpichi', 2010, 'CC BY-SA 3.0'),
    ],
    'JR 洞爺站': [
      photo('toya-station', '室蘭本線 JR 洞爺站的站房與站前道路',
        'JR Muroran-Main-Line Toya Station building.jpg', 'Mister0124', 2018, 'CC BY-SA 4.0'),
      photo('toya-station-platform', 'JR 洞爺站室蘭本線月台與軌道',
        'JR Muroran-Main-Line Tōya Station Platform.jpg', 'Mister0124', 2017, 'CC BY-SA 4.0'),
    ],
    '洞爺湖溫泉巴士總站': [
      photo('toya-terminal', '洞爺湖溫泉巴士總站與觀光資訊中心的白色站房',
        'Toya 20210811125140 (51822438158).jpg', 'inunami', 2021, 'CC BY 2.0'),
      photo('toya-terminal2', '從道路側看到的洞爺湖溫泉巴士總站與高塔',
        '130922 Toyako Onsen Toyako Hokkaido Japan08s5.jpg', '663highland', 2013, 'CC BY 2.5'),
    ],
    '若狹芋本店': [
      photo('toya-wakasaimo', '2007 年洞爺湖畔若狹芋本店的外牆招牌與紅色雨棚',
        'Wakasaimo-honpo.jpg', '橄欖岩', 2007, 'CC BY-SA 3.0'),
      photo('toya-wakasaimo-sign', '2007 年在洞爺湖溫泉街拍攝的若狹芋本店紅色招牌',
        'わかさいも看板 洞爺湖温泉 Sep 27, 2007.jpg', 'Jun OHWADA', 2007, 'CC BY 2.0'),
    ],
    '有珠山纜車山麓站': [
      photo('toya-usuzan-base', '2009 年有珠山纜車山麓站的建築與外部階梯',
        'Usuzan Ropeway Sanroku Station.jpg', 'Miyuki Meinaka', 2009, '公有領域'),
    ],
    '有珠山纜車山頂站': [
      photo('toya-usuzan-top', '2009 年有珠山纜車山頂站入口與日文招牌',
        'Usuzan Ropeway Sancho Station.jpg', 'Miyuki Meinaka', 2009, '公有領域'),
    ],
    '火口原展望台': [
      photo('toya-usu-crater', '2013 年從火口原展望台附近拍攝的有珠山火口全景',
        '130922 Mount Usu Sobetsu Hokkaido Japan09bs5.jpg', '663highland', 2013, 'CC BY 2.5'),
      photo('toya-usu-crater-approach', '2013 年從火口原展望台一帶看到的有珠山山稜',
        '130922 Mount Usu Sobetsu Hokkaido Japan08s.jpg', '663highland', 2013, 'CC BY 2.5'),
    ],
    '洞爺湖萬世閣': [
      photo('toya-manseikaku', '由湖畔花園望向洞爺湖萬世閣飯店',
        'Toyako Manseikaku.jpg', 'Totti', 2022, 'CC0 1.0'),
    ],
    '牛助 Gyusuke': [{
      image: 'photos/guides/toya-gyusuke-street.webp',
      alt: '從洞爺湖溫泉街辨認牛助店面：紅色三角屋頂、牛圖案與「牛助」招牌',
      photoSource: 'https://panoramax.osm.tw/?pic=715ed3e8-0451-49a8-bf7b-01fd76158651',
      photoCredit: 'Irvin Chen／Panoramax · 2026-03-30 · CC BY-SA 4.0 · 裁切',
      photoLicense: 'CC BY-SA 4.0',
    }],
  };
})();
