(() => {
  function photo(asset, alt, photoSource, photoCredit, photoLicense) {
    return {image: `photos/guides/${asset}.webp`, alt, photoSource, photoCredit, photoLicense};
  }

  window.folioMoreGuidePhotos = {
    'Kappa Liner 薄野站': [
      photo('wayfinding-kappa-cocono', '薄野上車點所在街廓的 COCONO SUSUKINO。沿國道 36 號在同側找往定山溪的 1 號站牌。', 'https://commons.wikimedia.org/wiki/File:COCONO_SUSUKINO.jpg', '禁樹なずな · 2023 · CC BY-SA 4.0 · 縮放轉 WebP', 'https://creativecommons.org/licenses/by-sa/4.0/'),
      photo('wayfinding-kappa-rei', '札幌東急 REI 飯店是薄野 1 號站牌西側的路口地標，照片拍攝於 2016 年。', 'https://commons.wikimedia.org/wiki/File:Sapporo_Tokyu_REI_Hotel.JPG', 'Abasaa · 2016 · 公有領域 · 縮放轉 WebP', ''),
    ],
    '白絲瀑布站・札幌方向': [
      photo('wayfinding-shiraito-street', '國道 230 號白絲瀑布站實拍。左側可見往定山溪方向的站牌，往札幌要到道路對側辨認標柱 2。', 'https://api.panoramax.xyz/api/collections/a2904603-5021-460d-965a-217f807e1135/items/f479a05d-e2d5-4b19-a3a5-b98bd09c3202', 'Irvin Chen / Panoramax · 2026-03-27 · CC BY-SA 4.0 · 縮放轉 WebP', 'https://creativecommons.org/licenses/by-sa/4.0/'),
    ],
    '札幌站前': [
      photo('wayfinding-chikaho', '札幌站前地下步行空間的北端出入口。沿地下通道走到北 3 條交會處，依 HULIC SQUARE 標示進入相連的地下一樓。', 'https://commons.wikimedia.org/wiki/File:Sapporo_Underground_Pedestrian_Space_Station_Road(Entrance).JPG', 'Chuoterminal 02 · CC BY 3.0 · 縮放轉 WebP', 'https://creativecommons.org/licenses/by/3.0/'),
    ],
    '洞爺站前巴士站': [
      photo('toya-station-front', 'JR 洞爺站出口及站前廣場。轉道南巴士時在廣場核對「洞爺駅前」站牌。', 'https://commons.wikimedia.org/wiki/File:JR_Muroran-Main-Line_Toya_Station_building.jpg', 'Mister0124 · 2018 · CC BY-SA 4.0 · 縮放轉 WebP', 'https://creativecommons.org/licenses/by-sa/4.0/'),
    ],
    'Seicomart 定山溪溫泉店': [
      photo('wayfinding-seicomart-street', 'Seicomart 定山溪溫泉店在照片左側，可辨認紅色高招牌與停車場後方紅白店面。', 'https://api.panoramax.xyz/api/collections/a2904603-5021-460d-965a-217f807e1135/items/94d1b610-9fac-4041-b0ef-95af0dd451b0', 'Irvin Chen / Panoramax · 2026-03-27 · CC BY-SA 4.0 · 縮放轉 WebP', 'https://creativecommons.org/licenses/by-sa/4.0/'),
    ],
    "榆樹之森遊客中心": [
      photo("hokudai-main-gate", "北海道大學正門，進門後立刻往左走到榆樹之森遊客中心", "https://commons.wikimedia.org/wiki/File:HokkaidoDaigakuSapporoKyanpasuSeimon2005-2.jpg", "Kinori · Public domain · 2005 · 縮放轉 WebP", ""),
    ],
    "北大中央草坪": [
      photo("hokudai-lawn-path", "從北大中央草坪旁的校園步道看向草坪與樹林", "https://commons.wikimedia.org/wiki/File:Central_Lawn_of_Sapporo_Campus,_Hokkaido_University_07.jpg", "ノボホショコロトソ · CC BY 4.0 · 2022 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
      photo("hokudai-lawn-stream", "北海道大學中央草坪的開放綠地與樹林", "https://commons.wikimedia.org/wiki/File:Central_Lawn_of_Sapporo_Campus,_Hokkaido_University_06.jpg", "ノボホショコロトソ · CC BY 4.0 · 2022 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
    ],
    "北大 Marche": [
      photo("hokudai-centennial-hall", "北大百年紀念會館的紅磚外牆與入口，北大 Marche 位於一樓", "https://commons.wikimedia.org/wiki/File:Hokkaido_University_Centennial_Hall.jpg", "禁樹なずな · CC BY-SA 4.0 · 2018 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
    ],
    "北大綜合博物館": [
      photo("hokudai-museum-1", "北大綜合博物館中央的拱門入口與前方步道", "https://commons.wikimedia.org/wiki/File:Hokkaido_University_Museum_01.jpg", "ノボホショコロトソ · CC BY 4.0 · 2025 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
      photo("hokudai-museum-sign", "北大綜合博物館大樓外刻有總合博物館的石標", "https://commons.wikimedia.org/wiki/File:Stone_Sign_of_Hokkaido_University_Museum_-_Oct_21,_2017.jpg", "oonnuuoo · CC BY 2.0 · 2017 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/2.0"),
      photo("hokudai-museum-front", "北大綜合博物館內部的展示通道與歷史儀器", "https://commons.wikimedia.org/wiki/File:Hokkaido_University,_Sapporo;_March_2025_(05).jpg", "MIKI Yoshihito. (#mikiyoshihito) · CC BY 2.0 · 2025 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/2.0"),
    ],
    "大野池": [
      photo("hokudai-ono-1", "大野池開闊水面與池邊立柱", "https://commons.wikimedia.org/wiki/File:Onoike_of_Hokkaido_University_01.jpg", "ノボホショコロトソ · CC BY 4.0 · 2020 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
      photo("hokudai-ono-2", "大野池的水生植物與秋天的池畔樹木", "https://commons.wikimedia.org/wiki/File:Onoike_of_Hokkaido_University_02.jpg", "ノボホショコロトソ · CC BY 4.0 · 2020 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
      photo("hokudai-ono-3", "北大大野池近岸的水生植物和水面", "https://commons.wikimedia.org/wiki/File:Onoike_of_Hokkaido_University_03.jpg", "ノボホショコロトソ · CC BY 4.0 · 2020 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
    ],
    "札幌・北大": [
      photo("hokudai-main-gate", "從札幌市區進入北大校園的正門", "https://commons.wikimedia.org/wiki/File:HokkaidoDaigakuSapporoKyanpasuSeimon2005-2.jpg", "Kinori · Public domain · 2005 · 縮放轉 WebP", ""),
      photo("hokudai-main-street", "北海道大學札幌校園的中央道路與行道樹", "https://commons.wikimedia.org/wiki/File:Main_Street_of_Hokkaido_University_in_Autumn.jpg", "ノボホショコロトソ · CC BY 4.0 · 2020 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
      photo("hokudai-lawn-path", "北大中央草坪旁的校園步道與草坪", "https://commons.wikimedia.org/wiki/File:Central_Lawn_of_Sapporo_Campus,_Hokkaido_University_07.jpg", "ノボホショコロトソ · CC BY 4.0 · 2022 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
    ],
    "巴士中心前站": [
      photo("transit-bus-center-exit", "札幌地鐵巴士中心前站 2 號出入口的路旁站亭", "https://commons.wikimedia.org/wiki/File:Bus_center_mae_sta_Exit_2.png", "Chuoterminal 02 · CC BY-SA 4.0 · 2025 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
      photo("transit-bus-center-gate", "巴士中心前站東西線剪票口", "https://commons.wikimedia.org/wiki/File:Tozai-line_BusCentermae-sta_Gate.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 2016 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
      photo("transit-bus-center-platform", "巴士中心前站的東西線月台與兩側方向看板", "https://commons.wikimedia.org/wiki/File:Bus-center-mae_station_platform_20160124_175301.jpg", "Chuoterminal 02 from jawp · CC BY 3.0 · 2016 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/3.0"),
    ],
    "北24條站": [
      photo("transit-kita24-exit", "北24條站 3 號出入口的地面階梯", "https://commons.wikimedia.org/wiki/File:Kitanijuyojo_Sta(Exit_3).jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 2025 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
      photo("transit-kita24-gate", "札幌地鐵南北線北24條站剪票口", "https://commons.wikimedia.org/wiki/File:Namboku-line_Kita_nijuyo_jo-sta_Gate.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 2016 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
      photo("transit-kita24-platform", "北24條站的南北線月台與月台門", "https://commons.wikimedia.org/wiki/File:Kita_nijuyo_jo_station_platform_20160207_193018.jpg", "Chuoterminal 02 from jawp · CC BY 3.0 · 2016 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/3.0"),
    ],
    "西線14條站": [
      photo("transit-nishi14-stop", "西線14條市電站的道路中央候車區與周邊街道，2009 年拍攝", "https://commons.wikimedia.org/wiki/File:Sapporo_Street_Car_Nishisen_Juyojo_Station.jpg", "Ozizo · Public domain · 2009 · 縮放轉 WebP", ""),
    ],
    "西4丁目站": [
      photo("transit-nishi4-arrivals", "西4丁目市電外回り列車專用下車月台，2024 年拍攝", "https://commons.wikimedia.org/wiki/File:Sapporo_city-tram_Nishi4choume_tram_stop%EF%BC%88For_getting_off_only%EF%BC%89.jpg", "くまもと急行鉄道 · CC0 · 2024 · 縮放轉 WebP", "http://creativecommons.org/publicdomain/zero/1.0/deed.en"),
      photo("transit-nishi4-stop", "有路面電車停靠的西4丁目市電站與候車棚", "https://commons.wikimedia.org/wiki/File:Nishi_yon_chome_Tramstop.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 2016 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
      photo("transit-nishi4-intersection", "西4丁目市電站路口側的候車月台與護欄", "https://commons.wikimedia.org/wiki/File:Nishi-yon-chome_Tramstop.JPG", "Chuoterminal_02 · CC BY 3.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/3.0"),
    ],
    "札幌伏見稻荷": [
      photo("shrine-fushimi-gates", "札幌伏見稻荷神社的紅色鳥居入口與石板步道", "https://commons.wikimedia.org/wiki/File:Fushimi_Inari_Shrine_of_Sapporo_-_gates.JPG", "禁樹なずな · CC BY-SA 4.0 · 2015 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
      photo("shrine-fushimi-first-gate", "札幌伏見稻荷神社同一段鳥居步道的雪天視角", "https://commons.wikimedia.org/wiki/File:20200120_Sapporo_Fushimi_Inari-1.jpg", "Balon Greyjoy · CC0 · 2020 · 縮放轉 WebP", "http://creativecommons.org/publicdomain/zero/1.0/deed.en"),
      photo("shrine-fushimi-hall", "沿札幌伏見稻荷的鳥居步道上行後可到神社拜殿", "https://commons.wikimedia.org/wiki/File:Sapporo_Fushimi_Inari_jinja.jpg", "Route275 · CC BY-SA 3.0 · 2007 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/3.0"),
    ],
    "伏見稻荷鳥居入口": [
      photo("shrine-fushimi-gates", "札幌伏見稻荷神社山坡下的鳥居入口與石板路", "https://commons.wikimedia.org/wiki/File:Fushimi_Inari_Shrine_of_Sapporo_-_gates.JPG", "禁樹なずな · CC BY-SA 4.0 · 2015 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"),
      photo("shrine-fushimi-first-gate", "下雪後由札幌伏見稻荷鳥居入口望向山坡步道", "https://commons.wikimedia.org/wiki/File:20200120_Sapporo_Fushimi_Inari-1.jpg", "Balon Greyjoy · CC0 · 2020 · 縮放轉 WebP", "http://creativecommons.org/publicdomain/zero/1.0/deed.en"),
    ],
    "北海道神宮": [
      photo("shrine-jingu-shinmon", "北海道神宮神門正前方的階梯與入口", "https://commons.wikimedia.org/wiki/File:20181107_Jingu_6458_(48437281857).jpg", "Ray Swi-hymn from Sijhih-Taipei, Taiwan · CC BY-SA 2.0 · 2018 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/2.0"),
      photo("shrine-jingu-courtyard", "北海道神宮通過神門後可見的拜殿正面，2026 年拍攝", "https://commons.wikimedia.org/wiki/File:(JPN-Hokkaido)_Hokkaido_Shrine_2026-06-06.jpg", "S5A-0043 · CC BY 4.0 · 2026 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"),
      photo("shrine-jingu-daini", "北海道神宮第二鳥居與主參道，第二鳥居在圓山公園入口之外", "https://commons.wikimedia.org/wiki/File:20181107_Jingu_6500_(48437238232).jpg", "Ray Swi-hymn from Sijhih-Taipei, Taiwan · CC BY-SA 2.0 · 2018 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/2.0"),
    ],
  };
})();
