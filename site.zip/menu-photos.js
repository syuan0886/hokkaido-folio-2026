window.folioMenuPhotos = {
  kamaei: {
    photo: ['photos/menu-kamaei.webp', 'かま栄的麵包魚板（パンロール）'],
    source: 'https://commons.wikimedia.org/wiki/File:%E3%83%91%E3%83%B3%E3%83%AD%E3%83%BC%E3%83%AB.jpg',
    credit: 'Ryuichi IKEDA · CC BY 2.0 · 縮放轉 WebP',
    license: 'https://creativecommons.org/licenses/by/2.0/',
  },
  butadon: {
    photo: ['assets/butadon.jpg', '十勝豚丼いっぴん的豬丼餐點示意'],
    source: 'https://commons.wikimedia.org/wiki/File:Tokachi_Butadon_Ippin_Butadon.jpg',
    credit: 'カイロス · 公有領域',
    note: '十勝豬丼餐點示意，攝於十勝豚丼いっぴん。',
  },
  'rokkatei-jingu': {
    photo: ['photos/menu-rokkatei.webp', '六花亭神宮茶屋店「判官さま」的 2024 年紀念包裝'],
    source: 'https://commons.wikimedia.org/wiki/File:Rokkatei_%22Hangan-sama%22_1.jpg',
    credit: 'Yamabato · CC BY-SA 4.0 · 縮放轉 WebP',
    license: 'https://creativecommons.org/licenses/by-sa/4.0/',
    note: '圖為 2024 年的紀念包裝。',
  },
  takinami: {
    photo: ['photos/menu-takinami.webp', '小樽三角市場滝波食堂的海鮮丼'],
    source: 'https://commons.wikimedia.org/wiki/File:' + encodeURIComponent('海鮮丼,_八角魚生魚片,_滝波食堂,_滝波商店,_北のどんぶり屋,_三角市場,_小樽,_北海道,_日本,_Otaru,_Hokkaido,_Japan,_おたるし,_ほっかいどう,_にっぽん,_にほん_(47026021534).jpg'),
    credit: 'bryan... · CC BY-SA 2.0 · 縮放轉 WebP',
    license: 'https://creativecommons.org/licenses/by-sa/2.0/',
  },
  aotsuka: {
    photo: ['photos/guides/venue-aotsuka-8.webp', '青塚食堂的魚丼套餐'],
    source: 'https://commons.wikimedia.org/wiki/File:' + encodeURIComponent('烤鰊魚,_烤花魚,_帆立貝,_花魚丼,_民宿青塚食堂,_小樽,_北海道,_日本,_Otaru,_Hokkaido,_Japan,_おたるし,_ほっかいどう,_にっぽん,_にほん_(47026019024).jpg'),
    credit: 'bryan... · CC BY-SA 2.0 · 縮放轉 WebP',
    license: 'https://creativecommons.org/licenses/by-sa/2.0/',
  },
  yabuhan: {
    photo: ['photos/guides/venue-yabuhan.webp', '小樽籔半的鍋燒烏龍麵'],
    source: 'https://commons.wikimedia.org/wiki/File:Nabeyaki_udon_at_Yabuhan_Soba_%E5%B0%8F%E6%A8%BD%E8%95%8E%E9%BA%A6%E5%B1%8B_%E7%B1%94%E5%8D%8A_in_Otaru,_Hokkaido,_Japan_(74).jpg',
    credit: 'Savannah Rivka · CC BY-SA 4.0 · 縮放轉 WebP',
    license: 'https://creativecommons.org/licenses/by-sa/4.0/',
    note: '籔半店內的鍋燒烏龍麵實拍。',
  },
  wakasaimo: {
    photo: ['photos/menu-wakasaimo.webp', 'わかさいも本舗的洞爺湖招牌和菓子'],
    source: 'https://commons.wikimedia.org/wiki/File:Wakasaimo_(Sweets_of_Hokkaido,_Japan).jpg',
    credit: '欅（Keyaki） · CC BY-SA 3.0 · 縮放轉 WebP',
    license: 'https://creativecommons.org/licenses/by-sa/3.0/',
  },
};
