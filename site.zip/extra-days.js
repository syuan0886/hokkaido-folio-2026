(() => {
  const days = (window.folioExtraDays ?? []).sort((a, b) => a.day - b.day);
  const create = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  };
  const externalLink = (label, url) => {
    const link = create('a', 'ink-link', label);
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener';
    return link;
  };

  const reading = document.querySelector('.reading');
  if (!reading) {
    const credits = document.querySelector('#extra-photo-credits');
    for (const day of days) {
      for (const credit of day.credits) {
        const row = create('li', '', credit.label + '。');
        row.append(externalLink('原圖', credit.url));
        if (credit.licenseUrl) {
          row.append(' · ', externalLink(credit.license, credit.licenseUrl));
        } else if (credit.license) {
          row.append(' · ' + credit.license);
        }
        credits.append(row);
      }
    }
    return;
  }

  const weekdays = ['五', '六', '日', '一'];
  const ordinals = ['三', '四', '五', '六'];
  const frames = {
    sapporo: {lng: 141.353, lat: 43.06, width: .165, src: 'maps/sapporo.webp'},
    otaru: {lng: 141.172, lat: 43.147, width: .55, src: 'maps/otaru.webp'},
    toya: {lng: 140.812, lat: 42.603, width: .215, src: 'maps/toya.webp'},
  };
  const mercator = lat => Math.asinh(Math.tan(lat * Math.PI / 180)) * 180 / Math.PI;
  const cover = document.querySelector('.cover-index');
  const catalog = document.querySelector('.catalog-list');
  const dateMenu = document.querySelector('#atlas-date-menu');
  const dateLabels = document.querySelectorAll('.atlas-day-date');
  const map = document.querySelector('.map-figure');
  const mapRoute = map.querySelector('svg');
  const details = new Map();
  window.folioExtraDetails = details;

  function makeTime(value) {
    const time = create('p', 'entry-time');
    const [start, end] = value.split(' ∼ ');
    if (end) time.append(start + ' ', create('span', 'time-range-wave', '∼'), ' ' + end);
    else time.textContent = value;
    return time;
  }

  function makePhoto([src, alt, crop], point) {
    const figure = create('figure', 'story-photo');
    figure.dataset.reading = point;
    const photo = new Image();
    photo.src = src;
    photo.alt = alt;
    photo.loading = 'lazy';
    if (crop) photo.style.objectPosition = '50% ' + crop;
    figure.append(photo);
    return figure;
  }

  function appendAtlas(day) {
    const frame = frames[day.day < 5 ? 'sapporo' : day.day === 5 ? 'otaru' : 'toya'];
    const north = mercator(frame.lat) + frame.width * 620 / 1280;
    const west = frame.lng - frame.width / 2;
    const pixelsPerDegree = 640 / frame.width;
    day.mapFrame = {...frame, north, west, pixelsPerDegree};
    const base = create('img', 'atlas-base');
    base.src = frame.src;
    base.alt = day.name + '地圖';
    base.width = 640;
    base.height = 620;
    base.dataset.mapDay = day.day;
    base.dataset.mapBase = '';
    map.insertBefore(base, mapRoute);

    for (const stop of day.stops) {
      const x = (stop.lng - west) * pixelsPerDegree;
      const y = (north - mercator(stop.lat)) * pixelsPerDegree;
      if (x < 0 || x > 640 || y < 0 || y > 620) continue;
      const marker = create('a', 'route-dot');
      marker.href = '#' + stop.entry;
      marker.dataset.pointId = stop.key;
      marker.dataset.mapDay = day.day;
      marker.dataset.extraPoint = '';
      marker.style.setProperty('--x', x / 6.4 + '%');
      marker.style.setProperty('--y', y / 6.2 + '%');
      if (x > 490) marker.classList.add('point-airport');
      if (y > 515) marker.classList.add('point-low');
      marker.append(create('span', '', stop.name));
      map.append(marker);
    }
  }

  for (const day of days) {
    const number = day.day;
    const date = 10 + number;
    const dateText = '11 / ' + date;
    const href = '#day-' + number;
    const dateNode = () => {
      const time = create('time', '', dateText);
      time.dateTime = '2026-11-' + date;
      return time;
    };
    const coverButton = create('button', 'ink-link');
    coverButton.type = 'button';
    coverButton.dataset.chapter = number - 1;
    coverButton.setAttribute('aria-pressed', 'false');
    coverButton.append(dateNode(), ' ' + day.name);
    cover.append(coverButton);
    const catalogLink = create('a', 'ink-link');
    catalogLink.href = href;
    catalogLink.append(dateNode(), create('span', 'ticket-label', day.name));
    catalog.append(catalogLink);
    const dateLink = create('a', 'ink-link', dateText);
    dateLink.href = href;
    dateMenu.append(dateLink);
    for (const dateLabel of dateLabels) {
      const label = create('span', '', dateText);
      label.dataset.dateDay = number;
      dateLabel.append(label);
    }

    const chapter = create('article', 'chapter');
    chapter.id = 'day-' + number;
    chapter.dataset.day = number;
    const header = create('header', 'chapter-heading');
    header.dataset.reading = day.entries[0].point;
    const folioNumber = create('p', 'folio-number', '第' + ordinals[number - 3] + '日 ');
    folioNumber.append(create('small', '', `11.${date}　週${weekdays[number - 3]}`));
    const title = create('h2', '', day.title);
    title.id = chapter.id + '-title';
    chapter.setAttribute('aria-labelledby', title.id);
    header.append(folioNumber, title, create('p', '', day.intro));
    chapter.append(header);
    for (const entry of day.entries) {
      if (entry.photo) chapter.append(makePhoto(entry.photo, entry.point));
      const section = create('section', 'entry');
      section.id = entry.id;
      section.dataset.reading = entry.point;
      section.append(makeTime(entry.time), create('h3', '', entry.title));
      for (const paragraph of entry.text.split('\n')) section.append(create('p', '', paragraph));
      details.set(entry.id, {entry, day});
      chapter.append(section);
    }
    reading.append(chapter);
    appendAtlas(day);
  }
})();
