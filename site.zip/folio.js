const cover = document.querySelector('.folio-cover');
const coverImage = cover.querySelector('.cover-image');
const coverPhoto = coverImage.querySelector('img');
const chapterButtons = [...cover.querySelectorAll('[data-chapter]')];
const squareList = cover.querySelector('.squares');
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const valley = ['photos/jozankei-woods.jpg', '定山溪山谷與紅色二見吊橋', '64%'];
const woods = ['photos/jozankei-river.jpg', '定山溪林間步道與秋葉', '62%'];
const airport = ['assets/chitose-street.jpg', '千歲站前街景', '58%'];
const university = ['photos/hokudai.jpg', '北海道大學的銀杏大道', '54%'];
const night = ['photos/moiwa.jpg', '從藻岩山俯瞰札幌夜景', '54%'];
const furukawa = ['photos/hokudai-furukawa.jpg', '秋天的北海道大學古河講堂', '51%'];

const chapters = [
  [valley, airport, woods],
  [night, university, furukawa],
  ...window.folioExtraDays.map(day => day.photos),
];

const details = {
  food: {
    time: '13:00 ∼ 13:50', title: '魚板與十勝豬丼',
  },
  park: {
    time: '19:20 ∼ 20:00', title: '定山源泉公園',
  },
  moiwa: {
    time: '19:40 ∼ 21:00', title: '藻岩山展望台',
  },
};

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
function arrive(element) {
  element.classList.remove('is-leaving');
  element.classList.add('is-arriving');
}

async function leave(element) {
  element.classList.remove('is-arriving');
  element.classList.add('is-leaving');
  if (reducedMotion.matches) return;
  if (element instanceof HTMLDialogElement) {
    await Promise.all(element.getAnimations().map(animation => animation.finished.catch(() => {})));
  } else {
    await wait(240);
  }
}

let selectedChapter = 0;
let selectedPhoto = 0;
let changeId = 0;

function paintSquares() {
  const oldFocus = squareList.contains(document.activeElement);
  squareList.replaceChildren(...chapters[selectedChapter].map((photo, index) => {
    const button = document.createElement('button');
    button.className = 'square-button';
    button.type = 'button';
    button.setAttribute('aria-label', `照片 ${index + 1}，${photo[1]}`);
    button.setAttribute('aria-pressed', String(index === selectedPhoto));
    button.addEventListener('click', () => selectCover(selectedChapter, index));
    return button;
  }));
  if (oldFocus) squareList.children[selectedPhoto].focus({preventScroll: true});
}

async function selectCover(day, photo) {
  const id = ++changeId;
  if (day === selectedChapter && photo === selectedPhoto) {
    cover.classList.remove('is-leaving');
    coverImage.classList.remove('is-leaving');
    return;
  }
  const [src, alt, position] = chapters[day][photo];
  const nextImage = new Image();
  nextImage.src = src;
  try { await nextImage.decode(); } catch {
    if (id === changeId) {
      cover.classList.remove('is-leaving');
      coverImage.classList.remove('is-leaving');
    }
    return;
  }
  if (id !== changeId) return;

  const newDay = selectedChapter !== day;
  cover.classList.remove('is-leaving', 'is-arriving');
  coverImage.classList.remove('is-leaving', 'is-arriving');
  const motion = newDay ? cover : coverImage;
  await leave(motion);
  if (id !== changeId) return;

  selectedChapter = day;
  selectedPhoto = photo;
  coverPhoto.src = src;
  coverPhoto.alt = alt;
  coverPhoto.style.setProperty('--photo-y', position);
  document.querySelector('#read-chapter').href = `#day-${day + 1}`;
  chapterButtons.forEach((button, index) => button.setAttribute('aria-pressed', String(index === day)));
  paintSquares();
  arrive(motion);
}

chapterButtons.forEach((button, index) => button.addEventListener('click', () => selectCover(index, 0)));
paintSquares();

const atlas = document.querySelector('.atlas');
const mapDate = atlas.querySelector('#map-date');
const dateLinks = [...atlas.querySelectorAll('nav a')];
const entries = [...document.querySelectorAll('[data-reading]')];
let reading = '';
let scheduled = false;

function paintAtlasDay(scope, day, frame = 'local') {
  scope.dataset.day = day;
  scope.dataset.mapFrame = frame;
  for (const layer of scope.querySelectorAll('[data-map-day]')) {
    layer.toggleAttribute('data-visible-day', layer.dataset.mapDay === day
      && (!layer.dataset.mapFrame || layer.dataset.mapFrame === frame));
  }
  for (const label of scope.querySelectorAll('[data-date-day]')) {
    label.toggleAttribute('data-current-day', label.dataset.dateDay === day);
  }
}

function paintAtlasPoint(scope, point, entry = '') {
  scope.dataset.point = point;
  scope.dataset.entry = entry;
  for (const marker of scope.querySelectorAll('[data-point-id]')) {
    if (marker.hasAttribute('data-visible-day') && marker.dataset.pointId === point) marker.setAttribute('aria-current', 'location');
    else marker.removeAttribute('aria-current');
  }
  const paths = [...scope.querySelectorAll('[data-visible-day] [data-route-point]')];
  const hasEntry = entry && paths.some(path => path.dataset.routeEntry === entry);
  for (const path of paths) {
    path.toggleAttribute('data-active-leg', hasEntry ? path.dataset.routeEntry === entry : path.dataset.routePoint === point);
  }
}

function followReading() {
  scheduled = false;
  if (atlas.hasAttribute('data-date-revealing') || atlas.hasAttribute('data-mobile-date-open')) return;
  const atlasBounds = atlas.getBoundingClientRect();
  const mapAtTop = matchMedia('(max-width: 750px)').matches && atlasBounds.top <= 16 && atlasBounds.bottom > 0;
  const line = mapAtTop ? atlasBounds.bottom + 64 : innerHeight * .25;
  const current = entries.findLast(entry => {
    const bounds = entry.getBoundingClientRect();
    const anchor = entry.matches('figure') ? bounds.top + Math.min(150, bounds.height * .45) : bounds.top;
    return anchor < line;
  }) ?? entries[0];
  const day = current.closest('.chapter').dataset.day;
  const entry = current.id || (current.matches('figure') ? current.nextElementSibling?.id : '') || '';
  const frame = day === '6' && (!entry || /^d6-station-(start|return)$/.test(entry)) ? 'regional' : 'local';
  const point = entry === 'd6-station-return' ? 'd6-sapporo' : current.dataset.reading;
  const position = `${day}-${point}-${entry}`;
  if (reading === position) return;
  reading = position;
  paintAtlasDay(atlas, day, frame);
  paintAtlasPoint(atlas, point, entry);
  mapDate.textContent = `11 / ${10 + Number(day)}`;
  dateLinks.forEach((link, index) => {
    if (index + 1 === Number(day)) link.setAttribute('aria-current', 'date');
    else link.removeAttribute('aria-current');
  });
}

function scheduleReading() {
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(followReading);
}

addEventListener('scroll', scheduleReading, {passive: true});
addEventListener('resize', scheduleReading);
followReading();

const catalog = document.querySelector('.catalog');
const detail = document.querySelector('.detail');
const menuDialog = document.querySelector('.menu-sheet');
const catalogButton = document.querySelector('[data-catalog]');
const dialogTriggers = new WeakMap();

document.addEventListener('pointerdown', event => {
  document.documentElement.toggleAttribute('data-touch-input', event.pointerType === 'touch');
}, {capture: true, passive: true});
document.addEventListener('keydown', () => {
  document.documentElement.removeAttribute('data-touch-input');
}, {capture: true});

let controlClickSequence = false;
document.addEventListener('mousedown', event => {
  if (event.button !== 0) return;
  if (event.detail <= 1) {
    controlClickSequence = Boolean(event.target.closest('button, a[href], summary, .atlas-expanded-controls'));
  } else if (controlClickSequence) {
    // A control can close a dialog before the next click reaches the same spot.
    event.preventDefault();
  }
}, {capture: true});

function openDialog(dialog, trigger) {
  dialogTriggers.set(dialog, trigger);
  dialog.showModal();
  dialog.scrollTop = 0;
  arrive(dialog);
}

async function closeDialog(dialog, destination = '') {
  if (dialog.classList.contains('is-leaving')) return;
  await leave(dialog);
  dialog.close();
  dialog.classList.remove('is-leaving');
  dialogTriggers.get(dialog)?.focus({preventScroll: true});
  if (destination) location.hash = destination;
}

catalogButton.addEventListener('click', () => {
  catalogButton.setAttribute('aria-expanded', 'true');
  openDialog(catalog, catalogButton);
});
catalog.addEventListener('close', () => catalogButton.setAttribute('aria-expanded', 'false'));
for (const link of catalog.querySelectorAll('a')) {
  link.addEventListener('click', event => {
    event.preventDefault();
    const selection = getSelection();
    if (!selection.isCollapsed && link.contains(selection.anchorNode)) return;
    closeDialog(catalog, link.hash);
  });
}

function detailNode(tag, text) {
  const node = document.createElement(tag);
  node.textContent = text;
  return node;
}

const detailEntries = window.folioExtraDetails;
const entryNotes = window.folioEntryNotes;
const menusByEntry = new Map();
for (const [id, menu] of Object.entries(window.folioMenus ?? {})) {
  if (!menusByEntry.has(menu.entry)) menusByEntry.set(menu.entry, []);
  menusByEntry.get(menu.entry).push({...menu, media: window.folioMenuPhotos?.[id]});
}

for (const section of document.querySelectorAll('.reading .entry')) {
  const title = section.querySelector('h3').textContent;
  let trigger = section.querySelector('[data-detail]');
  const key = trigger?.dataset.detail ?? section.id;
  if (!detailEntries.has(key)) {
    const day = Number(section.closest('.chapter').dataset.day);
    const text = [...section.querySelectorAll(':scope > p:not(.entry-time)')].map(paragraph => paragraph.textContent).join('\n');
    detailEntries.set(key, {day: {day, stops: []}, entry: {
      id: section.id, point: section.dataset.reading, title, text,
      time: section.querySelector('.entry-time').textContent.trim(),
    }});
  }
  if (!trigger) {
    trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'ink-link';
    trigger.dataset.detail = key;
    section.append(trigger);
  }
  const arrow = trigger.querySelector('.detail-arrow') ?? document.createElement('span');
  arrow.className = 'detail-arrow';
  arrow.setAttribute('aria-hidden', 'true');
  trigger.replaceChildren('詳細資訊 ', arrow);
  trigger.setAttribute('aria-label', '詳細資訊：' + title);
  trigger.setAttribute('aria-haspopup', 'dialog');

  const config = detailEntries.get(key);
  const note = entryNotes[key];
  config.routeEntry = note?.routeEntry ?? config.entry.id;
  if (note?.places) {
    config.places = note.places.map(place => {
      if (typeof place !== 'string') return place;
      const stop = config.day.stops.find(({key}) => key === place);
      return [stop.name, [stop.lat, stop.lng], stop.name];
    });
  }
}

function showMenu(menu, trigger) {
  menuDialog.querySelector('h2').textContent = menu.name;
  const figure = menuDialog.querySelector('.menu-photo');
  const image = figure.querySelector('img');
  const caption = figure.querySelector('figcaption');
  const {photo, note: photoNote, source: photoSource, credit, license} = menu.media ?? {};
  figure.hidden = !photo;
  image.alt = photo?.[1] ?? '';
  if (photo) image.src = photo[0];
  else image.removeAttribute('src');
  caption.replaceChildren(photoNote ?? '');
  if (photoNote && credit) caption.append(' ');
  if (photoSource && credit) {
    const link = detailNode('a', credit);
    link.href = photoSource;
    link.target = '_blank';
    link.rel = 'noopener';
    caption.append(link);
  } else if (credit) caption.append(credit);
  if (license) {
    const link = detailNode('a', '授權');
    link.href = license;
    link.target = '_blank';
    link.rel = 'noopener';
    caption.append(' · ', link);
  }
  caption.hidden = !caption.textContent;
  const note = menuDialog.querySelector('.menu-sheet-note');
  note.textContent = menu.note ?? '';
  note.hidden = !menu.note;
  const table = menuDialog.querySelector('table');
  table.hidden = !menu.items.length;
  table.querySelector('tbody').replaceChildren(...menu.items.map(([name, price]) => {
    const row = document.createElement('tr');
    const item = detailNode('th', name);
    item.scope = 'row';
    row.append(item, detailNode('td', price));
    return row;
  }));
  const source = menuDialog.querySelector('.menu-sheet-source');
  source.href = menu.source;
  openDialog(menuDialog, trigger);
}

function renderDetail(item, content) {
  const [startTime, endTime] = item.time.split(' ∼ ');
  const wave = detailNode('span', '∼');
  wave.className = 'time-range-wave';
  const time = detail.querySelector('.detail-time');
  if (endTime) time.replaceChildren(`${startTime} `, wave, ` ${endTime}`);
  else time.textContent = item.time;
  detail.querySelector('h2').textContent = item.title;
  detail.querySelector('.detail-intro').textContent = content.intro;
  const menus = new Map(content.menus.map(menu => [menu.factLabel ?? menu.name, menu]));
  function factRow(label, value, menu) {
    const row = document.createElement('div');
    row.append(detailNode('dt', label), detailNode('dd', value));
    if (menu) {
      row.className = 'detail-fact-with-menu';
      const action = document.createElement('dd');
      const button = detailNode('button', '');
      button.type = 'button';
      button.className = 'ink-link detail-menu-button';
      button.setAttribute('aria-label', '查看' + menu.name + '菜單');
      button.setAttribute('aria-haspopup', 'dialog');
      button.setAttribute('aria-controls', 'folio-menu');
      const label = detailNode('span', '菜單');
      label.className = 'ticket-label';
      button.append(label);
      button.addEventListener('click', () => showMenu(menu, button));
      action.append(button);
      row.append(action);
    }
    return row;
  }
  const facts = content.facts.map(([label, value]) => {
    const menu = menus.get(label);
    menus.delete(label);
    return factRow(label, value, menu);
  });
  for (const menu of menus.values()) facts.push(factRow(menu.name, '品項與價格', menu));
  detail.querySelector('.detail-facts').replaceChildren(...facts);
  const sections = content.sections.map(({title, text}) => {
    const section = document.createElement('section');
    section.append(detailNode('h3', title), detailNode('p', text));
    return section;
  });
  if (content.movements.length) {
    const section = document.createElement('section');
    const list = document.createElement('ol');
    list.className = 'detail-steps';
    list.replaceChildren(...content.movements.map(label => detailNode('li', label)));
    section.append(detailNode('h3', '地圖動線'), list);
    sections.push(section);
  }
  detail.querySelector('.detail-sections').replaceChildren(...sections);
  const sources = detail.querySelector('.detail-sources');
  sources.hidden = !content.sources.length;
  sources.querySelector('ul').replaceChildren(...content.sources.map(({label, url}) => {
    const link = document.createElement('a');
    const ticket = detailNode('span', label);
    ticket.className = 'ticket-label';
    link.append(ticket);
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener';
    link.className = 'ink-link';
    const row = document.createElement('li');
    row.append(link);
    return row;
  }));

}

for (const button of document.querySelectorAll('[data-detail]')) {
  button.addEventListener('click', () => {
    if (detail.open) return;
    const key = button.dataset.detail;
    const {entry, day, routeEntry} = detailEntries.get(key);
    const note = entryNotes[key];
    const original = window.folioSpotDetails[key];
    const item = details[key] ?? {...entry, title: note?.title ?? entry.title};
    const content = {
      intro: original?.intro ?? entry.text,
      facts: [...(original?.facts ?? note?.facts ?? []), ...(note?.moreFacts ?? [])],
      sections: [...(original?.sections ?? []), ...(note?.sections ?? []).map(([title, text]) => ({title, text}))],
      sources: [...(original?.sources ?? []), ...[...(entry.links ?? []), ...(note?.sources ?? [])].map(([label, url]) => ({label, url}))],
      menus: menusByEntry.get(key) ?? [],
      movements: [...new Set((window.folioRoutes?.[day.day] ?? []).filter(leg => leg.entry === routeEntry).map(leg => leg.label).filter(Boolean))],
    };
    renderDetail(item, content);
    detail.dataset.detailKey = key;
    openDialog(detail, button);
  });
}

for (const dialog of [catalog, detail, menuDialog]) {
  dialog.addEventListener('animationend', event => {
    if (event.target === dialog && event.animationName === 'folio-dialog-fade-in') dialog.classList.remove('is-arriving');
  });
  dialog.querySelector('[data-close]').addEventListener('click', () => closeDialog(dialog));
  function isBackdrop(event) {
    if (event.target !== dialog) return false;
    const {left, right, top, bottom} = dialog.getBoundingClientRect();
    return event.clientX < left || event.clientX > right || event.clientY < top || event.clientY > bottom;
  }
  dialog.addEventListener('mousedown', event => {
    if (isBackdrop(event)) event.preventDefault();
  });
  dialog.addEventListener('dblclick', event => {
    if (!isBackdrop(event)) return;
    event.preventDefault();
    closeDialog(dialog);
  });
  dialog.addEventListener('cancel', event => {
    event.preventDefault();
    closeDialog(dialog);
  });
}
