window.folioSpotDetails = {
  food: {
    intro: '在新千歲機場吃午餐，先到國內線二樓買小樽魚板，再上三樓吃十勝豬丼。',
    facts: [
      ['かま栄', '國內線 2F，08:00–20:00'],
      ['豚丼名人', '國內線 3F，11:00 開店'],
      ['搭車', 'JR 新千歲機場站在 B1F'],
    ],
    sections: [
      {title: '二樓　かま栄', text: '招牌パンロール把魚漿包進薄麵包後油炸。也可挑選剛炸好的魚板外帶。'},
      {title: '三樓　豚丼名人', text: '店在三樓美食區（グルメワールド）。特製美乃滋豬丼和炙燒起司豬丼是新千歲機場限定。'},
      {title: '轉乘與營業時間', text: '兩間店都在國內線安檢前。用餐後循 JR 指標下到 B1F。豬丼店與機場公告的晚間收店時間有差異，傍晚到訪可先向店家確認，電話 0123-46-4200。'},
    ],
    sources: [
      {label: '機場　かま栄位置與營業', url: 'https://www.hokkaido-airports.com/ja/new-chitose/spend/shop/48/'},
      {label: 'かま栄　パンロール與價格', url: 'https://kamaei.co.jp/about-panroll/'},
      {label: '機場　豚丼名人與餐點價格', url: 'https://www.hokkaido-airports.com/ja/new-chitose/spend/shop/123/'},
      {label: '豚丼名人　完整店家菜單', url: 'https://www.butadonmeijin.com/shop.html'},
      {label: '機場　JR 車站動線', url: 'https://www.hokkaido-airports.com/ja/new-chitose/access/jr/'},
    ],
  },
  park: {
    intro: '晚餐後到月見橋旁的定山源泉公園泡足湯。',
    facts: [
      ['足湯開放', '07:00–21:00，全年開放'],
      ['費用', '免費'],
      ['最近巴士站', '定山渓湯の町'],
    ],
    sections: [
      {title: '月見橋旁的源泉', text: '公園在札幌市南區定山溪溫泉東 3 丁目，園內有足湯和美泉定山像。晚餐後步行過去，記得帶一條小毛巾。'},
      {title: '用源泉煮溫泉蛋', text: '園內的「おんたまの湯」使用超過 80 度的源泉，通常約需 20 分鐘。對岸的定山溪物產館販售三顆生蛋加網袋的組合，協會標示 ¥180，當天可向店家確認煮蛋時間。'},
    ],
    sources: [
      {label: '定山溪觀光協會　定山源泉公園', url: 'https://jozankei.jp/tw/oneday/jozan-gensen-park/'},
      {label: '定山溪觀光協會　溫泉蛋體驗', url: 'https://jozankei.jp/oneday/ontama/'},
      {label: '定山溪觀光協會　足湯常見問題', url: 'https://jozankei.jp/contact/faq/'},
    ],
  },
  moiwa: {
    intro: '從藻岩山麓搭纜車，到中腹轉乘迷你纜車，在海拔 531 公尺的山頂看札幌夜景。',
    facts: [
      ['兩段來回', '成人 ¥2,100，兒童 ¥1,050'],
      ['11 月營運時段', '山麓纜車 10:30–22:00'],
      ['最晚由山麓上山', '21:30'],
    ],
    sections: [
      {title: '市電與接駁', text: '在「ロープウェイ入口」站下車，轉乘免費接駁到伏見 5 丁目 3–7 的山麓站。官方一般班距約 15 分鐘，平日傍晚開始營運。也可以從接駁站步行約 10 分鐘，約 500 公尺。'},
      {title: '上山與回程', text: '山麓到中腹的纜車約 5 分鐘，中腹到山頂的迷你纜車約 2 分鐘，兩段車程另加排隊和轉乘。展望台可環望札幌，也可在幸福之鐘旁停留拍照。人潮多時回程排隊較久，出發前可查看官方運行狀態和即時影像。'},
    ],
    sources: [
      {label: '藻岩山纜車　時刻與票價', url: 'https://mt-moiwa.jp/guide/'},
      {label: '藻岩山纜車　市電與免費接駁', url: 'https://mt-moiwa.jp/access/shuttlebus-tram/'},
      {label: '藻岩山纜車　展望台', url: 'https://mt-moiwa.jp/facility/st-summit/observation-deck/'},
      {label: '藻岩山纜車　即時影像與運行狀態', url: 'https://mt-moiwa.jp/'},
    ],
  },
};
