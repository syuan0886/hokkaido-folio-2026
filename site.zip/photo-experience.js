{
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const menu = document.querySelector('.menu-sheet');
  const photoFrames = new Map();
  const menuHead = menu.querySelector('.dialog-head');
  let active;
  let scrollFrame;
  let parallaxTime;
  let geometryDirty = true;

  function makeScene(parent, className) {
    const layer = document.createElement('figure');
    const image = new Image();
    layer.className = `folio-photo-ink ${className}`;
    layer.setAttribute('aria-hidden', 'true');
    image.alt = '';
    layer.append(image);
    parent.append(layer);
    return {layer, image};
  }

  const pageScene = makeScene(document.body, 'folio-photo-scene');
  const menuScene = makeScene(menu, 'folio-detail-scene');

  function moveInkTo(layer, trigger) {
    const point = trigger.getBoundingClientRect();
    layer.style.setProperty('--photo-ink-x', `${point.left + point.width / 2}px`);
    layer.style.setProperty('--photo-ink-y', `${point.top + point.height / 2}px`);
  }

  function collapsePhotograph() {
    if (!active) return;
    const {trigger, figure, scope, layer, className} = active;
    active = undefined;
    if (figure.matches('.story-photo') && trigger.matches(':hover')) {
      trigger.setAttribute('data-photo-hover-paused', '');
    }
    trigger.setAttribute('aria-pressed', 'false');
    figure.classList.remove('is-photo-preview');
    scope.classList.remove(className);
    layer.classList.remove('is-revealed');
  }

  function togglePhotograph(photo, trigger, figure) {
    const previous = active?.trigger;
    collapsePhotograph();
    if (previous === trigger || !photo.naturalWidth) return;

    const isMenu = figure.matches('.menu-photo');
    const isReading = figure.matches('.story-photo');
    const scene = isMenu ? menuScene : pageScene;
    const scope = isMenu ? menu : document.body;
    const className = isMenu ? 'has-menu-photo-scene' : isReading ? 'has-reading-photo-scene' : 'has-photo-scene';
    const preview = {trigger, figure, scope, className, layer: scene.layer};
    active = preview;

    scene.image.src = photo.currentSrc || photo.src;
    scene.image.style.objectPosition = getComputedStyle(photo).objectPosition;
    if (isMenu) {
      menu.style.setProperty('--menu-photo-image', `url(${JSON.stringify(scene.image.src)})`);
      menu.style.setProperty('--menu-photo-position', scene.image.style.objectPosition);
    } else {
      scene.layer.classList.toggle('is-reading-scene', isReading);
    }
    moveInkTo(scene.layer, trigger);
    trigger.setAttribute('aria-pressed', 'true');
    figure.classList.add('is-photo-preview');
    scope.classList.add(className);
    scene.layer.classList.add('is-revealed');
    scheduleParallax();
  }

  function bindPhotograph(figure) {
    const photo = figure.querySelector('img');
    if (!photo || photo.closest('.folio-photo-button')) return;
    const trigger = document.createElement('button');
    const viewport = document.createElement('span');
    trigger.className = 'folio-photo-button';
    trigger.type = 'button';
    trigger.setAttribute('aria-pressed', 'false');
    viewport.className = 'folio-photo-viewport';
    photo.classList.add('folio-photo-original');
    photo.before(trigger);
    trigger.append(viewport);
    viewport.append(photo);
    trigger.addEventListener('click', () => togglePhotograph(photo, trigger, figure));
    if (figure.matches('.story-photo')) {
      trigger.addEventListener('pointerleave', () => trigger.removeAttribute('data-photo-hover-paused'));
    }
    const updateBloom = () => {
      const source = photo.currentSrc || photo.src;
      if (source) trigger.style.setProperty('--photo-bloom', `url(${JSON.stringify(source)})`);
      scheduleParallax();
    };
    photoFrames.set(trigger, {image: photo});
    photo.addEventListener('load', updateBloom);
    if (photo.complete && photo.naturalWidth) updateBloom();
  }

  for (const figure of document.querySelectorAll('.cover-image, .story-photo, .menu-photo, .folio-extra-photo')) {
    bindPhotograph(figure);
  }

  menu.addEventListener('close', () => {
    if (active?.scope === menu) collapsePhotograph();
  });
  document.addEventListener('click', event => {
    if (event.target.closest('.square-button, [data-chapter], #read-chapter, [data-catalog], [data-detail]')) collapsePhotograph();
  }, {capture: true});
  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !active || document.querySelector('.atlas-expanded[open]')) return;
    event.preventDefault();
    collapsePhotograph();
  }, {capture: true});

  function paintParallax(time) {
    scrollFrame = undefined;
    const elapsed = Math.min(50, time - (parallaxTime ?? time - 16));
    const easing = 1 - Math.exp(-elapsed / 110);
    parallaxTime = time;

    if (geometryDirty) {
      geometryDirty = false;
      const headerRaised = active?.scope === menu && menu.scrollTop > 2;
      menu.toggleAttribute('data-photo-header-raised', headerRaised);
      if (headerRaised) {
        const {top, right, bottom, left} = menuHead.getBoundingClientRect();
        menu.style.setProperty('--photo-header-clip', `${top}px ${innerWidth - right}px ${innerHeight - bottom}px ${left}px`);
      }
      if (active) {
        const bounds = active.trigger.getBoundingClientRect();
        if (bounds.bottom <= 0 || bounds.top >= innerHeight) collapsePhotograph();
      }
      for (const [frame, state] of photoFrames) {
        const box = frame.getBoundingClientRect();
        state.visible = !reduceMotion.matches && box.height > 0 && box.bottom >= 0 && box.top <= innerHeight;
        if (!state.visible) {
          state.offset = undefined;
          continue;
        }
        const height = box.height;
        const distance = (innerHeight / 2 - (box.top + height / 2)) / ((innerHeight + height) / 2);
        const travel = Math.min(36, height * .083);
        state.target = distance * travel;
        state.image.style.setProperty('--photo-parallax-scale', (1.025 + (2 * travel) / height).toFixed(3));
      }
    }

    let moving = false;
    for (const state of photoFrames.values()) {
      if (!state.visible) continue;
      const current = state.offset ?? state.target;
      const distance = state.target - current;
      const settling = Math.abs(distance) > .065;
      state.offset = settling ? current + distance * easing : state.target;
      state.image.style.setProperty('--photo-parallax-y', `${state.offset.toFixed(2)}px`);
      moving ||= settling;
    }
    if (moving) scrollFrame = requestAnimationFrame(paintParallax);
    else parallaxTime = undefined;
  }

  function scheduleParallax() {
    geometryDirty = true;
    if (scrollFrame === undefined) scrollFrame = requestAnimationFrame(paintParallax);
  }

  document.addEventListener('scroll', scheduleParallax, {capture: true, passive: true});
  window.addEventListener('resize', () => {
    scheduleParallax();
    if (active) moveInkTo(active.layer, active.trigger);
  });
  reduceMotion.addEventListener('change', scheduleParallax);
  window.addEventListener('load', scheduleParallax, {once: true});
  scheduleParallax();
}
