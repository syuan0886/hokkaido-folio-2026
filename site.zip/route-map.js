(() => {
  const map = document.querySelector('.map-figure');
  const svg = map.querySelector('.atlas-route');
  const mercator = latitude => Math.asinh(Math.tan(latitude * Math.PI / 180)) * 180 / Math.PI;
  const legacy = {
    pixelsPerDegree: 745.65,
    west: 141.68073 - 537 / 745.65,
    north: mercator(42.78767) + 460 / 745.65,
  };
  const regionWidth = 1.5;
  const regional = {
    pixelsPerDegree: 640 / regionWidth,
    west: 141.117 - regionWidth / 2,
    north: mercator(42.72) + regionWidth * 620 / 1280,
  };
  const localFrames = new Map([
    ['1', legacy],
    ['2', legacy],
    ...window.folioExtraDays.map(day => [String(day.day), day.mapFrame]),
  ]);
  window.folioMapFrame = (day, frame) => frame === 'regional' ? regional : localFrames.get(day);

  function project(frame, [longitude, latitude]) {
    return [(longitude - frame.west) * frame.pixelsPerDegree,
      (frame.north - mercator(latitude)) * frame.pixelsPerDegree];
  }

  function addPaths(day, frameName) {
    const group = document.createElementNS(svg.namespaceURI, 'g');
    group.dataset.mapDay = day;
    if (day === '6') group.dataset.mapFrame = frameName;
    const frame = window.folioMapFrame(day, frameName);
    for (const leg of window.folioRoutes?.[day] ?? []) {
      if (leg.coords.length < 2) continue;
      if (day === '6' && frameName === 'local' && leg.mode === 'rail') continue;
      const points = leg.coords.map(coordinate => project(frame, coordinate));
      if (points.every(([x]) => x < 0) || points.every(([x]) => x > 640)
        || points.every(([, y]) => y < 0) || points.every(([, y]) => y > 620)) continue;
      const path = document.createElementNS(svg.namespaceURI, 'path');
      path.dataset.routePoint = leg.point;
      path.dataset.mode = leg.mode;
      if (leg.entry) path.dataset.routeEntry = leg.entry;
      path.setAttribute('d', points.map(([x, y], index) =>
        (index ? 'L' : 'M') + x.toFixed(2) + ' ' + y.toFixed(2)).join(' '));
      group.append(path);
    }
    svg.append(group);
  }

  for (const element of map.querySelectorAll('[data-map-day="6"]')) element.dataset.mapFrame = 'local';
  const base = new Image(640, 620);
  base.className = 'atlas-base';
  base.alt = '札幌至洞爺湖的道央區域地圖';
  base.src = 'maps/toya-region.webp';
  base.dataset.mapDay = '6';
  base.dataset.mapFrame = 'regional';
  base.dataset.mapBase = '';
  map.insertBefore(base, svg);

  for (const [point, entry, label, longitude, latitude] of [
    ['d6-sapporo', 'd6-station-return', 'JR 札幌站', 141.350778, 43.068611],
    ['d6-station', 'd6-station-start', 'JR 洞爺站', 140.763735, 42.550741],
  ]) {
    const marker = document.createElement('a');
    const name = document.createElement('span');
    const [x, y] = project(regional, [longitude, latitude]);
    name.textContent = label;
    marker.className = 'route-dot point-sapporo';
    marker.href = '#' + entry;
    marker.dataset.mapDay = '6';
    marker.dataset.mapFrame = 'regional';
    marker.dataset.pointId = point;
    marker.style.setProperty('--x', x / 6.4 + '%');
    marker.style.setProperty('--y', y / 6.2 + '%');
    marker.append(name);
    map.append(marker);
  }

  for (const day of localFrames.keys()) addPaths(day, 'local');
  addPaths('6', 'regional');

  const routeSegments = new WeakMap();
  const labelDirections = [[1, -1], [-1, -1], [1, 1], [-1, 1], [0, -1], [0, 1], [1, 0], [-1, 0]];
  const labelGaps = [12, 18, 26, 36, 48, 65];
  const intersects = (a, b) => a.left <= b.right && a.right >= b.left && a.top <= b.bottom && a.bottom >= b.top;
  const priority = marker => marker.hasAttribute('aria-current') ? 2 : Number(marker.matches(':hover, :focus-visible'));

  function pathSegments(scene, width, height) {
    const group = scene.querySelector('.atlas-route > g[data-visible-day]');
    if (!group) return [];
    const cached = routeSegments.get(group);
    if (cached?.width === width && cached.height === height) return cached.segments;
    const segments = [];
    for (const path of group.querySelectorAll('path')) {
      const points = [...path.getAttribute('d').matchAll(/[ML](-?[\d.]+) (-?[\d.]+)/g)]
        .map(([, x, y]) => [Number(x) * width / 640, Number(y) * height / 620]);
      for (let index = 1; index < points.length; index++) {
        const [x, y] = points[index - 1];
        const [endX, endY] = points[index];
        segments.push({x, y, dx: endX - x, dy: endY - y, left: Math.min(x, endX),
          right: Math.max(x, endX), top: Math.min(y, endY), bottom: Math.max(y, endY)});
      }
    }
    routeSegments.set(group, {width, height, segments});
    return segments;
  }

  function coversSegment(box, segment) {
    if (!intersects(box, segment)) return false;
    const halfWidth = (box.right - box.left) / 2;
    const halfHeight = (box.bottom - box.top) / 2;
    const x = box.left + halfWidth - segment.x;
    const y = box.top + halfHeight - segment.y;
    return Math.abs(segment.dx * y - segment.dy * x)
      <= Math.abs(segment.dy) * halfWidth + Math.abs(segment.dx) * halfHeight;
  }

  window.folioPlaceMapLabels = (scene, viewport, controls, markerScale = 1) => {
    const width = scene.clientWidth;
    const height = scene.clientHeight;
    if (!width || !height || !scene.isConnected) return;
    const sceneRect = scene.getBoundingClientRect();
    const scale = sceneRect.width / width;
    if (!scale) return;
    const edge = Math.min(width * .07, 20);
    const localBox = ({left, right, top, bottom}) => ({
      left: (left - sceneRect.left) / scale, right: (right - sceneRect.left) / scale,
      top: (top - sceneRect.top) / scale, bottom: (bottom - sceneRect.top) / scale,
    });
    const view = localBox(viewport.getBoundingClientRect());
    const bounds = {
      left: Math.max(edge, view.left + 5 / scale), right: Math.min(width - edge, view.right - 5 / scale),
      top: Math.max(edge, view.top + 5 / scale), bottom: Math.min(height - edge, view.bottom - 5 / scale),
    };
    const segments = pathSegments(scene, width, height);
    const markers = [...scene.querySelectorAll('.route-dot[data-visible-day]')];
    const occupied = controls.filter(control => control.getClientRects().length)
      .map(control => localBox(control.getBoundingClientRect()));
    const markerRadius = 7 / markerScale;
    const labels = markers.map(marker => {
      const x = marker.offsetLeft;
      const y = marker.offsetTop;
      const label = marker.querySelector('span');
      occupied.push({left: x - markerRadius, right: x + markerRadius, top: y - markerRadius, bottom: y + markerRadius});
      return {marker, x, y, rank: priority(marker),
        width: label.offsetWidth / markerScale, height: label.offsetHeight / markerScale};
    }).sort((a, b) => b.rank - a.rank);

    for (const {marker, x, y, rank, width: labelWidth, height: labelHeight} of labels) {
      if ((marker.hasAttribute('data-extra-point') && !rank)
        || x < view.left || x > view.right || y < view.top || y > view.bottom) {
        marker.removeAttribute('data-label-placed');
        continue;
      }
      const padding = 4 / markerScale;
      let placed = false;
      for (const spacing of labelGaps) {
        const gap = spacing / markerScale;
        for (const [dx, dy] of labelDirections) {
          const left = x + dx * (gap + labelWidth / 2) - labelWidth / 2;
          const top = y + dy * (gap + labelHeight / 2) - labelHeight / 2;
          const box = {left: left - padding, right: left + labelWidth + padding,
            top: top - padding, bottom: top + labelHeight + padding};
          if (box.left < bounds.left || box.right > bounds.right || box.top < bounds.top || box.bottom > bounds.bottom
            || occupied.some(other => intersects(box, other)) || segments.some(segment => coversSegment(box, segment))) continue;
          const labelX = `${(left - x) * markerScale}px`;
          const labelY = `${(top - y) * markerScale}px`;
          if (marker.style.getPropertyValue('--label-x') !== labelX) marker.style.setProperty('--label-x', labelX);
          if (marker.style.getPropertyValue('--label-y') !== labelY) marker.style.setProperty('--label-y', labelY);
          occupied.push(box);
          placed = true;
          break;
        }
        if (placed) break;
      }
      marker.toggleAttribute('data-label-placed', placed);
    }
  };
})();
