(() => {
  const atlas = document.querySelector('.spread .atlas');
  const map = atlas.querySelector('.map-figure');
  const readingColumn = atlas.parentElement.querySelector('.reading');
  const readingScale = atlas.querySelector('.atlas-scale');
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const mobile = matchMedia('(max-width: 750px)');
  const mapFlow = new URLSearchParams(location.search).get('map-flow') ?? 'compact';
  if (mapFlow === 'compact' || mapFlow === 'float') document.documentElement.dataset.atlasFlow = mapFlow;
  const radians = Math.PI / 180;
  const earthRadius = 6378137;
  const cornerIcon = '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" aria-hidden="true"><path d="M2.5 7V2.5H7m2 11H13.5V9" stroke="currentColor" stroke-width=".65"/></svg>';
  const dayRoutes = {
    1: ['新千歳空港 国内線ターミナル', '定山源泉公園', '札幌駅', 'プレミアホテル 中島公園 札幌', 'すすきの駅'],
    2: ['白糸の滝 バス停 定山渓', 'もいわ山ロープウェイ 山麓駅', '中国料理 布袋 赤れんがテラス店', '北海道大学総合博物館', '一粒庵 札幌'],
  };
  const extraDays = new Map(window.folioExtraDays.map(day => [String(day.day), day]));

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  }

  function button(className, label) {
    const node = element('button', className);
    node.type = 'button';
    node.setAttribute('aria-label', label);
    return node;
  }

  function googleLink(className) {
    const node = element('a', `atlas-google ${className}`, 'Google Maps');
    node.target = '_blank';
    node.rel = 'noopener';
    return node;
  }

  function showMapGuide(pin, context, trigger) {
    document.dispatchEvent(new CustomEvent('folio:map-guide', {detail: {pin, context, trigger}}));
  }

  function routeHref(day) {
    const [origin, destination, ...waypoints] = dayRoutes[day] ?? extraDays.get(day).route;
    const parameters = new URLSearchParams({api: '1', origin, destination, waypoints: waypoints.join('|')});
    return `https://www.google.com/maps/dir/?${parameters}`;
  }

  function expandButton(label) {
    const node = button('atlas-corner atlas-expand', label);
    node.innerHTML = cornerIcon;
    node.title = label;
    node.setAttribute('aria-haspopup', 'dialog');
    node.setAttribute('aria-expanded', 'false');
    return node;
  }

  function paintScale(node, pixelsPerMeter, maxWidth = 87) {
    if (!pixelsPerMeter) return;
    const maxDistance = maxWidth / pixelsPerMeter;
    const magnitude = 10 ** Math.floor(Math.log10(maxDistance));
    const distance = [5, 2, 1].map(step => step * magnitude).find(step => step <= maxDistance);
    const label = distance >= 1000 ? `${distance / 1000} km` : `${distance} m`;
    if (node.textContent !== label) {
      node.textContent = label;
      node.setAttribute('aria-label', `地圖比例尺，${label}`);
    }
    node.style.setProperty('--atlas-scale-width', `${distance * pixelsPerMeter}px`);
  }

  function paintOverviewScale(node, width, zoom, centerY = 310, scope = atlas) {
    const frame = window.folioMapFrame(scope.dataset.day, scope.dataset.mapFrame);
    const units = frame.pixelsPerDegree / radians;
    const mercatorY = frame.north * radians - centerY / units;
    const latitude = Math.atan(Math.sinh(mercatorY));
    const pixelsPerMeter = width * zoom * units / (640 * earthRadius * Math.cos(latitude));
    paintScale(node, pixelsPerMeter);
  }

  function markerFor(scope, point) {
    return [...scope.querySelectorAll('.route-dot[data-visible-day]')].find(marker => marker.dataset.pointId === point);
  }

  function markerPosition(marker) {
    return ['--x', '--y'].map(name => parseFloat(marker.style.getPropertyValue(name)) / 100);
  }

  const smallScene = element('div', 'atlas-map-scene atlas-overview-scene');
  const smallViewport = element('div', 'atlas-map-window');
  smallScene.append(...map.children);
  smallViewport.append(smallScene);
  map.append(smallViewport);

  const datePicker = atlas.querySelector('.atlas-date-picker');
  const dateToggle = datePicker.querySelector('button');
  const dateMenu = datePicker.querySelector('nav');
  const atlasMeta = atlas.querySelector('.atlas-route-meta');
  const dateViewport = window.visualViewport;
  let dateMenuOpen = false;
  let resumeCompact;
  let compactScale = 1;
  let compactMoving = false;
  let compactMarkers;
  let overviewWidth = 0;

  function revealDateMenu() {
    if (!dateMenuOpen) return;
    const viewportBottom = dateViewport ? dateViewport.offsetTop + dateViewport.height : innerHeight;
    let menuBottom = dateMenu.getBoundingClientRect().bottom;
    if (mobile.matches) {
      const listHeight = dateMenu.scrollHeight;
      dateMenu.style.setProperty('--atlas-date-list-height', `${listHeight}px`);
      const visibleHeight = Math.min(listHeight, innerHeight * .4);
      menuBottom = dateMenu.getBoundingClientRect().top + visibleHeight;
    }
    const overflow = Math.ceil(menuBottom - viewportBottom + 8);
    if (overflow > 0) atlas.setAttribute('data-date-revealing', '');
    if (atlas.hasAttribute('data-date-revealing')) {
      // A pinned map needs room to move with the page as it scrolls.
      atlas.style.setProperty('--atlas-date-top', `${atlas.getBoundingClientRect().top - overflow}px`);
    }
    if (overflow > 0) scrollBy({top: overflow, behavior: reducedMotion.matches ? 'instant' : 'smooth'});
  }

  function setDateMenu(open) {
    if (open === dateMenuOpen) return;
    if (!open) {
      // Keep the outgoing date visible until its fade ends, even if scrolling changes the day.
      for (const link of dateMenu.querySelectorAll('a')) {
        link.toggleAttribute('data-fade-current', link.getAttribute('aria-current') === 'date');
      }
      if (dateMenu.contains(document.activeElement)) dateToggle.focus({preventScroll: true});
      atlas.removeAttribute('data-date-revealing');
      atlas.style.removeProperty('--atlas-date-top');
      scheduleReading();
    }
    dateMenuOpen = open;
    atlas.toggleAttribute('data-mobile-date-open', open && mobile.matches);
    dateToggle.setAttribute('aria-expanded', String(open));
    dateMenu.inert = !open;
    resumeCompact?.();
    if (open) {
      dateMenu.scrollTop = 0;
      revealDateMenu();
    }
  }

  dateToggle.addEventListener('click', () => setDateMenu(!dateMenuOpen));
  dateMenu.addEventListener('click', event => {
    if (event.target.closest('a')) setDateMenu(false);
  });
  datePicker.addEventListener('keydown', event => {
    if (event.key === 'Escape') setDateMenu(false);
  });
  document.addEventListener('click', event => {
    if (!datePicker.contains(event.target)) setDateMenu(false);
  });
  addEventListener('resize', revealDateMenu);
  dateViewport?.addEventListener('resize', revealDateMenu);

  let selectedPlace;
  function paintReadingScale() {
    if (compactMoving) return;
    const marker = selectedPlace && markerFor(atlas, selectedPlace.point);
    const centerY = marker ? markerPosition(marker)[1] * 620 : 310;
    paintOverviewScale(readingScale, (overviewWidth || map.clientWidth) * compactScale, marker ? 1.34 : 1, centerY);
  }

  new ResizeObserver(([entry]) => {
    overviewWidth = entry.contentRect.width;
    paintReadingScale();
    scheduleMapLabels();
    if (mobile.matches) scheduleReading();
  }).observe(smallViewport);

  function syncReadingOffset() {
    if (!mobile.matches || compactMoving) return;
    const metaHeight = atlasMeta.offsetHeight + parseFloat(getComputedStyle(atlasMeta).marginTop);
    const extraMenuHeight = Math.max(0, dateMenu.offsetHeight - metaHeight);
    const offset = `${atlas.offsetHeight - extraMenuHeight}px`;
    if (readingColumn.style.getPropertyValue('--atlas-mobile-reading-offset') !== offset) {
      readingColumn.style.setProperty('--atlas-mobile-reading-offset', offset);
    }
  }
  new ResizeObserver(syncReadingOffset).observe(atlas);

  function focusReading(marker) {
    const {pointId: point, mapDay: day, mapFrame = 'local'} = marker.dataset;
    paintAtlasDay(atlas, day, mapFrame);
    paintAtlasPoint(atlas, point, marker.hash.slice(1));
    atlas.querySelector('#map-date').textContent = `11 / ${10 + Number(day)}`;
    for (const link of atlas.querySelectorAll('.atlas-foot nav a')) {
      if (link.hash === `#day-${day}`) link.setAttribute('aria-current', 'date');
      else link.removeAttribute('aria-current');
    }
    selectedPlace = {point, day, mapFrame};
    const [x, y] = markerPosition(marker);
    smallScene.style.setProperty('--atlas-small-x', `${(0.5 - x) * 134}%`);
    smallScene.style.setProperty('--atlas-small-y', `${(0.5 - y) * 134}%`);
    smallScene.style.setProperty('--atlas-small-scale', '1.34');
    paintReadingScale();
  }

  function refreshCompactMarkers() {
    compactMarkers = smallScene.querySelectorAll('.route-dot[data-visible-day]');
    const scale = compactScale.toFixed(5);
    for (const marker of compactMarkers) marker.style.setProperty('--atlas-compact-scale', scale);
  }

  new MutationObserver(() => {
    if (mapFlow === 'compact' && mobile.matches) refreshCompactMarkers();
    paintReadingGoogle();
    paintReadingScale();
    scheduleMapLabels();
    if (!selectedPlace || (atlas.dataset.day === selectedPlace.day && atlas.dataset.point === selectedPlace.point
      && atlas.dataset.mapFrame === selectedPlace.mapFrame)) return;
    selectedPlace = undefined;
    smallScene.style.removeProperty('--atlas-small-x');
    smallScene.style.removeProperty('--atlas-small-y');
    smallScene.style.removeProperty('--atlas-small-scale');
    paintReadingScale();
  }).observe(atlas, {attributes: true, attributeFilter: ['data-day', 'data-point', 'data-map-frame']});

  for (const marker of smallScene.querySelectorAll('.route-dot')) {
    marker.setAttribute('aria-haspopup', 'dialog');
    marker.addEventListener('click', event => {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      focusReading(marker);
      const {mapDay: day, mapFrame = 'local', pointId} = marker.dataset;
      const context = overviewContext(day, mapFrame, marker.hash.slice(1));
      const pin = context.points.find(place => place.id === pointId);
      if (pin) showMapGuide(pin, context, marker);
    });
  }

  const expand = expandButton('展開沿途地圖');
  const overviewGoogle = googleLink('atlas-overview-google');
  map.append(overviewGoogle, expand);
  function paintReadingGoogle() {
    overviewGoogle.href = routeHref(atlas.dataset.day);
    const dayOfMonth = 10 + Number(atlas.dataset.day);
    overviewGoogle.setAttribute('aria-label', `在 Google Maps 開啟 11 月 ${dayOfMonth} 日路線`);
    dateToggle.setAttribute('aria-label', `11 月 ${dayOfMonth} 日，切換閱讀日期`);
  }
  paintReadingGoogle();

  const dialog = element('dialog', 'atlas-expanded');
  dialog.setAttribute('aria-label', '沿途地圖');
  dialog.setAttribute('aria-describedby', 'atlas-credit');
  const surface = element('div', 'atlas-expanded-surface');
  const largeScope = element('div', 'atlas atlas-expanded-viewport folio-tile-map');
  largeScope.tabIndex = 0;
  largeScope.setAttribute('role', 'region');
  largeScope.setAttribute('aria-label', '拖曳移動地圖，使用方向鍵或加減鍵');
  const heading = element('div', 'atlas-expanded-heading');
  const expandedTitle = element('h2', '', '沿途地圖');
  const expandedPlace = element('span', 'atlas-expanded-place');
  expandedPlace.setAttribute('role', 'status');
  heading.append(expandedTitle, expandedPlace);
  const zoomControls = element('div', 'atlas-expanded-controls');
  const smaller = button('atlas-zoom', '縮小地圖');
  const larger = button('atlas-zoom', '放大地圖');
  smaller.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10"/></svg>';
  larger.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h10m-5-5v10"/></svg>';
  const reset = button('atlas-expanded-reset', '回到全圖');
  reset.textContent = '全圖';
  const viewToggle = button('atlas-expanded-reset', '切換洞爺湖地圖範圍');
  viewToggle.hidden = true;
  const expandedGoogle = googleLink('atlas-expanded-google');
  zoomControls.append(viewToggle, expandedGoogle, smaller, larger, reset);
  const expandedScale = element('span', 'atlas-scale atlas-expanded-scale');
  expandedScale.setAttribute('role', 'img');
  const expandedLegend = element('div', 'atlas-expanded-route-key');
  expandedLegend.setAttribute('aria-label', '路線圖例');
  const expandedKey = element('div', 'atlas-expanded-map-key');
  expandedKey.append(expandedScale, expandedLegend);
  surface.append(largeScope, heading, zoomControls, expandedKey);
  const fold = button('atlas-corner atlas-fold', '收合沿途地圖');
  fold.innerHTML = cornerIcon;
  fold.title = '收合沿途地圖';
  dialog.append(surface, fold);
  document.body.append(dialog);

  let labelFrame = 0;
  function scheduleMapLabels() {
    if (labelFrame) return;
    labelFrame = requestAnimationFrame(() => {
      labelFrame = 0;
      if (!dialog.open && !compactMoving) window.folioPlaceMapLabels(smallScene, smallViewport, [overviewGoogle, expand], compactScale);
    });
  }

  for (const event of ['pointerover', 'pointerout', 'focusin', 'focusout']) {
    smallScene.addEventListener(event, scheduleMapLabels);
  }
  smallScene.addEventListener('transitionend', event => {
    if (event.target === smallScene && event.propertyName === 'transform') scheduleMapLabels();
  });
  document.fonts.ready.then(scheduleMapLabels);
  document.fonts.addEventListener('loadingdone', scheduleMapLabels);
  dialog.addEventListener('close', scheduleMapLabels);

  let closing = false;
  let opener;
  let showingDetail = false;
  let expandedTileMap;
  let expandedContext;
  function setZoomButtons(tileMap, minus, plus) {
    minus.disabled = tileMap.zoomLevel <= tileMap.minimumZoom;
    plus.disabled = tileMap.zoomLevel >= tileMap.maximumZoom;
  }

  function createExpandedTileMap() {
    return window.createFolioTileMap(largeScope, {
      onSelect(pin, trigger) {
        if (showingDetail) {
          localMap.select(pin.id, false);
          showMapGuide(pin, {...localMap.context, scope: 'expanded'}, trigger);
        } else {
          paintAtlasPoint(largeScope, pin.id, pin.entry);
          expandedTileMap.paintRouteSelection(pin.entry, pin.id);
          expandedPlace.textContent = pin.label;
          showMapGuide(pin, {...expandedContext, routeEntry: pin.entry}, trigger);
        }
      },
      onView(map) {
        if (!expandedTileMap) return;
        setZoomButtons(expandedTileMap, smaller, larger);
        const [left, right] = [0, 100].map(x => map.containerPointToLatLng([x, 0]));
        paintScale(expandedScale, 100 / map.distance(left, right));
      },
    });
  }

  function framePosition(frame, x, y) {
    const mercatorY = frame.north - y / frame.pixelsPerDegree;
    return [
      Math.atan(Math.sinh(mercatorY * radians)) / radians,
      frame.west + x / frame.pixelsPerDegree,
    ];
  }

  function frameBounds(frame) {
    return [framePosition(frame, 0, 620), framePosition(frame, 640, 0)];
  }

  function overviewContext(day, frame, routeEntry) {
    const frameData = window.folioMapFrame(day, frame);
    const points = [...smallScene.querySelectorAll('.route-dot')].filter(marker =>
      marker.dataset.mapDay === day && (!marker.dataset.mapFrame || marker.dataset.mapFrame === frame))
      .map(marker => {
        const id = marker.dataset.pointId;
        const [x, y] = markerPosition(marker);
        const stop = extraDays.get(day)?.stops.find(place => place.key === id);
        const position = stop ? [stop.lat, stop.lng] : framePosition(frameData, x * 640, y * 620);
        return {
          id, label: marker.textContent, entry: marker.hash.slice(1),
          position, query: position.join(','),
        };
      });
    const routes = (window.folioRoutes?.[day] ?? []).filter(route => day !== '6' || frame === 'regional' || route.mode !== 'rail');
    const bounds = frameBounds(frameData);
    const base = [...smallScene.querySelectorAll('.atlas-base')].find(image =>
      (image.dataset.mapDay === day && (!image.dataset.mapFrame || image.dataset.mapFrame === frame))
      || (Number(day) <= 2 && image.classList.contains('atlas-legacy-base')));
    const image = base && {src: base.currentSrc || base.src, bounds};
    return {day: Number(day), routeEntry, points, routes, bounds, image, scope: 'overview'};
  }

  function paintLargeRoute(day, frame, point, entry) {
    paintAtlasDay(largeScope, day, frame);
    const shownPoint = entry === 'd6-station-return'
      ? (frame === 'regional' ? 'd6-sapporo' : 'd6-station') : point;
    paintAtlasPoint(largeScope, shownPoint, entry);
    expandedContext = overviewContext(day, frame, entry);
    const {points, routes, bounds, image} = expandedContext;
    expandedPlace.textContent = points.find(pin => pin.id === shownPoint)?.label ?? '';
    expandedTileMap.setData({points, routes, active: shownPoint, entry, point: shownPoint, bounds, image});
    window.folioTileLegend(expandedLegend, routes);
    viewToggle.textContent = frame === 'regional' ? '洞爺湖' : '往返全程';
    viewToggle.setAttribute('aria-label', frame === 'regional' ? '查看洞爺湖周邊' : '查看札幌與洞爺湖往返全程');
  }

  viewToggle.addEventListener('click', () => {
    const {day, mapFrame, point, entry} = largeScope.dataset;
    paintLargeRoute(day, mapFrame === 'regional' ? 'local' : 'regional', point, entry);
  });

  function openMap(trigger, localMap) {
    if (dialog.open) return;
    opener = trigger;
    showingDetail = Boolean(localMap);
    dialog.dataset.mode = showingDetail ? 'detail' : 'overview';
    viewToggle.hidden = showingDetail || atlas.dataset.day !== '6';
    dialog.showModal();
    expandedTileMap ??= createExpandedTileMap();
    if (localMap) {
      expandedTileMap.setData(localMap.data);
      window.folioTileLegend(expandedLegend, localMap.data.routes);
      expandedTitle.textContent = localMap.name;
      expandedPlace.textContent = '';
      expandedGoogle.href = localMap.href;
      expandedGoogle.setAttribute('aria-label', `在 Google Maps 查看${localMap.name}`);
    } else {
      const {day, mapFrame, point, entry} = atlas.dataset;
      paintLargeRoute(day, mapFrame, point, entry);
      expandedTitle.textContent = '沿途地圖';
      expandedGoogle.href = routeHref(atlas.dataset.day);
      expandedGoogle.setAttribute('aria-label', overviewGoogle.getAttribute('aria-label'));
    }
    dialog.setAttribute('aria-label', expandedTitle.textContent);
    opener.setAttribute('aria-expanded', 'true');
    fold.focus({preventScroll: true});
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (!closing && dialog.open) dialog.dataset.revealed = 'true';
    }));
  }
  expand.addEventListener('click', () => openMap(expand));

  if (mapFlow === 'compact') {
    const spread = atlas.closest('.spread');
    const compactLimit = element('span', 'atlas-compact-limit');
    compactLimit.setAttribute('aria-hidden', 'true');
    map.append(compactLimit);
    let compactFrame = 0;
    let settleTimer = 0;
    let progress = 0;
    let target = 0;
    let lastPaint = 0;
    let spreadTop = 0;
    let artWidth = 0;
    let narrowScale = 1;

    function applyCompactScale() {
      const scale = compactScale.toFixed(5);
      for (const layer of [map, smallViewport, overviewGoogle, expand, ...compactMarkers]) {
        layer.style.setProperty('--atlas-compact-scale', scale);
      }
    }

    function settleCompactMap() {
      clearTimeout(settleTimer);
      settleTimer = 0;
      compactMoving = false;
      syncReadingOffset();
      paintReadingScale();
      scheduleMapLabels();
    }

    function measureCompact() {
      if (!mobile.matches) {
        const hadCompactScale = compactScale !== 1;
        progress = target = 0;
        compactScale = 1;
        lastPaint = 0;
        if (hadCompactScale) applyCompactScale();
        compactMarkers = undefined;
        if (hadCompactScale || compactMoving) settleCompactMap();
        return;
      }
      const width = smallViewport.clientWidth;
      if (!width) return;
      if (!compactMarkers) refreshCompactMarkers();
      spreadTop = spread.getBoundingClientRect().top + scrollY;
      narrowScale = Math.min(1, compactLimit.getBoundingClientRect().width / width);
      if (artWidth !== width) {
        artWidth = width;
        map.style.setProperty('--atlas-art-width', `${width}px`);
        map.style.setProperty('--atlas-art-height', `${width * 620 / 640}px`);
      }
      scheduleCompactMap();
    }

    function paintCompactMap(time) {
      compactFrame = 0;
      if (!mobile.matches) return;
      if (!dateMenuOpen) {
        const fraction = Math.min(1, Math.max(0, (scrollY - spreadTop - 22) / 310));
        // Keep the smallest size reached when the reader scrolls back up.
        target = Math.max(target, fraction * fraction * (3 - 2 * fraction));
        const elapsed = lastPaint ? Math.min(time - lastPaint, 80) : 16.7;
        progress = reducedMotion.matches ? target : target + (progress - target) * Math.exp(-elapsed / 62);
        if (target - progress < .004) progress = target;
      }
      const scale = 1 - progress * (1 - narrowScale);
      if (scale !== compactScale) {
        compactScale = scale;
        compactMoving = true;
        clearTimeout(settleTimer);
        settleTimer = 0;
        applyCompactScale();
      }
      if (!dateMenuOpen && progress !== target) {
        lastPaint = time;
        scheduleCompactMap();
      } else {
        lastPaint = 0;
        if (compactMoving && !settleTimer) settleTimer = setTimeout(settleCompactMap, 90);
      }
    }

    function scheduleCompactMap() {
      if (compactFrame) return;
      compactFrame = requestAnimationFrame(paintCompactMap);
    }
    resumeCompact = scheduleCompactMap;
    addEventListener('scroll', scheduleCompactMap, {passive: true});
    addEventListener('resize', measureCompact);
    mobile.addEventListener('change', measureCompact);
    reducedMotion.addEventListener('change', scheduleCompactMap);
    const compactMeasurements = new ResizeObserver(measureCompact);
    compactMeasurements.observe(document.querySelector('.folio-cover'));
    compactMeasurements.observe(smallViewport);
    measureCompact();
  }

  if (mapFlow === 'float') {
    const dock = expandButton('展開沿途地圖');
    dock.className = 'atlas-mobile-dock';
    dock.prepend('沿途地圖');
    dock.inert = true;
    dock.addEventListener('click', () => openMap(dock));
    document.body.append(dock);
    new IntersectionObserver(([entry]) => {
      const show = entry.boundingClientRect.bottom <= (entry.rootBounds?.top ?? 0);
      dock.toggleAttribute('data-visible', show);
      dock.inert = !show;
    }).observe(atlas);
  }

  async function closeMap() {
    if (!dialog.open || closing) return;
    closing = true;
    const wasRevealed = dialog.hasAttribute('data-revealed');
    delete dialog.dataset.revealed;
    if (wasRevealed && !reducedMotion.matches) await new Promise(resolve => setTimeout(resolve, 360));
    dialog.close();
    opener.setAttribute('aria-expanded', 'false');
    opener.focus({preventScroll: true});
    closing = false;
  }

  fold.addEventListener('click', closeMap);
  dialog.addEventListener('cancel', event => {
    event.preventDefault();
    closeMap();
  });
  smaller.addEventListener('click', () => expandedTileMap.zoom(-1));
  larger.addEventListener('click', () => expandedTileMap.zoom(1));
  reset.addEventListener('click', () => expandedTileMap.reset());
  const detail = document.querySelector('.detail');
  const detailMap = detail.querySelector('.detail-map');
  const detailMapWindow = detailMap.querySelector('.detail-map-window');
  const detailMapLabel = detailMap.querySelector('.detail-map-label');
  const detailPlaces = detailMap.querySelector('.detail-map-places');
  const detailGoogle = googleLink('atlas-detail-google');
  const detailExpand = expandButton('展開景點地圖');
  const detailControls = element('div', 'atlas-inline-controls');
  detailControls.setAttribute('role', 'group');
  detailControls.setAttribute('aria-label', '景點地圖控制');
  const detailSmaller = smaller.cloneNode(true);
  const detailLarger = larger.cloneNode(true);
  detailSmaller.setAttribute('aria-label', '縮小景點地圖');
  detailLarger.setAttribute('aria-label', '放大景點地圖');
  const detailReset = button('atlas-inline-reset', '景點地圖回到全圖');
  detailReset.textContent = '全圖';
  detailControls.append(detailSmaller, detailLarger, detailReset, detailExpand);
  const inlineContainer = element('div', 'folio-tile-map folio-tile-map-inline');
  inlineContainer.setAttribute('aria-label', '景點地圖');
  detailMapWindow.replaceChildren(inlineContainer);
  detailMap.querySelector('.detail-map-source').append(detailGoogle);
  detailMap.querySelector('.detail-map-art').append(detailControls);
  let localMap;
  let inlineTileMap;
  detailSmaller.addEventListener('click', () => inlineTileMap?.zoom(-1));
  detailLarger.addEventListener('click', () => inlineTileMap?.zoom(1));
  detailReset.addEventListener('click', () => inlineTileMap?.reset());
  detailExpand.addEventListener('click', () => {
    if (localMap) openMap(detailExpand, localMap);
  });

  const detailMaps = {
    food: {
      day: 1, entry: 'arrival', image: 'airport-wide', zoom: 16, bounds: [14990851, 6177783, 1420, 1000],
    },
    park: {
      day: 1, entry: 'valley', mode: 'walk', image: 'jozankei', zoom: 17, bounds: [29933716, 12333654, 1300, 740],
      fitRoutes: false,
      places: [
        ['定山源泉公園', [42.964889, 141.163139], '定山源泉公園'],
        ['溫泉蛋之泉', [42.965047, 141.162987], 'おんたまの湯 定山渓'],
        ['二見吊橋', [42.963909, 141.158148], '二見吊橋 定山渓'],
      ],
    },
    moiwa: {
      day: 2, entry: 'night', mode: 'ropeway', image: 'moiwa', zoom: 16, bounds: [14974234, 6162574, 1440, 1000],
      places: [
        ['山頂展望台', [43.0222893, 141.3224861], '藻岩山 山頂展望台'],
        ['山麓站', [43.0315385, 141.3330663], 'もいわ山ロープウェイ 山麓駅'],
        ['中腹站', [43.0222204, 141.3255123], 'もいわ山ロープウェイ 中腹駅'],
      ],
    },
  };

  function entryRoutes(day, entry, mode) {
    return (window.folioRoutes?.[day] ?? []).filter(route =>
      route.entry === entry && (!mode || route.mode === mode));
  }

  function detailImage({image, zoom, bounds: [left, top, width, height]}) {
    const {EPSG3857} = window.L.CRS;
    return {
      src: 'detail-' + image + '.webp',
      bounds: [
        EPSG3857.pointToLatLng(window.L.point(left, top + height), zoom),
        EPSG3857.pointToLatLng(window.L.point(left + width, top), zoom),
      ],
    };
  }

  function extraDetailMap({day, entry, places, routeEntry = entry.id}) {
    const routes = entryRoutes(day.day, routeEntry);
    if (!places?.length) {
      const stops = day.stops ?? [];
      const origin = stops.find(stop => stop.key === entry.point);
      if (origin) {
        const center = window.L.latLng(origin.lat, origin.lng);
        const nearby = stops.filter(stop => stop !== origin).map(stop => ({
          stop, distance: center.distanceTo([stop.lat, stop.lng]),
        })).filter(({distance}) => distance <= 1600).sort((a, b) => a.distance - b.distance).slice(0, 5);
        places = [origin, ...nearby.map(({stop}) => stop)].map(stop => [stop.name, [stop.lat, stop.lng]]);
      } else if (routes.length) {
        const [lng, lat] = routes.at(-1).coords.at(-1);
        places = [[entry.title, [lat, lng]]];
      }
    }
    const regional = day.day === 6 && /^d6-station-(start|return)$/.test(entry.id);
    const frame = window.folioMapFrame(String(day.day), regional ? 'regional' : 'local');
    const src = regional ? 'maps/toya-region.webp' : day.mapFrame?.src ?? 'atlas.svg';
    return {day: day.day, entryId: entry.id, places, routes, routeEntry, fallback: {src, bounds: frameBounds(frame)}};
  }

  function buildDetailMap({day, routeEntry, entryId = routeEntry, places, routes, fallback, fitRoutes}) {
    detailMap.hidden = !places?.length;
    if (!places?.length) {
      localMap = undefined;
      return;
    }
    inlineTileMap ??= window.createFolioTileMap(inlineContainer, {
      inline: true,
      onSelect(pin, trigger) {
        localMap.select(pin.id, false);
        showMapGuide(pin, localMap.context, trigger);
      },
      onView() {
        if (inlineTileMap) setZoomButtons(inlineTileMap, detailSmaller, detailLarger);
      },
    });
    const points = places.map(([label, position, query], id) => ({label, position, query, id, entry: entryId}));
    const data = {points, routes, active: 0, entry: routeEntry, image: fallback};
    if (fitRoutes === false) data.bounds = points.map(point => point.position);
    const context = {day: Number(day), routeEntry, points, routes, image: fallback,
      scope: 'inline', detailKey: detail.dataset.detailKey};
    localMap = {data, context, select: activate};
    const locationButtons = points.map(pin => {
      const node = button('atlas-detail-place', '在小地圖定位' + pin.label);
      node.textContent = pin.label;
      node.addEventListener('click', () => activate(pin.id));
      return node;
    });
    detailPlaces.replaceChildren(...locationButtons);
    inlineTileMap.setData(data);
    activate(0, false);

    function activate(id, center = true) {
      const pin = points[id];
      localMap.data.active = id;
      localMap.name = pin.label;
      const query = pin.query ?? pin.position.join(',');
      localMap.href = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(query);
      detailMapLabel.textContent = pin.label;
      detailGoogle.href = localMap.href;
      detailGoogle.setAttribute('aria-label', '在 Google Maps 查看' + pin.label);
      locationButtons.forEach((node, index) => node.setAttribute('aria-pressed', String(index === id)));
      inlineTileMap.select(pin, {center, notify: false});
      if (dialog.open && showingDetail) {
        expandedTitle.textContent = pin.label;
        expandedGoogle.href = localMap.href;
        expandedGoogle.setAttribute('aria-label', '在 Google Maps 查看' + pin.label);
      }
    }
  }

  new MutationObserver(() => {
    if (!detail.open) return;
    const key = detail.dataset.detailKey;
    const definition = detailMaps[key];
    const context = window.folioExtraDetails.get(key);
    if (definition) buildDetailMap({
      day: definition.day,
      places: context?.places ?? definition.places,
      routes: entryRoutes(definition.day, definition.entry, definition.mode),
      routeEntry: definition.entry,
      fallback: detailImage(definition),
      fitRoutes: definition.fitRoutes,
    });
    else if (context) buildDetailMap(extraDetailMap(context));
  }).observe(detail, {attributes: true, attributeFilter: ['open']});
})();
