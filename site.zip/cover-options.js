{
  const cover = document.querySelector('.cover-image');
  const primary = cover.querySelector('img');
  const overlap = document.createElement('figure');
  const companion = new Image();
  overlap.className = 'folio-extra-photo';
  companion.loading = 'lazy';
  companion.width = 320;
  companion.height = 405;
  overlap.append(companion);
  cover.append(overlap);

  function syncCompanion() {
    const source = primary.getAttribute('src');
    if (selectedChapter >= 2) {
      const photos = chapters[selectedChapter];
      [companion.src, companion.alt] = photos[(selectedPhoto + 1) % photos.length];
    } else if (source.endsWith('moiwa.jpg') || source.endsWith('hokudai-furukawa.jpg')) {
      companion.src = 'photos/hokudai.jpg';
      companion.alt = '北海道大學的銀杏大道';
    } else if (source.endsWith('hokudai.jpg')) {
      companion.src = 'photos/moiwa.jpg';
      companion.alt = '從藻岩山俯瞰札幌夜景';
    } else if (source.endsWith('jozankei-river.jpg')) {
      companion.src = 'assets/jozankei.jpg';
      companion.alt = '定山溪溫泉區的二見吊橋';
    } else {
      companion.src = 'photos/jozankei-river.jpg';
      companion.alt = '定山溪林間步道與秋葉';
    }
  }

  syncCompanion();
  new MutationObserver(syncCompanion).observe(primary, { attributeFilter: ['src'] });
}
