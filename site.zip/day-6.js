const day6LakePhoto = ['photos/d6-toyako.jpg', '從高處俯瞰洞爺湖溫泉街與昭和新山', '52%'];
const day6UsuzanPhoto = ['photos/d6-usuzan.jpg', '從有珠山纜車眺望洞爺湖', '49%'];
const day6ShowaPhoto = ['photos/d6-showashinzan.jpg', '昭和新山的火山岩峰與秋景', '46%'];

(window.folioExtraDays ??= []).push({
  day: 6,
  name: '洞爺湖・有珠山',
  title: '從湖畔到有珠山',
  intro: '搭早班北斗到洞爺，先在虻田神社參拜，再逛溫泉街、搭纜車上有珠山。午餐後到萬世閣泡湯，傍晚等光之隧道點燈，吃過晚餐再搭北斗回札幌。',
  photos: [day6LakePhoto, day6UsuzanPhoto, day6ShowaPhoto],
  credits: [
    {
      label: '洞爺湖與昭和新山，由 663highland 攝影，縮小、裁切顯示',
      url: 'https://commons.wikimedia.org/wiki/File:130921_Toyako_Onsen_Toyako_Hokkaido_Japan00s.jpg',
      license: 'CC BY 2.5',
      licenseUrl: 'https://creativecommons.org/licenses/by/2.5/',
    },
    {
      label: '有珠山纜車視野，由 Miyuki Meinaka 攝影，裁切顯示',
      url: 'https://commons.wikimedia.org/wiki/File:The_View_from_Usuzan_Ropeway.jpg',
      license: '公有領域',
      licenseUrl: 'https://commons.wikimedia.org/wiki/File:The_View_from_Usuzan_Ropeway.jpg#Licensing',
    },
    {
      label: '昭和新山，由 Ray Swi-hymn 攝影，縮小、裁切顯示',
      url: 'https://commons.wikimedia.org/wiki/File:20181106_Showa_5319_(48429714361).jpg',
      license: 'CC BY-SA 2.0',
      licenseUrl: 'https://creativecommons.org/licenses/by-sa/2.0/',
    },
  ],
  stops: [
    {key: 'd6-station', name: 'JR 洞爺站', lat: 42.550741, lng: 140.763735, entry: 'd6-station-start'},
    {key: 'd6-shrine', name: '虻田神社', lat: 42.553974, lng: 140.762653, entry: 'd6-shrine-visit'},
    {key: 'd6-terminal', name: '洞爺湖溫泉巴士總站', lat: 42.564364, lng: 140.817666, entry: 'd6-onsen-bus'},
    {key: 'd6-wakasaimo', name: '若狹芋本店', lat: 42.565433, lng: 140.815725, entry: 'd6-sweets'},
    {key: 'd6-yakushi', name: '湯前藥師如來堂', lat: 42.564602, lng: 140.823323, entry: 'd6-yakushi-visit'},
    {key: 'd6-echigoya', name: '洞爺湖越後屋', lat: 42.565325, lng: 140.824606, entry: 'd6-wooden-sword'},
    {key: 'd6-usuzan', name: '有珠山纜車山麓站', lat: 42.538936, lng: 140.860520, entry: 'd6-ropeway'},
    {key: 'd6-gyusuke', name: '牛助 Gyusuke', lat: 42.565159, lng: 140.813463, entry: 'd6-lunch'},
    {key: 'd6-manseikaku', name: '洞爺湖萬世閣', lat: 42.565819, lng: 140.824675, entry: 'd6-bath'},
    {key: 'd6-tunnel', name: '光之隧道', lat: 42.565147, lng: 140.824641, entry: 'd6-illumination'},
    {key: 'd6-boyotei', name: '望羊蹄', lat: 42.565116, lng: 140.819033, entry: 'd6-dinner'},
  ],
  route: ['洞爺駅 北海道洞爺湖町', '洞爺駅 北海道洞爺湖町', '虻田神社', '有珠山ロープウェイ 山麓駅', '洞爺湖温泉 イルミネーショントンネル'],
  entries: [
    {
      id: 'd6-station-start', point: 'd6-station', time: '06:53 ∼ 08:43', title: '搭北斗前往洞爺',
      text: '06:53 從札幌站搭北斗 4 號，08:43 抵達 JR 洞爺站。',
      links: [['JR 北海道｜北斗時刻表', 'https://www.jrhokkaido.co.jp/CM/Info/press/pdf/20251212_KO_kaisei.pdf']],
    },
    {
      id: 'd6-shrine-visit', point: 'd6-shrine', time: '09:00 ∼ 09:20', title: '虻田神社參拜',
      text: '08:43 抵達後步行前往神社。09:00 社務所開門，參拜、購買御守並領御朱印。09:20 步行回站，09:35 至 09:55 留作候車。',
      links: [['虻田神社｜社務所時間', 'https://abutajinja.holy.jp/']],
    },
    {
      id: 'd6-onsen-bus', point: 'd6-terminal', time: '09:55 ∼ 10:13', title: '進洞爺湖溫泉街',
      text: '從 JR 洞爺站前搭道南巴士，在洞爺湖溫泉下車。成人車資 ¥400。10:13 至 10:20 步行往若狹芋本店。',
      links: [['道南巴士｜洞爺站前至洞爺湖溫泉', 'https://www.donanbus.co.jp/map/toyako_toyakoonsen/']],
    },
    {
      id: 'd6-sweets', point: 'd6-wakasaimo', time: '10:20 ∼ 10:32', title: '若狹芋本店',
      text: '預留 12 分鐘買若狹芋等洞爺湖點心。10:32 至 10:42 步行到湯前藥師如來堂。',
      links: [['若狹芋本舖｜官方網站', 'https://www.wakasaimo.com/']],
    },
    {
      id: 'd6-yakushi-visit', point: 'd6-yakushi', time: '10:42 ∼ 10:48', title: '湯前藥師如來堂',
      text: '停留 6 分鐘，到湯前藥師如來堂及お湯掛け地蔵參拜。10:48 至 10:53 步行前往越後屋。',
      links: [['洞爺湖溫泉觀光協會｜溫泉街地圖', 'https://www.laketoya.com/toyawp/wp-content/uploads/2025/11/bdfe0d7f666712585decdf991d3bc4e8.pdf']],
    },
    {
      id: 'd6-wooden-sword', point: 'd6-echigoya', time: '10:53 ∼ 11:08', title: '越後屋挑木刀',
      text: '在洞爺湖越後屋預留 15 分鐘選購木刀。11:08 至 11:12 步行到元町站，留 10 分鐘候車。11:22 搭道南巴士，11:33 抵達昭和新山。',
      links: [
        ['觀光協會｜越後屋及伴手禮', 'https://www.laketoya.com/en/shop/'],
        ['道南巴士｜元町至昭和新山', 'https://www.donanbus.co.jp/map/toyako_syowashinzan/'],
      ],
    },
    {
      id: 'd6-ropeway', point: 'd6-usuzan', time: '11:33 ∼ 13:15', title: '有珠山纜車與展望台',
      text: '11:33 至 11:45 購票、候車。11:45 至 12:50 搭纜車往返，走洞爺湖展望台和 USU360。纜車成人往返 ¥2,000，單程約 6 分鐘。12:50 回山麓逛商店、休息及候車。',
      photo: day6UsuzanPhoto,
      links: [
        ['有珠山纜車｜票價與運行', 'https://usuzan.hokkaido.jp/ja/'],
        ['洞爺湖有珠山地質公園｜山頂步道', 'https://www.toya-usu-geopark.org/trail/panorama'],
      ],
    },
    {
      id: 'd6-lunch', point: 'd6-gyusuke', time: '13:40 ∼ 14:45', title: '牛助吃燒肉',
      text: '13:15 搭巴士下山，13:31 抵達溫泉街，再步行前往牛助。午餐留 65 分鐘，可點成吉思汗烤羊肉或燒肉。週一開店資料有 13:00 和 13:30 兩種版本，行程安排 13:40 到店，仍以店家當天營業及最後點餐時間為準。',
      links: [
        ['道南巴士｜昭和新山回溫泉街', 'https://www.donanbus.co.jp/map/toyako_syowashinzan2/'],
        ['洞爺湖溫泉觀光協會｜牛助', 'https://www.laketoya.com/restaurant/'],
      ],
    },
    {
      id: 'd6-bath', point: 'd6-manseikaku', time: '14:55 ∼ 16:45', title: '萬世閣日歸溫泉',
      text: '14:45 離開牛助，步行約 10 分鐘到萬世閣，留 110 分鐘泡湯。平日成人 ¥1,200，毛巾組另租 ¥400。下午場 13:00 至 21:00，最晚 20:00 受理。',
      links: [['洞爺湖萬世閣｜日歸入浴', 'https://www.toyamanseikaku.jp/day/']],
    },
    {
      id: 'd6-illumination', point: 'd6-tunnel', time: '17:00 ∼ 17:25', title: '光之隧道點燈',
      text: '16:45 離開萬世閣，約 16:50 到光之隧道等候。17:00 點燈後逛隧道、拍照，17:25 至 17:35 步行去望羊蹄。',
      links: [['洞爺湖溫泉觀光協會｜光之隧道', 'https://www.laketoya.com/event/illumination/']],
    },
    {
      id: 'd6-dinner', point: 'd6-boyotei', time: '17:35 ∼ 18:30', title: '望羊蹄晚餐',
      text: '預留 55 分鐘吃望羊蹄的洋食。18:30 離店，步行回巴士總站並候車。',
      links: [['望羊蹄｜店家公告與菜單', 'https://boyotei.sakura.ne.jp/announce.html']],
    },
    {
      id: 'd6-station-return', point: 'd6-station', time: '18:50 ∼ 21:41', title: '搭北斗返回札幌',
      text: '18:50 從洞爺湖溫泉搭巴士，19:08 抵達 JR 洞爺站。候車後搭 19:47 北斗 19 號，21:41 抵達札幌。',
      links: [
        ['道南巴士｜洞爺湖溫泉回 JR 洞爺站', 'https://www.donanbus.co.jp/map/toyako_muroran/'],
        ['JR 北海道｜北斗時刻表', 'https://www.jrhokkaido.co.jp/CM/Info/press/pdf/20251212_KO_kaisei.pdf'],
      ],
    },
  ],
});
