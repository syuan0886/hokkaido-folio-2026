(() => {
  const list = document.querySelector('#guide-photo-credits');
  const notes = Object.values(window.folioGuideNotes ?? {}).flat();
  const photos = [window.folioGuidePhotos, window.folioMoreGuidePhotos, window.folioVenueGuidePhotos]
    .flatMap(collection => Object.values(collection ?? {}).flat());
  const seen = new Set();
  for (const {image, alt, photoSource, photoCredit, photoLicense} of [...notes, ...photos]) {
    if (!image || !photoSource || seen.has(image)) continue;
    seen.add(image);
    const row = document.createElement('li');
    const source = document.createElement('a');
    source.href = photoSource;
    source.textContent = alt || '照片原檔';
    row.append(source, ' — ' + photoCredit);
    const cc = /^CC (BY(?:-SA|-NC(?:-SA)?)?) (\d\.\d)$/i.exec(photoLicense ?? '');
    const licenseUrl = cc ? `https://creativecommons.org/licenses/${cc[1].toLowerCase()}/${cc[2]}/` : photoLicense;
    if (/^https?:\/\//i.test(licenseUrl ?? '')) {
      const license = document.createElement('a');
      license.href = licenseUrl;
      license.textContent = '授權';
      row.append(' · ', license);
    }
    list.append(row);
  }
})();
