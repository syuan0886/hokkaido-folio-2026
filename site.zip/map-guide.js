(() => {
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const dialog = document.createElement('dialog');
  dialog.className = 'map-guide';
  dialog.setAttribute('aria-labelledby', 'map-guide-title');
  dialog.innerHTML = `
    <figure class="map-guide-scene folio-photo-ink folio-detail-scene" aria-hidden="true"><img alt=""></figure>
    <svg class="map-guide-leader" aria-hidden="true"><path/><circle r="2.5"/></svg>
    <article class="map-guide-sheet">
      <div class="map-guide-content">
        <header class="map-guide-header">
          <h2 id="map-guide-title"></h2>
          <button type="button" class="map-guide-close" aria-label="關閉地點導引"><span aria-hidden="true"></span></button>
        </header>
        <div class="map-guide-media">
          <div class="map-guide-stage">
            <button type="button" class="map-guide-image folio-photo-button" aria-pressed="false"><span class="folio-photo-viewport"><img alt="" class="folio-photo-original"></span></button>
            <p class="map-guide-no-photo" hidden>本站尚未收錄可展示的現場照片</p>
            <div class="map-guide-pages" role="group" aria-label="切換導引"></div>
          </div>
          <figure class="map-guide-route">
            <span class="map-guide-route-paper"><img alt=""></span>
            <span class="map-guide-route-ink" aria-hidden="true"><img alt=""></span>
          </figure>
        </div>
        <div class="map-guide-copy" aria-live="polite" aria-atomic="true"></div>
      </div>
    </article>
    <template>
      <div class="map-guide-caption">
          <h3></h3><p></p>
          <div class="map-guide-references">
            <a class="map-guide-source" target="_blank" rel="noopener" hidden></a>
            <a class="map-guide-photo-source" target="_blank" rel="noopener" hidden></a>
            <span class="map-guide-credit" hidden></span>
          </div>
      </div>
    </template>`;
  document.body.append(dialog);

  const sheet = dialog.querySelector('.map-guide-sheet');
  const content = sheet.querySelector('.map-guide-content');
  const title = sheet.querySelector('h2');
  const leader = dialog.querySelector('.map-guide-leader');
  const scene = dialog.querySelector('.map-guide-scene');
  const image = sheet.querySelector('.map-guide-image');
  const viewport = image.querySelector('.folio-photo-viewport');
  const noPhoto = sheet.querySelector('.map-guide-no-photo');
  const route = sheet.querySelector('.map-guide-route-paper');
  const routeInk = sheet.querySelector('.map-guide-route-ink');
  const openClose = sheet.querySelector('.map-guide-close');
  const copy = sheet.querySelector('.map-guide-copy');
  const captionTemplate = dialog.querySelector('template');
  const pager = sheet.querySelector('.map-guide-pages');
  const clamp = (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value));
  const isDiagram = source => /(?:^data:image\/svg\+xml|\.svg(?:[?#]|$))/i.test(source || '');

  let slides = [];
  let decoded = [];
  let selected = 0;
  let request = 0;
  let selection = 0;
  let trigger;
  let anchor;
  let closeTimer;
  let outsidePointer = false;

  function positionSheet() {
    if (!dialog.open) return;
    const { width, height } = dialog.getBoundingClientRect();
    const bounds = sheet.getBoundingClientRect();
    const gutter = 14;
    const marker = trigger?.isConnected ? trigger.getBoundingClientRect() : anchor;
    const markerX = marker ? marker.left + marker.width / 2 : width / 2;
    const markerY = marker ? marker.top + marker.height / 2 : height / 2;
    const roomAbove = markerY - gutter;
    const roomBelow = height - markerY - gutter;
    const left = clamp(markerX - bounds.width / 2, gutter, width - bounds.width - gutter);
    const top = clamp(
      roomBelow >= roomAbove ? markerY + 24 : markerY - bounds.height - 24,
      gutter,
      height - bounds.height - gutter
    );
    sheet.style.left = `${left}px`;
    sheet.style.top = `${top}px`;
    if (scene.classList.contains('is-revealed')) positionInk();

    const outsideX = markerX < left || markerX > left + bounds.width;
    const outsideY = markerY < top || markerY > top + bounds.height;
    const edgeX = outsideY ? clamp(markerX, left + 20, left + bounds.width - 20) : clamp(markerX, left, left + bounds.width);
    const edgeY = clamp(markerY, top, top + bounds.height);
    leader.style.visibility = marker && (outsideX || outsideY) ? 'visible' : 'hidden';
    leader.querySelector('path').setAttribute('d', `M ${markerX} ${markerY} L ${edgeX} ${edgeY}`);
    const dot = leader.querySelector('circle');
    dot.setAttribute('cx', markerX);
    dot.setAttribute('cy', markerY);
  }

  function decode(source) {
    if (!source) return Promise.resolve(null);
    const picture = new Image();
    picture.src = source;
    return picture.decode().then(() => picture, () => null);
  }

  function showImage(frame, decodedImage, alt, animate) {
    const previous = frame.querySelector('img:not(.map-guide-outgoing)');
    const next = decodedImage ? decodedImage.cloneNode() : new Image();
    next.alt = alt || '';
    if (frame === viewport) next.className = 'folio-photo-original';
    if (previous?.getAttribute('src') === next.getAttribute('src')) {
      previous.alt = next.alt;
      return;
    }
    if (!animate || !decodedImage) {
      frame.replaceChildren(next);
      return;
    }

    const outgoing = [...frame.querySelectorAll('img')];
    if (previous) {
      previous.classList.add('map-guide-outgoing');
      previous.setAttribute('aria-hidden', 'true');
      previous.alt = '';
    }
    frame.append(next);
    const timing = { duration: 360, easing: 'cubic-bezier(.2,.65,.28,1)' };
    const removeOutgoing = () => outgoing.forEach(layer => layer.remove());
    next.animate([{ opacity: 0 }, { opacity: 1 }], timing).finished.then(removeOutgoing, removeOutgoing);
  }

  function showLink(link, url, label) {
    link.hidden = !/^https?:\/\//i.test(url || '');
    if (!link.hidden) {
      link.href = url;
      link.textContent = label;
    } else link.removeAttribute('href');
  }

  function setInked(inked) {
    if (inked) positionInk();
    dialog.classList.toggle('is-inked', inked);
    scene.classList.toggle('is-revealed', inked);
    image.setAttribute('aria-pressed', String(inked));
  }

  function positionInk() {
    const frame = dialog.getBoundingClientRect();
    const bounds = image.getBoundingClientRect();
    scene.style.setProperty('--photo-ink-x', `${bounds.left + bounds.width / 2 - frame.left}px`);
    scene.style.setProperty('--photo-ink-y', `${bounds.top + bounds.height / 2 - frame.top}px`);
  }

  function prepareSlide(slide) {
    const legacyDiagram = isDiagram(slide.src);
    const photo = decode(legacyDiagram ? undefined : slide.src);
    // Paint the guide before projecting routes or encoding their map images.
    const maps = new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))
      .then(() => slide.loadRoute?.() ?? slide)
      .then(({routeSrc, routeInkSrc}) => Promise.all([
        decode(routeSrc || (legacyDiagram ? slide.src : undefined)),
        decode(routeInkSrc),
      ]))
      .catch(() => [null, null]);
    return {photo, maps};
  }

  function showCaption(index) {
    for (const [page, button] of [...pager.children].entries()) {
      const current = page === index;
      button.setAttribute('aria-pressed', String(current));
      const caption = copy.children[page];
      caption.classList.toggle('is-current', current);
      caption.inert = !current;
    }
  }

  async function selectSlide(index, opening = false) {
    if (!slides.length) return;
    selected = (index + slides.length) % slides.length;
    const slide = slides[selected];
    const change = ++selection;
    const guide = request;
    const isCurrent = () => guide === request && change === selection;
    const assets = decoded[selected] ??= prepareSlide(slide);

    if (opening) showCaption(selected);
    const photo = await assets.photo;
    if (!isCurrent()) return;

    const animate = !motion.matches;
    image.hidden = !photo;
    noPhoto.hidden = !!photo;
    image.setAttribute('aria-label', `切換照片墨染：${slide.alt || slide.title}`);
    showImage(viewport, photo, slide.alt || slide.title, animate);
    showImage(scene, photo, '', animate);
    if (photo) image.style.setProperty('--photo-bloom', `url(${JSON.stringify(photo.src)})`);
    else setInked(false);
    if (!opening) showCaption(selected);
    showImage(route, null, '', false);
    showImage(routeInk, null, '', false);
    const [map, inkMap] = await assets.maps;
    if (!isCurrent()) return;
    showImage(route, map, slide.routeAlt || `${slide.title}的動線圖`, animate);
    showImage(routeInk, inkMap ?? map, '', animate);
  }

  function makeCaption(slide) {
    const caption = captionTemplate.content.firstElementChild.cloneNode(true);
    const photoSource = !isDiagram(slide.src) && slide.src;
    caption.inert = true;
    caption.querySelector('h3').textContent = slide.title;
    caption.querySelector('p').textContent = slide.description || slide.text || '';
    showLink(caption.querySelector('.map-guide-source'), slide.source, slide.sourceLabel || '官方資料');
    const photoLink = caption.querySelector('.map-guide-photo-source');
    const credit = caption.querySelector('.map-guide-credit');
    showLink(photoLink, photoSource && slide.photoSource, slide.photoCredit || '照片來源');
    credit.hidden = !photoSource || !slide.photoCredit || !photoLink.hidden;
    credit.textContent = slide.photoCredit || '';
    return caption;
  }

  function closeGuide() {
    if (!dialog.open || dialog.classList.contains('is-closing')) return;
    ++request;
    dialog.classList.add('is-closing');
    closeTimer = window.setTimeout(() => {
      dialog.close();
      if (trigger?.isConnected) trigger.focus({ preventScroll: true });
      trigger = undefined;
    }, motion.matches ? 0 : 220);
  }

  document.addEventListener('folio:map-guide', event => {
    const { pin, context, trigger: source } = event.detail || {};
    if (!pin || typeof window.folioGuideSlides !== 'function') return;
    const origin = source?.getBoundingClientRect?.();
    const result = window.folioGuideSlides(pin, context).filter(slide => slide?.title);
    if (!result.length) return;
    ++request;
    slides = result;
    decoded = [];

    window.clearTimeout(closeTimer);
    trigger = source || document.activeElement;
    anchor = origin;
    setInked(false);
    dialog.classList.remove('is-closing');
    image.hidden = true;
    noPhoto.hidden = true;
    showImage(viewport, null, '', false);
    showImage(scene, null, '', false);
    showImage(route, null, '', false);
    showImage(routeInk, null, '', false);
    title.textContent = pin.label;
    copy.replaceChildren(...slides.map(makeCaption));
    pager.replaceChildren(...slides.map((slide, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.setAttribute('aria-label', slide.title);
      button.addEventListener('click', () => selectSlide(index));
      return button;
    }));
    selectSlide(0, true);
    if (!dialog.open) dialog.showModal();
    content.scrollTop = 0;
    positionSheet();
    openClose.focus({ preventScroll: true });
  });

  image.addEventListener('click', () => setInked(!dialog.classList.contains('is-inked')));
  openClose.addEventListener('click', closeGuide);
  dialog.addEventListener('pointerdown', event => { outsidePointer = event.target === dialog; });
  dialog.addEventListener('click', event => { if (outsidePointer && event.target === dialog) closeGuide(); });
  dialog.addEventListener('cancel', event => {
    event.preventDefault();
    closeGuide();
  });
  dialog.addEventListener('keydown', event => {
    if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
    event.preventDefault();
    selectSlide(selected + (event.key === 'ArrowRight' ? 1 : -1));
  });
  new ResizeObserver(positionSheet).observe(sheet);
  window.addEventListener('resize', positionSheet);
})();
