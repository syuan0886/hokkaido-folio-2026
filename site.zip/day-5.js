{
  const canal = ['photos/d5-otaru-canal.webp', '小樽運河夜色與河畔石造倉庫', '53%'];
  const lighthouse = ['photos/d5-hiyoriyama.webp', '祝津海岬上的日和山燈塔', '50%'];
  const aquarium = ['photos/d5-otaru-aquarium.webp', '小樽水族館海獸公園與祝津海岸', '55%'];

  (window.folioExtraDays ??= []).push({
    day: 5,
    name: '小樽・祝津',
    title: '從祝津海岬到小樽運河',
    intro: '從三角市場的海鮮早餐出發，搭巴士到祝津看海獸、吃炭烤鯡魚。傍晚走過小樽的青之運河，回札幌後再到薄野吃冰淇淋。',
    photos: [canal, aquarium, lighthouse],
    credits: [
      { label: '小樽運河夜景／663highland（縮圖、轉 WebP）', url: 'https://commons.wikimedia.org/wiki/File:Otaru_Canal01s3.jpg', license: 'CC BY 2.5', licenseUrl: 'https://creativecommons.org/licenses/by/2.5/' },
      { label: '日和山燈塔／Komatta（轉 WebP）', url: 'https://commons.wikimedia.org/wiki/File:Hiyoriyama_lighthouse.JPG', license: 'CC BY-SA 4.0', licenseUrl: 'https://creativecommons.org/licenses/by-sa/4.0/' },
      { label: '小樽水族館海獸公園／星組背番号10（轉 WebP）', url: 'https://commons.wikimedia.org/wiki/File:Otaru_aquarium_(Kaiju_koen).JPG', license: 'CC BY-SA 3.0', licenseUrl: 'https://creativecommons.org/licenses/by-sa/3.0/' },
    ],
    stops: [
      { key: 'd5-sapporo', name: '札幌站', lat: 43.068611, lng: 141.350778, entry: 'd5-sapporo-start' },
      { key: 'd5-station', name: '小樽站', lat: 43.197778, lng: 140.993889, entry: 'd5-station-bus' },
      { key: 'd5-market', name: '三角市場', lat: 43.198569, lng: 140.993706, entry: 'd5-market-breakfast' },
      { key: 'd5-aquarium', name: '小樽水族館', lat: 43.23691, lng: 141.01210, entry: 'd5-aquarium-visit' },
      { key: 'd5-aotsuka', name: '青塚食堂', lat: 43.236602, lng: 141.014796, entry: 'd5-aotsuka-lunch' },
      { key: 'd5-shukutsu', name: '祝津全景展望台', lat: 43.238083, lng: 141.009417, entry: 'd5-shukutsu-view' },
      { key: 'd5-yabuhan', name: '籔半', lat: 43.19649, lng: 140.995755, entry: 'd5-yabuhan-dinner' },
      { key: 'd5-canal', name: '小樽運河・淺草橋', lat: 43.19787, lng: 141.00318, entry: 'd5-canal-walk' },
      { key: 'd5-milk', name: 'Milk Mura 本店', lat: 43.056142, lng: 141.354019, entry: 'd5-milk-dessert' },
      { key: 'd5-sandria', name: 'Sandria 本店', lat: 43.049437, lng: 141.345772, entry: 'd5-sandria-breakfast' },
    ],
    route: ['JR札幌駅', 'サンドリア 本店 札幌', '小樽三角市場', 'おたる水族館', '小樽運河 浅草橋街園'],
    entries: [
      {
        id: 'd5-sapporo-start', point: 'd5-sapporo', time: '07:35 ∼ 09:15', title: '從札幌到小樽',
        text: '07:35 出發，步行至中島公園站，搭南北線，08:05 抵達札幌站。08:17 搭 JR 普通列車，09:08 抵達小樽。出站後步行至三角市場，約 09:15 抵達。',
        links: [['JR 北海道時刻查詢', 'https://www.jrhokkaido.co.jp/network/index.html']],
      },
      {
        id: 'd5-market-breakfast', point: 'd5-market', time: '09:15 ∼ 10:30', title: '三角市場的海鮮早餐',
        text: '09:15～10:15 留給候位和吃海鮮丼。首選滝波食堂，さんかく亭和味処たけだ是備案。10:15～10:30 在市場或車站附近散步，也可留作候位緩衝。',
        links: [['三角市場店家', 'https://otaru-sankaku.com/']],
      },
      {
        id: 'd5-station-bus', point: 'd5-station', time: '10:30 ∼ 約 11:00', title: '搭巴士往祝津',
        text: '10:30 到小樽站前巴士總站 3 號月台候車。10:40 搭中央巴士 10 號經高島，約 11:00 到小樽水族館。成人單程 ¥240。',
        links: [['往返水族館巴士時刻', 'https://otaru-aq.jp/guide/bus']],
      },
      {
        id: 'd5-aquarium-visit', point: 'd5-aquarium', time: '11:00 ∼ 13:50', title: '小樽水族館', photo: aquarium,
        text: '11:00～11:25 入館後往海獸公園，11:30～11:40 看洪堡企鵝，11:50～12:00 看北海獅吃整條鮭魚。12:00～12:45 看海豹、海象等海獸，12:45～13:00 到海豚劇場找位子。13:00～13:20 看海豚和南美海獅，13:20～13:50 回本館看水槽。動物活動以當天公告為準。',
        links: [['表演時刻', 'https://otaru-aq.jp/events/showtime'], ['入館票價', 'https://otaru-aq.jp/guide/tickets']],
      },
      {
        id: 'd5-aotsuka-lunch', point: 'd5-aotsuka', time: '13:50 ∼ 15:10', title: '青塚食堂的炭烤鯡魚',
        text: '13:50 離開水族館，步行約 10 分鐘。14:00 到青塚食堂吃炭烤特大鯡魚定食，70 分鐘含候位。15:10 預計離店，若候位延長，最晚 15:25 動身。',
        links: [['青塚食堂菜單', 'https://www.aotsuka.com/ryouri.html']],
      },
      {
        id: 'd5-shukutsu-view', point: 'd5-shukutsu', time: '15:10 ∼ 16:25', title: '祝津海岬與日和山燈塔', photo: lighthouse,
        text: '15:10～15:25 步行上坡，15:25～16:10 在祝津全景展望台看日本海、海岬和日和山燈塔。日落約 16:12～16:14，16:10 先下坡，約 16:25 抵達水族館巴士站。',
        links: [['祝津海岸與展望台', 'https://otaru.gr.jp/project/otaru-harutabi-umi']],
      },
      {
        id: 'd5-aquarium-bus', point: 'd5-aquarium', time: '16:32 ∼ 約 16:57', title: '從祝津回小樽市區',
        text: '16:32 在水族館巴士站搭中央巴士 11 號，經赤岩，約 16:57 抵達小樽站前。成人單程 ¥240。',
        links: [['往返水族館巴士時刻', 'https://otaru-aq.jp/guide/bus']],
      },
      {
        id: 'd5-yabuhan-dinner', point: 'd5-yabuhan', time: '16:57 ∼ 18:10', title: '籔半的天婦羅蕎麥麵',
        text: '16:57～17:10 從小樽站走到籔半，17:10～18:10 用餐。晚餐安排天婦羅蕎麥麵，約 17:15 是原行程建議詢問的訂位時間。',
        links: [['籔半店家資訊', 'https://yabuhan.co.jp/']],
      },
      {
        id: 'd5-canal-walk', point: 'd5-canal', time: '18:10 ∼ 19:30', title: '走過青之運河', photo: canal,
        text: '18:10～18:25 步行至運河。18:25～19:30 從淺草橋走到中央橋，看石造倉庫、瓦斯燈與藍色燈飾，有餘裕再往北運河。當天燈飾亮至 22:30，這段安排步行。',
        links: [['青之運河活動資訊', 'https://otaru.gr.jp/tourist/aonoungakotosimohazimarimasita11-2']],
      },
      {
        id: 'd5-station-return', point: 'd5-station', time: '19:30 ∼ 21:00', title: '從小樽回札幌薄野',
        text: '19:30～19:45 從運河走回小樽站，19:45～19:56 進站候車。19:56 搭 JR 普通列車，20:41 抵達札幌站。換南北線到薄野，再步行至 Milk Mura。',
        links: [['JR 北海道時刻查詢', 'https://www.jrhokkaido.co.jp/network/index.html']],
      },
      {
        id: 'd5-milk-dessert', point: 'd5-milk', time: '21:00 ∼ 22:00', title: 'Milk Mura 的牛乳冰淇淋',
        text: '到薄野 Milk Mura SAPPORO 本店吃牛乳冰淇淋配利口酒。預留一小時含現場候位及用餐，店家不接受預約，僅收現金。',
        links: [['札幌觀光局店家資訊', 'https://www.sapporo.travel/en/gourmet/shop/shop_128-3/']],
      },
      {
        id: 'd5-sandria-breakfast', point: 'd5-sandria', time: '22:00 ∼ 約 23:00', title: 'Sandria 買隔日早餐',
        text: '22:00～22:20 步行到 Sandria 本店，22:20～22:40 買三明治。店家 24 小時營業，雙蛋三明治是人氣品項。22:40～22:55 步行返回，約 23:00 到飯店，將早餐冷藏。',
        links: [['Sandria 本店與品項', 'https://www.s-sandwich.com/']],
      },
    ],
  });
}
