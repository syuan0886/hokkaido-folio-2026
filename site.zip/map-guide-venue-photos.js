window.folioVenueGuidePhotos = {
  "布袋・赤磚露台": [
    {
      "image": "photos/guides/venue-akarenga-front.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:Akarenga_terrace_201511.JPG",
      "photoCredit": "アルトクール · CC BY-SA 4.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/4.0",
      "alt": "赤磚露台商場面向街角的玻璃外牆與招牌",
      "guideTitle": "先到赤磚露台",
      "guideText": "照片是赤磚露台商場的外觀。先認「赤れんがテラス」招牌，進樓後往 3 樓美食區找「中国料理 布袋」。"
    },
    {
      "image": "photos/guides/venue-akarenga-street.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:%E8%B5%A4%E3%82%8C%E3%82%93%E3%81%8C%E3%83%86%E3%83%A9%E3%82%B9%EF%BC%88Akarenga_terrace%EF%BC%89_-_panoramio.jpg",
      "photoCredit": "t-konno · CC BY-SA 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/3.0",
      "alt": "赤磚露台商場旁的步行街夜景",
      "guideTitle": "從商場旁的步行街辨認入口",
      "guideText": "這是赤磚露台旁的步行街。到商場後，從公共入口上 3 樓，再對照店名。"
    }
  ],
  "札幌東急百貨": [
    {
      "image": "photos/guides/venue-tokyu-front.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:Sapporo-Tokyu-Department-Store01.JPG",
      "photoCredit": "RJD · CC BY 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by/3.0",
      "alt": "札幌東急百貨西口與南口一側的外觀",
      "guideTitle": "從西南側辨認札幌東急",
      "guideText": "圖中是札幌東急百貨靠西口和南口的外觀，可與右側地圖的街角對照。"
    },
    {
      "image": "photos/guides/venue-tokyu-angle.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:Sapporo-Tokyu-Department-Store02.JPG",
      "photoCredit": "RJD · CC BY 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by/3.0",
      "alt": "札幌東急百貨從北側拍攝的大樓外觀",
      "guideTitle": "從札幌站側過來",
      "guideText": "照片由北側朝百貨拍攝。從車站方向過來，先辨認建築與百貨入口。"
    },
    {
      "image": "photos/guides/venue-tokyu-entrance.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:Sapporo-Tokyu-Department-Store03.JPG",
      "photoCredit": "RJD · CC BY 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by/3.0",
      "alt": "札幌東急百貨的北側街口視角",
      "guideTitle": "由北側街口辨認百貨",
      "guideText": "照片提供另一個北側視角。抵達後依當天開放入口入內。"
    }
  ],
  "青塚食堂": [
    {
      "image": "photos/guides/venue-aotsuka-3.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:%E7%83%A4%E9%B0%8A%E9%AD%9A,_%E7%83%A4%E8%8A%B1%E9%AD%9A,_%E5%B8%86%E7%AB%8B%E8%B2%9D,_%E8%8A%B1%E9%AD%9A%E4%B8%BC,_%E6%B0%91%E5%AE%BF%E9%9D%92%E5%A1%9A%E9%A3%9F%E5%A0%82,_%E5%B0%8F%E6%A8%BD,_%E5%8C%97%E6%B5%B7%E9%81%93,_%E6%97%A5%E6%9C%AC,_Otaru,_Hokkaido,_Japan,_%E3%81%8A%E3%81%9F%E3%82%8B%E3%81%97,_%E3%81%BB%E3%81%A3%E3%81%8B%E3%81%84%E3%81%A9%E3%81%86,_%E3%81%AB%E3%81%A3%E3%81%BD%E3%82%93,_%E3%81%AB%E3%81%BB%E3%82%93_(32871714037).jpg",
      "photoCredit": "bryan... · CC BY-SA 2.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/2.0",
      "alt": "青塚食堂正門與屋簷上的店名",
      "guideTitle": "認青塚食堂正門",
      "guideText": "從祝津的海岸道路走到地圖標記處。看屋簷上的「青塚食堂」招牌和店門。"
    },
    {
      "image": "photos/guides/venue-aotsuka-6.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:%E7%83%A4%E9%B0%8A%E9%AD%9A,_%E7%83%A4%E8%8A%B1%E9%AD%9A,_%E5%B8%86%E7%AB%8B%E8%B2%9D,_%E8%8A%B1%E9%AD%9A%E4%B8%BC,_%E6%B0%91%E5%AE%BF%E9%9D%92%E5%A1%9A%E9%A3%9F%E5%A0%82,_%E5%B0%8F%E6%A8%BD,_%E5%8C%97%E6%B5%B7%E9%81%93,_%E6%97%A5%E6%9C%AC,_Otaru,_Hokkaido,_Japan,_%E3%81%8A%E3%81%9F%E3%82%8B%E3%81%97,_%E3%81%BB%E3%81%A3%E3%81%8B%E3%81%84%E3%81%A9%E3%81%86,_%E3%81%AB%E3%81%A3%E3%81%BD%E3%82%93,_%E3%81%AB%E3%81%BB%E3%82%93_(33938301928).jpg",
      "photoCredit": "bryan... · CC BY-SA 2.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/2.0",
      "alt": "青塚食堂入口旁的炭火烤魚",
      "guideTitle": "留意入口旁的炭火烤魚區",
      "guideText": "圖為店家入口旁的炭火烤魚。到門口先確認店內座位，再向店員點餐。"
    },
    {
      "image": "photos/guides/venue-aotsuka-8.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:%E7%83%A4%E9%B0%8A%E9%AD%9A,_%E7%83%A4%E8%8A%B1%E9%AD%9A,_%E5%B8%86%E7%AB%8B%E8%B2%9D,_%E8%8A%B1%E9%AD%9A%E4%B8%BC,_%E6%B0%91%E5%AE%BF%E9%9D%92%E5%A1%9A%E9%A3%9F%E5%A0%82,_%E5%B0%8F%E6%A8%BD,_%E5%8C%97%E6%B5%B7%E9%81%93,_%E6%97%A5%E6%9C%AC,_Otaru,_Hokkaido,_Japan,_%E3%81%8A%E3%81%9F%E3%82%8B%E3%81%97,_%E3%81%BB%E3%81%A3%E3%81%8B%E3%81%84%E3%81%A9%E3%81%86,_%E3%81%AB%E3%81%A3%E3%81%BD%E3%82%93,_%E3%81%AB%E3%81%BB%E3%82%93_(47026019024).jpg",
      "photoCredit": "bryan... · CC BY-SA 2.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/2.0",
      "alt": "在青塚食堂拍攝的魚丼套餐",
      "guideTitle": "店內餐點實拍",
      "guideText": "這是到店者拍攝的餐點。品項、魚種和價位以當天店內菜單為準。"
    }
  ],
  "籔半": [
    {
      "image": "photos/guides/venue-yabuhan.webp",
      "photoSource": "https://commons.wikimedia.org/wiki/File:Nabeyaki_udon_at_Yabuhan_Soba_%E5%B0%8F%E6%A8%BD%E8%95%8E%E9%BA%A6%E5%B1%8B_%E7%B1%94%E5%8D%8A_in_Otaru,_Hokkaido,_Japan_(74).jpg",
      "photoCredit": "Savannah Rivka · CC BY-SA 4.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/4.0",
      "alt": "小樽籔半店內拍攝的鍋燒烏龍麵",
      "guideTitle": "先認右圖的籔半位置",
      "guideText": "左圖是在小樽籔半拍攝的鍋燒烏龍麵。從小樽站附近過來時，按右圖走到店名「籔半」的位置。"
    }
  ],
  "KINOTOYA 大通公園店": [
    {
      "image": "photos/guides/venue-street-bisse-street.webp",
      "alt": "大通公園旁的大通 Bisse 外觀，KINOTOYA 大通公園店位於一樓",
      "photoSource": "https://commons.wikimedia.org/wiki/File:%E5%A4%A7%E9%80%9A%E3%83%93%E3%83%83%E3%82%BB%EF%BC%88ODORI_BISSE%EF%BC%89_-_panoramio_%281%29.jpg",
      "photoCredit": "t-konno · CC BY-SA 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/3.0/",
      "guideTitle": "進大通 Bisse 的一樓",
      "guideText": "照片是大通 Bisse 外觀。認大樓後到 1 樓找 KINOTOYA，並以現場店名標示為準。"
    },
    {
      "image": "photos/guides/venue-street-bisse-building.webp",
      "alt": "沿街仰望大通 Bisse 所在的北洋大通中心，KINOTOYA 位於一樓",
      "photoSource": "https://commons.wikimedia.org/wiki/File:%E5%A4%A7%E9%80%9A%E3%83%93%E3%83%83%E3%82%BB%EF%BC%88ODORI_BISSE%EF%BC%89_-_panoramio.jpg",
      "photoCredit": "t-konno · CC BY-SA 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/3.0/"
    },
    {
      "image": "photos/guides/venue-street-bisse-night.webp",
      "alt": "大通 Bisse 夜間外觀，KINOTOYA 大通公園店位於一樓",
      "photoSource": "https://commons.wikimedia.org/wiki/File:%E5%A4%A7%E9%80%9A%E3%83%93%E3%83%83%E3%82%BB%EF%BC%88ODORI_BISSE%EF%BC%89_-_panoramio_%282%29.jpg",
      "photoCredit": "t-konno · CC BY-SA 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/3.0/"
    }
  ],
  "一粒庵": [
    {
      "image": "photos/guides/venue-street-hokuren-building.webp",
      "alt": "左側為ホクレンビル，拉麵札幌一粒庵位於該棟地下 1 樓",
      "photoSource": "https://commons.wikimedia.org/wiki/File:JA-Hokkaido-Bldg-02.jpg",
      "photoCredit": "J o · CC BY-SA 3.0 · 縮放轉 WebP",
      "photoLicense": "https://creativecommons.org/licenses/by-sa/3.0/",
      "guideTitle": "認ホクレン大樓，往地下 1 樓",
      "guideText": "照片左側是「ホクレンビル」。到大樓後依地下樓層指標下 B1F，找「ラーメン札幌一粒庵」。"
    }
  ]
};
