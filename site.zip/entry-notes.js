(() => {
  const pin = (name, lat, lng, query = name) => [name, [lat, lng], query];
  const sapporo = pin('JR 札幌站', 43.068569, 141.350801, 'JR 札幌駅');
  const airport = pin('JR 新千歲機場站', 42.7878079, 141.6808693, '新千歳空港駅');
  const nakajima = pin('中島公園站', 43.0483303, 141.355121, '中島公園駅 札幌');
  const susukino = pin('薄野站', 43.055499, 141.353679, 'すすきの駅');
  const maruyama = pin('圓山公園站', 43.055735, 141.319515, '円山公園駅');
  const odori = pin('大通站', 43.060094, 141.352314, '大通駅 札幌');
  const hotei = pin('布袋・赤磚露台', 43.06392, 141.35063, '中国料理 布袋 赤れんがテラス店');
  const kappa = pin('Kappa Liner 薄野站', 43.055348, 141.3524291, '43.055348,141.3524291');
  const premier = pin('Premier 中島公園', 43.04765, 141.35192, 'プレミアホテル 中島公園 札幌');
  const eastSapporo = pin('東札幌站', 43.05188, 141.384889, '東札幌駅');
  const kinotoya = pin('KINOTOYA 大通公園店', 43.061389, 141.352045, 'きのとや 大通公園店');
  const spa = pin('癒し〜ぷ札幌大通店', 43.059507, 141.356969, '癒し〜ぷ 札幌大通店');
  const donki = pin('MEGA 唐吉訶德', 43.057211, 141.352511, 'MEGAドン・キホーテ 札幌狸小路本店');
  const kita24 = pin('北24條站', 43.089542, 141.344911, '北24条駅');
  const otaru = pin('JR 小樽站', 43.19742, 140.99407, 'JR 小樽駅');
  const otaruBus = pin('小樽站前 3 號月台', 43.19755, 140.99419, '小樽駅前バスターミナル');
  const aquariumBus = pin('水族館巴士站', 43.23656, 141.01313, 'おたる水族館 バス停');
  const centralBridge = pin('小樽運河・中央橋', 43.19994, 141.0015, '小樽運河 中央橋');
  const toyaBus = pin('洞爺站前巴士站', 42.55071, 140.76328, '洞爺駅前 道南バス');
  const motomachi = pin('元町巴士站', 42.5656, 140.82635, '洞爺湖温泉 元町 バス停');
  const showa = pin('昭和新山巴士站', 42.54036, 140.85976, '昭和新山 バス停');

  // Strings refer to the public stop coordinates already used by the itinerary map.
  window.folioEntryNotes = {
    food: {
      places: [
        pin('新千歲機場國內線', 42.78767, 141.68073, '新千歳空港 国内線ターミナル'),
        pin('かま栄', 42.78767, 141.68073, 'かま栄 新千歳空港店'),
        pin('豚丼名人', 42.78767, 141.68073, 'ドライブインいとう 豚丼名人 新千歳空港'),
        airport,
      ],
      moreFacts: [['入境與會合', '10:55 抵達，13:00 前在國內線航廈會合'], ['午餐時間', '13:00–13:50']],
    },
    city: {
      places: [airport, sapporo, nakajima, premier, kappa],
      facts: [['JR 快速 Airport 95', '14:19 新千歲機場 → 14:57 札幌'], ['南北線', '札幌 → 中島公園'], ['寄放行李', '15:00–15:35，Premier 中島公園']],
      sections: [['轉乘順序', '由國內線航廈 B1F 搭 JR。到札幌站循地下鐵南北線指標，往真駒內方向搭到中島公園。寄放行李後前往薄野的巴士站柱。']],
      sources: [['JR 北海道時刻查詢', 'https://www.jrhokkaido.co.jp/network/index.html'], ['札幌市交通局車資', 'https://www.city.sapporo.jp/st/ryokin/']],
    },
    park: {
      moreFacts: [['Kappa Liner', '16:08 薄野上車，16:54 白絲瀑布下車'], ['松尾成吉思汗・定山溪', '18:00–19:20，札幌市南區定山溪溫泉東 3 丁目'], ['足湯與補給', '19:20–20:00 泡足湯，之後到 Seicomart']],
      places: [pin('定山源泉公園', 42.964889, 141.163139, '定山源泉公園'), pin('溫泉蛋之泉', 42.965047, 141.162987, 'おんたまの湯 定山渓'), pin('二見吊橋', 42.963909, 141.158148, '定山渓 二見吊橋'), pin('松尾成吉思汗・定山溪', 42.9670706, 141.1673788, '松尾ジンギスカン 定山渓支店'), pin('Seicomart 定山溪溫泉店', 42.96491, 141.16583, 'セイコーマート 定山渓温泉店')],
    },
    return: {
      title: '定山溪回札幌',
      places: [pin('白絲瀑布站・札幌方向', 42.968206, 141.169449, '白糸の滝 バス停 定山渓'), sapporo, hotei],
      facts: [['Kappa Liner', '09:55 白絲瀑布 → 11:03 札幌'], ['布袋・赤磚露台', '11:30–12:20，赤磚露台 3F']],
      sections: [['上車與午餐', '在白絲瀑布往札幌方向的站柱 2 候車。抵達後寄放過夜小包，再步行到赤磚露台 3 樓美食廣場。']],
      sources: [['Kappa Liner 班次與預約', 'https://www.jotetsu.co.jp/bus/kappa_liner/'], ['布袋赤磚露台店', 'https://zangihoteigroup.com/other2/']],
    },
    university: {
      places: [pin('榆樹之森遊客中心', 43.07085, 141.34751, '北海道大学 エルムの森'), pin('北大中央草坪', 43.07105, 141.34469, '北海道大学 中央ローン'), pin('北大 Marche', 43.07178, 141.34569, '北大マルシェ Café & Labo'), pin('北大綜合博物館', 43.07264, 141.34218, '北海道大学総合博物館'), pin('大野池', 43.07426, 141.34149, '北海道大学 大野池'), pin('一粒庵', 43.06692, 141.35418, 'ラーメン札幌一粒庵'), sapporo],
      facts: [['校園散步', '12:40–16:00，從榆樹之森入校'], ['北大 Marche', '百年紀念會館 1F，可停留吃甜點'], ['博物館', '免費，行程預留 60–75 分鐘'], ['一粒庵', '17:00–17:45，札幌站南側ホクレンビル B1F']],
      sections: [['校園順序', '榆樹之森、中央草坪、北大 Marche、綜合博物館、大野池與舊白楊木林道。以 16:00 左右能往札幌站走為準，再安排較遠的校園景點。'], ['晚餐後', '吃完到札幌站取小包，搭南北線到中島公園，再前往市電站。']],
      sources: [['北大校園地圖', 'https://www.facility.hokudai.ac.jp/wp-content/uploads/2022/09/guide-map_japanese.pdf'], ['北大博物館開館資訊', 'https://www.museum.hokudai.ac.jp/outline/open/']],
    },
    moiwa: {
      moreFacts: [['上山前', '18:50–19:40，市電外回り轉免費接駁'], ['下山後', '搭市電往西線11條，再到 MaxValu 山鼻店採買']],
    },
    'd3-start': {places: [nakajima, 'd3-market'], routeEntry: 'd3-breakfast', facts: [['準備', '07:00–07:30'], ['步行', '07:30–08:00，中島公園附近 → 二條市場']]},
    'd3-breakfast': {places: [pin('二條市場・大磯二號店', 43.0582133, 141.358959, '二条市場 大磯 2号店')], facts: [['大磯二號店', '南 3 條東 2 丁目，GC 大樓 1F'], ['早餐', '08:00–09:30，含候位']]},
    'd3-jcmi': {places: ['d3-convention', pin('巴士中心前站', 43.061525, 141.361925, 'バスセンター前駅'), eastSapporo], facts: [['搭車', '09:30–10:00，地鐵東西線轉步行'], ['會議', '10:00–15:30，札幌會議中心 SORA']]},
    'd3-tower-stop': {places: ['d3-tower', 'd3-convention', eastSapporo, odori], facts: [['移動', '15:30–15:50，由東札幌搭東西線到大通'], ['展望台', '15:50–16:30，預計看 16:00 點燈']]},
    'd3-gyoza': {places: ['d3-odori', kinotoya, 'd3-tower'], facts: [['札幌餃子製造所', '16:40–17:15，4PLA 店'], ['KINOTOYA', '17:20–17:40，大通公園店']]},
    'd3-spa': {places: [spa, kinotoya], facts: [['步行', '17:40–17:55，從 KINOTOYA 前往'], ['頭部按摩', '18:00–19:00，待預約']]},
    'd3-dinner': {places: [pin('彩ノ匠・狸COMICHI', 43.0577536, 141.3552939, '彩ノ匠 狸COMICHI 札幌'), pin('狸神社・狸COMICHI', 43.0577536, 141.3552939, '狸神社 狸COMICHI 札幌'), spa], facts: [['彩ノ匠', '19:15–20:15，狸COMICHI，待預約'], ['狸神社', '20:15–20:25，同棟停留']]},
    'd3-shopping': {places: [pin('#C-pla 狸小路四丁目', 43.057163, 141.352155, '#C-pla 狸小路4丁目店'), donki, 'd3-comichi'], facts: [['扭蛋', '20:30–20:50，狸小路四丁目'], ['唐吉訶德', '21:00–22:10，札幌狸小路本店']]},
    'd3-bakery': {places: [pin('夜のしげぱん', 43.054012, 141.350171, '夜のしげぱん 札幌'), donki, nakajima], facts: [['夜のしげぱん', '22:20–22:35，外帶麵包'], ['回程', '22:35–22:55，步行往中島公園附近']]},
    'd4-start': {places: [nakajima, odori, maruyama, 'd4-maruyama'], facts: [['轉乘', '南北線中島公園 → 大通 → 東西線圓山公園'], ['公園散步', '08:30–08:50，穿過圓山公園']]},
    'd4-shrine': {places: ['d4-maruyama', maruyama, pin('六花亭 神宮茶屋店', 43.055784, 141.308083, '六花亭 神宮茶屋店')], facts: [['參拜', '08:50–10:05，御守與御朱印'], ['六花亭 神宮茶屋店', '在神宮境內，行程安排判官餅']]},
    'd4-barnes': {places: ['d4-barnes', 'd4-maruyama', 'd4-fushimi'], facts: [['BARNES', '10:25–10:45，吃霜淇淋'], ['離開', '10:45 搭計程車，約 11:05 到伏見稻荷']]},
    'd4-fushimi-stop': {places: ['d4-fushimi', pin('伏見稻荷鳥居入口', 43.036725, 141.326563, '札幌伏見稲荷神社'), 'd4-barnes'], facts: [['神社停留', '11:05–11:45，走鳥居步道'], ['下一段', '沿下坡前往西線14條市電站']]},
    'd4-streetcar': {places: [pin('西線14條站', 43.04064, 141.336435, '西線14条 札幌'), pin('西4丁目站', 43.058895, 141.351845, '西4丁目 札幌'), 'd4-fushimi', 'd4-station'], facts: [['市電外回り', '12:12 西線14條 → 12:33 西4丁目'], ['步行', '12:33–12:50，地下街到 HULIC SQUARE 2F'], ['備用班次', '12:21 出發，會縮短轉乘與報到時間']]},
    'd4-jojoen': {places: [pin('叙々苑札幌站前店', 43.0652864, 141.3513925, '叙々苑 札幌駅前店'), sapporo], facts: [['叙々苑', '13:00–14:20，HULIC SQUARE 札幌 2F'], ['進店', '由札幌站前地下步行空間抵達']]},
    'd4-tokyu': {places: [pin('札幌東急百貨', 43.066014, 141.353197, 'さっぽろ東急百貨店'), 'd4-station', sapporo, kita24], facts: [['百貨', '14:30–15:30，札幌站旁'], ['南北線', '15:41 札幌 → 15:46 北24條']]},
    'd4-spocha': {places: ['d4-round1', kita24], facts: [['入場前', '15:46–16:05 步行，16:05–16:15 購票'], ['Spo-Cha', '16:15–19:15，札幌北21條店']]},
    'd4-curry': {places: ['d4-kita24', pin('三船24條店', 43.091055, 141.343951, '三船 24条店 札幌'), kita24, susukino], facts: [['Tiger Curry', '19:30–20:45，北24條本店，訂位未確認'], ['三船24條店', '20:45–20:55，外帶取餐'], ['南北線', '21:10 北24條 → 21:18 薄野']]},
    'd4-supper': {places: [pin('皆招樓', 43.053881, 141.353978, '皆招楼 札幌'), pin('Dinner Bell 薄野南7條店', 43.051599, 141.34984, 'ディナーベル すすきの南7条店'), susukino], facts: [['皆招樓', '21:25–21:40，買中華包'], ['Dinner Bell', '21:50–22:20，晚間補給']]},
    'd5-sapporo-start': {places: [sapporo, otaru, nakajima, 'd5-market'], facts: [['南北線', '中島公園 → 札幌，約 08:05 到站'], ['JR 普通列車', '08:17 札幌 → 09:08 小樽']]},
    'd5-market-breakfast': {places: [pin('滝波食堂・三角市場', 43.198569, 140.993706, '滝波食堂 小樽'), pin('さんかく亭・三角市場', 43.198569, 140.993706, 'さんかく亭 小樽'), pin('味処たけだ・三角市場', 43.198569, 140.993706, '味処たけだ 小樽'), otaru], facts: [['滝波食堂', '首選，三角市場內'], ['さんかく亭', '候位備案，三角市場內'], ['味処たけだ', '候位備案，三角市場內']]},
    'd5-station-bus': {places: [otaruBus, aquariumBus, otaru], facts: [['中央巴士 10 號', '10:40 小樽站前 3 號月台，經高島'], ['成人單程', '¥240，約 11:00 抵達水族館']]},
    'd5-aquarium-visit': {places: ['d5-aquarium', aquariumBus, pin('海獸公園', 43.23792, 141.01148, 'おたる水族館 海獣公園')], facts: [['海獸公園', '11:30 洪堡企鵝，11:50 北海獅'], ['海豚劇場', '12:45 開始找位，13:00 看表演'], ['本館', '13:20–13:50 回本館看水槽']]},
    'd5-aotsuka-lunch': {places: ['d5-aotsuka', 'd5-aquarium'], facts: [['青塚食堂', '14:00 到店，70 分鐘含候位'], ['離店', '15:10 預計離店，最晚 15:25 動身']]},
    'd5-shukutsu-view': {places: ['d5-shukutsu', 'd5-aotsuka', aquariumBus], facts: [['上坡步行', '15:10–15:25，由青塚食堂往展望台'], ['停留', '15:25–16:10，之後往水族館巴士站下坡']]},
    'd5-aquarium-bus': {places: [aquariumBus, otaru], facts: [['中央巴士 11 號', '16:32 水族館 → 約 16:57 小樽站前，經赤岩'], ['成人單程', '¥240']]},
    'd5-yabuhan-dinner': {places: ['d5-yabuhan', otaru], facts: [['籔半', '17:10–18:10，蕎麥麵晚餐'], ['交通', '約 16:57 從小樽站前步行過去']]},
    'd5-canal-walk': {places: ['d5-canal', centralBridge, 'd5-yabuhan'], facts: [['步行順序', '籔半 → 淺草橋 → 中央橋'], ['運河散步', '18:25–19:30，當日燈飾至 22:30']]},
    'd5-station-return': {places: [otaru, sapporo, susukino, centralBridge, 'd5-milk'], facts: [['JR 普通列車', '19:56 小樽 → 20:41 札幌'], ['市區轉乘', '南北線札幌 → 薄野，出站步行到 Milk Mura']]},
    'd5-milk-dessert': {places: ['d5-milk', susukino], facts: [['Milk Mura', '21:00–22:00，含候位與用餐'], ['付款與訂位', '僅收現金，現場候位']]},
    'd5-sandria-breakfast': {places: ['d5-sandria', 'd5-milk'], facts: [['Sandria', '22:20–22:40 買三明治，本店 24 小時營業'], ['隔日早餐', '購買後回飯店冷藏']]},
    'd6-station-start': {places: [sapporo, 'd6-station'], facts: [['JR 北斗 4 號', '06:53 札幌 → 08:43 洞爺'], ['下車後', '步行前往虻田神社，09:00 社務所開門']]},
    'd6-shrine-visit': {places: ['d6-shrine', 'd6-station', toyaBus], facts: [['參拜', '09:00–09:20，御守與御朱印'], ['往回', '09:20 步行回站，09:55 搭道南巴士']]},
    'd6-onsen-bus': {places: [toyaBus, 'd6-terminal', 'd6-wakasaimo'], facts: [['道南巴士', '09:55 洞爺站前 → 10:13 洞爺湖溫泉'], ['成人車資', '¥400']]},
    'd6-sweets': {places: ['d6-wakasaimo', 'd6-terminal', 'd6-yakushi'], facts: [['若狹芋本店', '10:20–10:32，買洞爺湖點心'], ['下一站', '10:32 出發，步行往湯前藥師如來堂']]},
    'd6-yakushi-visit': {places: ['d6-yakushi', 'd6-wakasaimo', 'd6-echigoya'], facts: [['參拜', '10:42–10:48，湯前藥師如來堂與お湯掛け地蔵'], ['步行', '10:48–10:53 前往越後屋']]},
    'd6-wooden-sword': {places: ['d6-echigoya', motomachi, 'd6-yakushi'], facts: [['越後屋', '10:53–11:08，挑選木刀'], ['候車', '約 11:12 抵達元町站，11:22 搭車']]},
    'd6-ropeway': {places: ['d6-usuzan', showa, pin('有珠山纜車山頂站', 42.54028, 140.84436, '有珠山ロープウェイ 山頂駅'), pin('洞爺湖展望台', 42.5405, 140.8443, '有珠山 洞爺湖展望台'), pin('火口原展望台', 42.53726, 140.84168, '有珠山 火口原展望台')], facts: [['纜車往返', '成人 ¥2,000，單程約 6 分鐘'], ['山頂動線', '山頂站 → 洞爺湖展望台 → 火口原展望台 → 山頂站'], ['回程巴士', '13:15 從昭和新山巴士站發車']]},
    'd6-lunch': {places: ['d6-gyusuke', 'd6-terminal', showa], facts: [['牛助 Gyusuke', '13:40–14:45，預留 65 分鐘'], ['巴士', '13:15 昭和新山 → 13:31 洞爺湖溫泉']]},
    'd6-bath': {places: ['d6-manseikaku', 'd6-gyusuke', 'd6-tunnel'], facts: [['日歸溫泉', '14:55–16:45，平日成人 ¥1,200'], ['毛巾', '另租 ¥400'], ['受理', '下午場 13:00–21:00，最晚 20:00']]},
    'd6-illumination': {places: ['d6-tunnel', 'd6-manseikaku', 'd6-boyotei'], facts: [['候場與點燈', '約 16:50 到場，17:00 點燈'], ['離開', '17:25 步行前往望羊蹄']]},
    'd6-dinner': {places: ['d6-boyotei', 'd6-tunnel', 'd6-terminal'], facts: [['望羊蹄', '17:35–18:30，預留 55 分鐘'], ['離店後', '18:30 步行往洞爺湖溫泉巴士總站']]},
    'd6-station-return': {places: ['d6-terminal', toyaBus, 'd6-station', sapporo], facts: [['道南巴士', '18:50 洞爺湖溫泉 → 19:08 洞爺站前'], ['JR 北斗 19 號', '19:47 洞爺 → 21:41 札幌']]},
  };
})();
