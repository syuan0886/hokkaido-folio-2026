(() => {
  const airport = 'https://www.hokkaido-airports.com/ja/new-chitose';
  const terminal = `${airport}/floormap/domestic/`;
  const airportWorks = `${airport}/info/20261109-7624.html`;
  const rail = `${airport}/access/jr/`;
  const fish = `${airport}/spend/shop/48/`;
  const pork = `${airport}/spend/shop/123/`;
  const park = 'https://jozankei.jp/tw/oneday/jozan-gensen-park/';
  const egg = 'https://jozankei.jp/oneday/ontama/';
  const bridgeNotice = 'https://jozankei.jp/news/futami-park-notice/';
  const hotel = 'https://premier.kenhotels.com/en/nakajimapark/guide/access/';
  const station = 'https://www.jrhokkaido.co.jp/construction/';
  const jrStations = 'https://www.jrhokkaido.co.jp/network/station/station.html';
  const subway = 'https://www.city.sapporo.jp/st/subway/ekikonaizu/ekikonaizu.html';
  const kappa = 'https://www.jotetsu.co.jp/bus/kappa_liner/';
  const shiraito = 'https://www.jotetsu.co.jp/bus/times/260401/shiraitonotaki.pdf';
  const campus = 'https://www.facility.hokudai.ac.jp/wp-content/uploads/2024/04/41a893af0cde11d5f73d78f86c03a52a.pdf';
  const moiwa = 'https://mt-moiwa.jp/facility/';
  const moiwaShuttle = 'https://mt-moiwa.jp/access/shuttlebus-tram/';
  const convention = 'https://www.sora-scc.jp/access/';
  const tvAccess = 'https://www.tv-tower.co.jp/access.html';
  const tvTicket = 'https://www.tv-tower.co.jp/floorguide_3f.html';
  const aquariumBus = 'https://otaru-aq.jp/guide/bus';
  const aquariumAccess = 'https://blog.otaru-aq.jp/guide/access';
  const aquariumFaq = 'https://otaru-aq.jp/faq';
  const usu = 'https://usuzan.hokkaido.jp/tw/';
  const usuTrail = 'https://www.toya-usu-geopark.org/trail/panorama';
  const usuCrater = 'https://usuzan.hokkaido.jp/archives/blog/19390';
  const usuBus = 'https://www.donanbus.co.jp/map/toyako_syowashinzan/';

  const note = (title, text, source, extra = {}) => ({title, text, source, ...extra});
  const guidePhotos = {
    'nakajima-exit-3': ["https://commons.wikimedia.org/wiki/File:Nakajima_koen_Sta(Exit_3).jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'nakajima-south-gate': ["https://commons.wikimedia.org/wiki/File:Namboku-line_Nakajimakoen-sta_Gate(South).jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'nakajima-platform': ["https://commons.wikimedia.org/wiki/File:Nakajima-Koen_Station_platforms_2016_8_12.jpg", "Nesnad · CC BY 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"],
    'cts-international-arrival': ["https://commons.wikimedia.org/wiki/File:New_Chitose_Airport_International_terminal_20190703.jpg", "耕太郎 on Wikitravel · CC BY-SA 3.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/3.0"],
    'cts-shopping': ["https://commons.wikimedia.org/wiki/File:Shopping_World_(New_Chitose_Airport).JPG", "Abasaa · Public domain · 縮放轉 WebP", ""],
    'cts-gourmet': ["https://commons.wikimedia.org/wiki/File:Gourmet_World_(New_Chitose_Airport).JPG", "Abasaa · Public domain · 縮放轉 WebP", ""],
    'cts-domestic-arrivals': ["https://commons.wikimedia.org/wiki/File:Departure_marks_in_New_Chitose_Airport_Domestic_arrivals_Lobby_(20181227).jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'cts-jr-gate': ["https://commons.wikimedia.org/wiki/File:JR_Chitose-Line_New_Chitose_Airport_Station_Gates_(20181227).jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'cts-jr-platform': ["https://commons.wikimedia.org/wiki/File:JR_Chitose-Line_New_Chitose_Airport_Station_Platform.jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'cts-jr-concourse': ["https://commons.wikimedia.org/wiki/File:JR_Chitose-Line_New_Chitose_Airport_Station_Concourse.jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'sapporo-station-exterior': ["https://commons.wikimedia.org/wiki/File:Sapporo_Station_in_November_2025.jpg", "ノボホショコロトソ · CC BY 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"],
    'sapporo-station-corridor': ["https://commons.wikimedia.org/wiki/File:A_Corridor_of_Sapporo_Station_01.jpg", "ノボホショコロトソ · CC BY 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"],
    'sapporo-station-north': ["https://commons.wikimedia.org/wiki/File:JR_Sapporo_Station_%E6%9C%AD%E5%B9%8C%E9%A7%85_%E5%8C%97%E5%8F%A3.jpg", "ノボホショコロトソ · CC BY 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"],
    'sapporo-convention-center': ["https://commons.wikimedia.org/wiki/File:Sapporo_Convention_Center.jpg", "モンモン · Public domain · 縮放轉 WebP", ""],
    'sapporo-convention-approach': ["https://commons.wikimedia.org/wiki/File:Sapporo_convention_center_-_panoramio.jpg", "Masoud Akbari · CC BY-SA 3.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/3.0"],
    'moiwa-mid-station': ["https://commons.wikimedia.org/wiki/File:Moiwayama_Ropeway_Mid-slope_station.jpg", "ブルーノ・プラス · CC BY 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"],
    'moiwa-base-station': ["https://commons.wikimedia.org/wiki/File:%E5%B1%B1%E9%BA%93%E9%A7%85_%E3%82%82%E3%81%84%E3%82%8F%E3%82%84%E3%81%BE%E3%83%AD%E3%83%BC%E3%83%97%E3%82%A6%E3%82%A7%E3%82%A4_%E6%9C%AD%E5%B9%8C%E5%B8%82_Mar_28,_2010.jpg", "Happy Come · CC BY 2.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/2.0"],
    'moiwa-gondola': ["https://commons.wikimedia.org/wiki/File:Cable_Car_(Ropeway)_to_Mount_Moiwayama_-_Sapporo_-_Hokkaido_-_Japan_(47977611532).jpg", "Adam Jones from Kelowna, BC, Canada · CC BY-SA 2.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/2.0"],
    'moiwa-cableway': ["https://commons.wikimedia.org/wiki/File:Moiwayama_Ropeway_(4thgen).JPG", "Route275 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'otaru-station-front': ["https://commons.wikimedia.org/wiki/File:Otaru_Station_20220626.jpg", "皓月旗 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'otaru-station-gates': ["https://commons.wikimedia.org/wiki/File:Otaru_Station_ticket_gate_202604.jpg", "Sashimiteishoku · CC0 · 縮放轉 WebP", "http://creativecommons.org/publicdomain/zero/1.0/deed.en"],
    'otaru-station-platform': ["https://commons.wikimedia.org/wiki/File:JR_Hakodate-Main-Line_Otaru_Station_Platform_4%E3%83%BB5.jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'tv-tower-basement': ["https://commons.wikimedia.org/wiki/File:Sapporo_Television_Tower_Basement_Shops_2014.jpg", "Wing1990hk · CC BY 3.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/3.0"],
    'tv-tower-deck': ["https://commons.wikimedia.org/wiki/File:Sapporo_Television_Tower_Observation_Deck_2014.jpg", "Wing1990hk · CC BY 3.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/3.0"],
    'usu-summit-station': ["https://commons.wikimedia.org/wiki/File:Usuzan_Ropeway_Sancho_Station.jpg", "Miyuki Meinaka · Public domain · 縮放轉 WebP", ""],
    'usu-base-station': ["https://commons.wikimedia.org/wiki/File:Usuzan_Ropeway_Sanroku_Station.jpg", "Miyuki Meinaka · Public domain · 縮放轉 WebP", ""],
    'usu-ropeway-gondola': ["https://commons.wikimedia.org/wiki/File:USUZAN_ROPE_WAY.jpg", "Miyuki Meinaka · Public domain · 縮放轉 WebP", ""],
    'usu-toya-viewpoint': ["https://commons.wikimedia.org/wiki/File:130922_Usuzan_Ropeway_Sobetsu_Hokkaido_Japan04s3.jpg", "663highland · CC BY 2.5 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/2.5"],
    'jozankei-135-02': ["https://jozankei.jp/photo/?category=135", "定山溪觀光協會 · 官方開放素材 · 縮放轉 WebP", "https://jozankei.jp/photo/?category=135"],
    'jozankei-135-06': ["https://jozankei.jp/photo/?category=135", "定山溪觀光協會 · 官方開放素材 · 縮放轉 WebP", "https://jozankei.jp/photo/?category=135"],
    'jozankei-135-09': ["https://jozankei.jp/photo/?category=135", "定山溪觀光協會 · 官方開放素材 · 縮放轉 WebP", "https://jozankei.jp/photo/?category=135"],
    'jozankei-135-12': ["https://jozankei.jp/photo/?category=135", "定山溪觀光協會 · 官方開放素材 · 縮放轉 WebP", "https://jozankei.jp/photo/?category=135"],
    'jozankei-137-09': ["https://jozankei.jp/photo/?category=137", "定山溪觀光協會 · 官方開放素材 · 縮放轉 WebP", "https://jozankei.jp/photo/?category=137"],
    'jozankei-137-10': ["https://jozankei.jp/photo/?category=137", "定山溪觀光協會 · 官方開放素材 · 縮放轉 WebP", "https://jozankei.jp/photo/?category=137"],
    'jozankei-137-13': ["https://jozankei.jp/photo/?category=137", "定山溪觀光協會 · 官方開放素材 · 縮放轉 WebP", "https://jozankei.jp/photo/?category=137"],
    'premier-park-view': ["https://commons.wikimedia.org/wiki/File:Nakajima_Park_Sapporo22s3s3750.jpg", "663highland · CC BY 2.5 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/2.5"],
    'susukino-exit-4': ["https://commons.wikimedia.org/wiki/File:Susukino_Sta(Exit_4).jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'susukino-gates': ["https://commons.wikimedia.org/wiki/File:Namboku-line_Susukino-sta_Gate.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'susukino-platform': ["https://commons.wikimedia.org/wiki/File:Namboku-line_Susukino-sta_Platform.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'maruyama-exit-3': ["https://commons.wikimedia.org/wiki/File:(JPN-Hokkaido)_Maruyama-Koen_Subway_Station_Exit_3_2026-06-06.jpg", "S5A-0043 · CC BY 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"],
    'maruyama-gates': ["https://commons.wikimedia.org/wiki/File:Tozai-line_Maruyamakoen-sta_Gate.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'maruyama-platform': ["https://commons.wikimedia.org/wiki/File:(JPN-Hokkaido)_Maruyama-Koen_Subway_Station_Platform_1_2026-06-06.jpg", "S5A-0043 · CC BY 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/4.0"],
    'odori-concourse': ["https://commons.wikimedia.org/wiki/File:Odori_Station_Sapporo01s3s3870.jpg", "663highland · CC BY 2.5 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/2.5"],
    'odori-gates': ["https://commons.wikimedia.org/wiki/File:%C5%8Cd%C5%8Dri_Station_ticket_gate_2018-12-31.jpg", "MIKI Yoshihito from Sapporo City,Hokkaido., JAPAN · CC BY 2.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/2.0"],
    'odori-platform': ["https://commons.wikimedia.org/wiki/File:Tozai-line_Odori-sta_Platform.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'higashisapporo-entrance': ["https://commons.wikimedia.org/wiki/File:Higashi_sapporo-sta.JPG", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'higashisapporo-gates': ["https://commons.wikimedia.org/wiki/File:Tozai-line_Higashisapporo-sta_Gate.jpg", "Chuoterminal 02 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'higashisapporo-platform': ["https://commons.wikimedia.org/wiki/File:Higashi-sapporo_station_platform_20160124_180716.jpg", "Chuoterminal 02 from jawp · CC BY 3.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by/3.0"],
    'toya-station-front': ["https://commons.wikimedia.org/wiki/File:JR_Muroran-Main-Line_Toya_Station_building.jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'toya-station-gates': ["https://commons.wikimedia.org/wiki/File:JR_Muroran-Main-Line_T%C5%8Dya_Station_Gates.jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
    'toya-station-platform': ["https://commons.wikimedia.org/wiki/File:JR_Muroran-Main-Line_T%C5%8Dya_Station_Platform.jpg", "Mister0124 · CC BY-SA 4.0 · 縮放轉 WebP", "https://creativecommons.org/licenses/by-sa/4.0"],
  };

  function photo(key, alt) {
    const [photoSource, photoCredit, photoLicense] = guidePhotos[key];
    return {image: `photos/guides/${key}.webp`, alt, photoSource, photoCredit, photoLicense};
  }
  const moiwaNight = {image:'photos/moiwa.jpg', alt:'藻岩山山頂面向札幌市區的夜景', photoSource:'https://commons.wikimedia.org/wiki/File:City_nightscape_of_Sapporo_from_Mt._Moiwa_20260703a.jpg', photoCredit:'掬茶 · CC BY-SA 4.0 · 網頁裁切', photoLicense:'https://creativecommons.org/licenses/by-sa/4.0/'};
  const towerNight = {image:'photos/d3-sapporo-tv-tower.webp', alt:'大通公園側所見的札幌電視塔', photoSource:'https://commons.wikimedia.org/wiki/File:Sapporo_TV_Tower_at_night_20250725.jpg', photoCredit:'掬茶 · CC BY-SA 4.0 · 縮放轉 WebP', photoLicense:'https://creativecommons.org/licenses/by-sa/4.0/'};
  const seaAnimals = {image:'photos/d5-otaru-aquarium.webp', alt:'小樽水族館海獸公園與海岸', photoSource:'https://commons.wikimedia.org/wiki/File:Otaru_aquarium_(Kaiju_koen).JPG', photoCredit:'星組背番号10 · CC BY-SA 3.0 · 縮放轉 WebP', photoLicense:'https://creativecommons.org/licenses/by-sa/3.0/'};
  const usuLake = {image:'photos/d6-usuzan.jpg', alt:'從有珠山纜車上辨認洞爺湖方向', photoSource:'https://commons.wikimedia.org/wiki/File:The_View_from_Usuzan_Ropeway.jpg', photoCredit:'Miyuki Meinaka · Public domain · 網頁裁切'};

  window.folioGuideNotes = {
    '新千歲機場國內線': [
      note('國際線由 2F 聯絡通道走', '照片是國際線航廈大廳。入境後循「国内線」標示走 2F 聯絡通道，3F 跨航廈通道施工封閉。', airportWorks, photo('cts-international-arrival', '新千歲機場國際線航廈大廳與頭頂方向標示')),
      note('抵達國內線後找集合點', '國內線 1F 抵達大廳設有 JR 電子看板。到航廈公共區後前往約定的集合點，再上樓吃飯。', terminal, photo('cts-domestic-arrivals', '新千歲機場國內線 1F 抵達大廳的 JR 出發電子看板')),
      note('上國內線 2F 公共商店區', '循「SHOPPING WORLD」到 2F 公共商店區，找「かま栄」櫃檯。買完魚板再往 3F 美食區。', fish, photo('cts-shopping', '新千歲機場國內線 2F 公共商店區入口與 SHOPPING WORLD 招牌'))
    ],
    'かま栄': [
      note('從國內線抵達大廳上樓', '集合後由國內線 1F 上到 2F。照片中的 JR 電子看板在 1F 抵達大廳，可用來認出這一層。', terminal, photo('cts-domestic-arrivals', '新千歲機場國內線抵達大廳的電子看板')),
      note('到 2F 公共商店區找「かま栄」', '照片為「SHOPPING WORLD」入口。進入公共商店區後認「かま栄」店牌，櫃檯可點「パンロール」。店面照片可從官方店頁查看。', fish, photo('cts-shopping', '新千歲機場國內線公共商店區入口')),
      note('離店上 3F，找豚丼名人', '從 2F 往上一層，找照片中的「Gourmet World」入口。豚丼名人在 3F 的安檢外美食區。', pork, photo('cts-gourmet', '新千歲機場國內線 3F Gourmet World 美食區入口'))
    ],
    '豚丼名人': [
      note('上 3F 後認 Gourmet World 招牌', '從國內線 2F 上樓後找「Gourmet World」入口，再核對「豚丼名人」店牌。官方店頁有門面照與樓層位置。', pork, photo('cts-gourmet', '新千歲機場國內線 3F 美食區 Gourmet World 入口')),
      note('吃完回到國內線 2F', '照片是 2F 公共商店區。下到這一層後找「センタープラザ」，再跟「JR線」指示走向 B1F。', rail, photo('cts-shopping', '新千歲機場國內線 2F 公共商店區')),
      note('到 B1F 進新千歲空港駅', '看見「JR 新千歳空港駅」招牌即到車站剪票口。進站前看班次與月台。', rail, photo('cts-jr-gate', '新千歲空港駅剪票口與上方 JR 車站招牌'))
    ],
    'JR 新千歲機場站': [
      note('由中央廣場沿 JR 標示下到 B1F', '由 2F「センタープラザ」依「JR線」標示到 B1F。照片是車站前通道；機場官網有走電扶梯與電梯兩種實走影片。', rail, photo('cts-jr-concourse', 'B1F 新千歲空港駅站前通道與方向指示')),
      note('看出發看板，再刷卡或持票進站', '看見「JR 新千歳空港駅」就是剪票口。進站前看往札幌的「快速エアポート」、發車時間與月台。', rail, photo('cts-jr-gate', 'B1F 新千歲空港駅剪票口')),
      note('到月台核對車廂與行車方向', '照片中的數字與電子看板可用來辨認月台。持指定席票的話再核對車廂號，抵達札幌後可轉地下鐵。', rail, photo('cts-jr-platform', '新千歲空港駅月台、電子看板與列車'))
    ],
    '定山源泉公園': [
      note('找有木牌的公園入口', '沿溫泉街找月見橋附近的「定山源泉公園」。認照片中的入口木牌，從門下走入園內的紅色步道。', park, photo('jozankei-135-06', '定山源泉公園木牌入口與內側紅色步道')),
      note('進公園找有屋頂的足湯', '晚餐後到公園，可以辨認照片中有木柱與屋頂的足湯區。足湯免費，開放時間為 07:00–21:00。', park, photo('jozankei-135-12', '定山源泉公園入夜後亮燈的木造足湯亭')),
      note('園內可接著看溫泉蛋池', '看到用石材圍起的方形熱泉池，就到「おんたまの湯」。若要另外走二見吊橋，請回溫泉街依施工告示繞道。', egg, photo('jozankei-135-09', '定山源泉公園內的方形溫泉蛋池與網袋'))
    ],
    '溫泉蛋之泉': [
      note('先從木牌入口進入源泉公園', '從溫泉街走向月見橋旁的定山源泉公園。認照片中入口木牌，溫泉蛋池在園內。', park, photo('jozankei-135-06', '寫著定山源泉公園的入口木牌')),
      note('找方形的「おんたまの湯」', '圖中是溫泉蛋池。官方建議以網袋放入雞蛋，約 20 分鐘取出，入池前先看現場說明。', egg, photo('jozankei-135-09', '溫泉蛋之泉方形池內正浸著網袋裝雞蛋')),
      note('取蛋後可回足湯亭', '若要煮蛋，先確認附近店家是否仍可購買雞蛋與網袋。取蛋後可以從園內步道回到圖中的足湯亭。', egg, photo('jozankei-135-02', '定山源泉公園內的足湯亭與相鄰步道'))
    ],
    '二見吊橋': [
      note('從河谷找紅色吊橋方向', '二見公園施工封閉。認豐平川上的紅色吊橋方向，再從公廁附近找「歩行者用迂回路」指標，依圍欄和臨時階梯前往。', bridgeNotice, photo('jozankei-137-10', '從河谷遠望樹林中的二見吊橋')),
      note('抵達紅欄杆橋頭先看告示', '照片是在二見吊橋橋面往前看的視角。到橋頭先看當天通行告示，遇封閉就從可通行處折返。', bridgeNotice, photo('jozankei-137-13', '二見吊橋上的紅色欄杆與橋面')),
      note('沿行人繞道原路返回', '看完橋景沿行人繞道原路返回。官方公告載明吊橋與步道自 2026/11/16 起封閉，預計 2027 年春季融雪後開放。', bridgeNotice, photo('jozankei-137-09', '從豐平川上看見紅色二見吊橋全貌'))
    ],
    'JR 札幌站': [
      note('認札幌站南側的主站房', '從站前廣場找「札幌駅」及 JR 塔。要進站搭車時，循 JR 北海道的構內圖和現場標示到開放的剪票口。', station, photo('sapporo-station-exterior', 'JR 札幌站南口主站房及右側 JR 塔')),
      note('站內依改道標示走', '照片記錄施工期間站內的臨時通道。下車後看當天指標；若轉乘地鐵，找「地下鉄 南北線」並搭往真駒內方向。', station, photo('sapporo-station-corridor', '札幌站工程期間設有綠色圍欄的站內臨時通道')),
      note('確認北口和南口方向', '照片為札幌站北口側。往北大或北側目的地時可從北口走；往住宿轉地鐵時，先依站內「地下鉄」標示找南北線。', station, photo('sapporo-station-north', '從街道看向 JR 札幌站的北口側與站房'))
    ],
    '中島公園站': [
      note('在南北線中島公園下車', '從札幌站方向過來時搭往真駒內的列車，在「中島公園 N09」下車。要走公園側的 3 號出口，就跟月台指標往南剪票口。', subway, photo('nakajima-platform', '中島公園站地下月台與月台門')),
      note('穿過南剪票口往 3 號出口', '照片中的綠色看板是「南改札口」。刷卡出站後，看上方「出口 3」標示往公園方向走。', subway, photo('nakajima-south-gate', '中島公園站南剪票口與上方綠色指示牌')),
      note('從玻璃站亭走到公園側', '看見玻璃外牆與「3」標記就到公園側出口。白天可穿越公園到 Premier；夜間或冬季，飯店建議從 1 號出口走街側。', hotel, {...photo('nakajima-exit-3', '中島公園站 3 號出口的玻璃站亭，2025 年拍攝'), position:[43.0478092,141.3551057], target:'Premier 中島公園'})
    ],
    'Premier 中島公園': [
      note('由中島公園站前往飯店', '照片是公園側的 3 號出口。日間可走這裡穿過公園。若天色已暗或遇到冬季路況，按飯店建議從 1 號出口走街側。', hotel, {...photo('nakajima-exit-3', '前往 Premier 的日間路線從中島公園站 3 號出口開始'), position:[43.0478092,141.3551057], target:'Premier 中島公園'}),
      note('由公園辨認飯店大樓', '照片中的高樓現為 Premier，拍攝時使用 Novotel 舊名。循飯店交通圖走到街側正門，要寄放行李時到櫃檯辦理。', hotel, photo('premier-park-view', '從中島公園看向現為 Premier 的飯店大樓')),
      note('回程走中島公園站剪票口', '離開飯店後可步行回中島公園站。照片是公園側 3 號出口通往的南剪票口，依當天路線選擇出口與月台。', subway, photo('nakajima-south-gate', '中島公園站南剪票口'))
    ],
    '薄野站': [
      note('到南北線薄野月台', '從中島公園站往麻生方向搭一站，在「すすきの N08」下車。', subway, photo('susukino-platform', '南北線薄野站月台與方向看板')),
      note('依目的地選出站方向', '照片為薄野站剪票口。要轉地面巴士或市電時，先看各自的轉乘指標與出口圖。', subway, photo('susukino-gates', '札幌地下鐵薄野站剪票口')),
      note('看地面站牌確認所在路口', '照片是薄野站 4 號出入口。到地面先確認路口方位，再依行程地圖走往目的地。', subway, photo('susukino-exit-4', '薄野站 4 號出入口，2025 年拍攝'))
    ],
    '大通站': [
      note('在大通站下車', '從東札幌回大通時，搭東西線往宮之澤方向，在「大通」下車。照片是大通站其中一處月台。', subway, photo('odori-concourse', '札幌大通站地下月台與列車')),
      note('找大通站地下通道指標', '大通站有三條地鐵線與地下街通道。要去電視塔，先找「オーロラタウン」與 27 號出口方向。', tvAccess, photo('odori-platform', '大通站地下公共通道與指示牌')),
      note('離開剪票區走往目的出口', '照片是大通站剪票口。刷卡出站後循出口牌走到需要的出口，電視塔在 27 號出口旁。', tvAccess, photo('odori-gates', '札幌大通站的剪票口'))
    ],
    '東札幌站': [
      note('從東西線東札幌月台下車', '往札幌會議中心時，在「東札幌 T12」下車。沿月台方向牌找出站通道。', subway, photo('higashisapporo-platform', '東札幌站東西線月台')),
      note('刷卡出站後先看出口圖', '從照片所示剪票口離開後，依會議中心官方步行圖確認出口方向。', convention, photo('higashisapporo-gates', '東札幌站的剪票口')),
      note('出站朝 SORA 會議中心步行', '照片是東札幌站的 1 號出入口。到地面後依會場官網步行圖走，車站到會場約 10 分鐘。', convention, photo('higashisapporo-entrance', '東札幌站 1 號出入口在路旁的站亭'))
    ],
    '圓山公園站': [
      note('在東西線「円山公園」下車', '從大通搭東西線往宮之澤方向，到「円山公園 T06」下車。', subway, photo('maruyama-platform', '圓山公園站 1 號月台，2026 年拍攝')),
      note('穿過圓山公園站剪票口', '循「出口」指標到剪票口。出站後看站內圖選公園側出口。', subway, photo('maruyama-gates', '圓山公園站地下剪票口')),
      note('出站往圓山公園與神宮', '照片是 3 號出口。到地面後依行程地圖走進圓山公園，北海道神宮距車站約 15 分鐘。', 'https://www.hokkaidojingu.or.jp/china/access/index.html', photo('maruyama-exit-3', '圓山公園站 3 號出入口，2026 年拍攝'))
    ],
    'JR 小樽站': [
      note('辨認 JR 小樽站站房', '從市區回站時，找寫有「小樽駅」的站房。前往三角市場或轉巴士時，都先由主站口確認方向。', jrStations, photo('otaru-station-front', 'JR 小樽站正門與站前廣場')),
      note('在剪票口前確認札幌班次', '回程看當天電子看板，再刷卡或持票進站。從札幌抵達時，由同一剪票區出站。', jrStations, photo('otaru-station-gates', 'JR 小樽站剪票口，2026 年拍攝')),
      note('到月台核對車種與目的地', '照片是小樽站 4、5 號月台。實際搭車月台以電子看板為準，回札幌需確認車頭行先。', jrStations, photo('otaru-station-platform', 'JR 小樽站 4 與 5 號月台'))
    ],
    'JR 洞爺站': [
      note('在洞爺站下車', '特急抵達時核對「洞爺」站名。下車循出口指標，依現場引導到站房。', jrStations, photo('toya-station-platform', 'JR 洞爺站月台')),
      note('經剪票口出站', '照片為洞爺站剪票口。出站往站前廣場，再依行程選擇步行去虻田神社或轉乘道南巴士。', jrStations, photo('toya-station-gates', 'JR 洞爺站剪票口與候車區')),
      note('從站房認站前集合方向', '照片是洞爺站站房。回程先從站前廣場進站，再依電子看板核對特急北斗的班次與月台。', jrStations, photo('toya-station-front', 'JR 洞爺站正面站房與門口'))
    ],
    'Kappa Liner 薄野站': [
      note('到薄野後先核對巴士站牌', '在客運公司乘車處圖找「すすきの」與定山溪方向。到現場再核對站牌上的「かっぱライナー号」。', kappa),
      note('依預約班次上車', 'Kappa Liner 採預約制，座位自由入座。上車前把預約班次與目的地下車站準備好。', kappa),
      note('往定山溪在白絲瀑布下車', '聽到「白糸の滝」時準備下車。到站後再照行程地圖走往住宿點。', kappa)
    ],
    '白絲瀑布站・札幌方向': [
      note('先辨認站柱 2', '白絲瀑布站分兩側。看站牌「標柱2」及「札幌駅・真駒内駅方面」，確認在往札幌側候車。', shiraito),
      note('確認是預約的 Kappa Liner', '同一站也有其他路線。車到後先核對車頭的「かっぱライナー号」以及預約班次。', kappa),
      note('在札幌市區按行程下車', '依預約目的站下車。若接札幌站周邊行程，抵達後再走往寄物點及赤磚露台。', kappa)
    ],
    '榆樹之森遊客中心': [
      note('走北八條西五丁目的北大正門', '從札幌站步行到北海道大學正門。進正門後立即往左，找「エルムの森」。', 'https://www.hokudai.ac.jp/pr/shops/elm.html'),
      note('取一份校園導覽地圖', '遊客中心有校園地圖，可先確認中央草坪與綜合博物館，之後沿校園中央道路走。', campus),
      note('從正門區往中央草坪', '離開遊客中心後返回正門的校園步道，沿導覽圖前往中央草坪，再續走博物館方向。', campus)
    ],
    '山麓站': [
      note('市電到ロープウェイ入口', '在市電「ロープウェイ入口」下車後，步行約一分鐘到免費接駁乘車處。', moiwaShuttle),
      note('轉接駁到山麓站', '免費接駁一般每 15 分鐘一班。也可由接駁乘車處步行約 500 公尺。到站認「山麓駅」，照片為更新前的車站標牌。', moiwaShuttle, photo('moiwa-base-station', '藻岩山纜車山麓站舊站名標牌')),
      note('在山麓站搭第一段纜車', '進站後看售票與乘車指標。圖中的空中纜車由山麓到中腹站，往山頂在中腹站另轉迷你纜車。', moiwa, photo('moiwa-cableway', '藻岩山往中腹的空中纜車車廂'))
    ],
    '中腹站': [
      note('從山麓搭空中纜車到中腹', '照片中能看見藻岩山第一段空中纜車。這段到中腹站結束，下車後先找山頂方向。', moiwa, photo('moiwa-cableway', '藻岩山纜車車廂與山麓市區')),
      note('認中腹站建物，再找轉乘標示', '中腹站外觀為弧形站房。抵達後跟「ミニケーブルカー」標示轉乘到山頂，留意回程時間。', moiwa, photo('moiwa-mid-station', '藻岩山中腹站弧形站房外觀')),
      note('下山經中腹轉空中纜車', '從山頂搭迷你纜車回到中腹，再改搭空中纜車返回山麓。圖為空中纜車路段面向市區的方向。', moiwa, photo('moiwa-gondola', '藻岩山空中纜車路線朝札幌市區的視角'))
    ],
    '山頂展望台': [
      note('由中腹站搭迷你纜車上山頂', '照片中的中腹站是兩段纜車的轉乘點。換乘迷你纜車抵達山頂站後，依「展望台」指標上樓。', moiwa, photo('moiwa-mid-station', '前往山頂展望台時轉乘的藻岩山中腹站')),
      note('到屋頂展望台看札幌市區', '夜景照片是山頂面向札幌市區的視角。抵達後可由展望台環視，依現場指標避開限制通行區。', moiwa, moiwaNight),
      note('原路經中腹站下山', '下山先搭迷你纜車回中腹，再搭圖中的空中纜車到山麓。抵達山麓後可轉免費接駁回市電站。', moiwaShuttle, photo('moiwa-cableway', '藻岩山連接中腹與山麓的空中纜車'))
    ],
    '札幌會議中心': [
      note('搭東西線到東札幌站', '從巴士中心前站搭往新札幌方向，在東札幌下車。照片是 1 號出入口，離站後對照會場交通圖走。', convention, photo('higashisapporo-entrance', '札幌會議中心附近的東札幌站 1 號出入口')),
      note('照會場交通圖步行約 10 分鐘', '沿官網步行圖前往。認照片中的玻璃大廳與圓弧形會議棟，確認到了札幌會議中心。', convention, photo('sapporo-convention-approach', '從街道接近札幌會議中心時所見的玻璃大廳與圓弧會議棟')),
      note('入內依大會標示找報到處', '走向玻璃大廳入口。進會議中心後依 JCMI 當天現場指引找報到和會場。', 'https://jcmi46.org/outline.html', photo('sapporo-convention-center', '札幌會議中心正面建物與大廳'))
    ],
    '札幌電視塔': [
      note('從地下街走電視塔方向', '在大通站循「オーロラタウン」和 27 號出口指標。照片為電視塔地下商店區，可辨認電視塔地下層。', tvAccess, photo('tv-tower-basement', '札幌電視塔地下商店區與圓形陳列區')),
      note('認公園東端的電視塔入口', '照片中的塔位於大通公園東端。想看外部點燈可先留在公園側，再走向塔的 1F 入口。', tvAccess, towerNight),
      note('到 3F 購票再轉直達電梯', '展望台入場券在 3F 售票。搭直達電梯上樓後，抵達照片中的玻璃窗展望區。', tvTicket, photo('tv-tower-deck', '札幌電視塔室內玻璃窗展望區'))
    ],
    '小樽站前 3 號月台': [
      note('從 JR 小樽站出站到站前巴士總站', '到站前廣場後，找「小樽駅前バスターミナル」與「3番のりば」。', aquariumAccess),
      note('搭行程指定的 10 號往水族館', '同一月台有兩條水族館路線。行程去程搭高島經由的 10 號，先核對車頭行先。', aquariumBus),
      note('在水族館終點站下車', '巴士抵達「おたる水族館」後下車，再依館方入口標示往售票處。', aquariumAccess)
    ],
    '水族館巴士站': [
      note('下車後朝水族館入口走', '從站牌辨認「おたる水族館」，沿館方指標往入口。出發前可先核對返程站牌與班次。', aquariumAccess),
      note('回程留時間下坡到站牌', '若從祝津展望台回來，依行程步行路線下坡，回到水族館巴士站再候車。', aquariumAccess),
      note('看清 11 號經赤岩回小樽站', '行程回程搭 11 號祝津線。核對站牌的「赤岩経由／小樽駅前」後上車。', aquariumBus)
    ],
    '小樽水族館': [
      note('先從入口到本館', '從水族館巴士站走到售票入口。入館後確認當天表演時刻與海獸公園的開放區域。', aquariumAccess),
      note('沿坡道到海獸公園', '海獸公園在海岸邊，由本館方向往下走。照片是抵達海邊區域後的視角，回程上坡要留時間。', aquariumFaq, seaAnimals),
      note('回本館二樓前往海豚劇場', '海豚劇場可從本館 2F 進入。從海獸公園返回時，預留上坡與找座位的時間。', aquariumFaq)
    ],
    '有珠山纜車山麓站': [
      note('昭和新山下車後找纜車站', '道南巴士到「昭和新山」後，依「有珠山ロープウェイ」標示走往山麓站。照片為山麓站建物的較早記錄。', usuBus, photo('usu-base-station', '有珠山纜車山麓站的站房與入口')),
      note('在山麓站購票搭上行纜車', '購票後確認下一班上行與回程安排。搭圖中的有珠山纜車到山頂站，再從山頂站步行前往展望台。', usu, photo('usu-ropeway-gondola', '沿山坡行駛的有珠山纜車車廂')),
      note('下山後走回昭和新山巴士站', '搭纜車回到山麓站後，原路走回昭和新山站牌。行程回程搭往洞爺湖溫泉的巴士。', 'https://www.donanbus.co.jp/map/toyako_syowashinzan2/', photo('usu-toya-viewpoint', '有珠山纜車車廂及朝山麓方向的視野'))
    ],
    '有珠山纜車山頂站': [
      note('抵達山頂站先看分岔指標', '照片為有珠山纜車山頂站。下車後先找洞爺湖展望台和 USU360 的方向，兩個展望台要走不同方向。', usuTrail, photo('usu-summit-station', '有珠山纜車山頂站的外牆及站名標牌')),
      note('出站往右找洞爺湖展望台', '出山頂站後向右，找「洞爺湖展望台／Mt.USU Terrace」。照片從纜車上拍攝，可先辨認洞爺湖的方向。', 'https://usuzan.hokkaido.jp/archives/blog/19634', usuLake),
      note('觀景結束回站搭下行纜車', '走完展望台後回到山頂站，搭圖中的纜車回山麓。接道南巴士前，預留搭車和走到站牌的時間。', usu, photo('usu-toya-viewpoint', '有珠山纜車車廂及山區景象'))
    ],
    '洞爺湖展望台': [
      note('山頂站出來往右走', '認「洞爺湖展望台／Mt.USU Terrace」標示，從山頂站往右走到湖景側。', 'https://usuzan.hokkaido.jp/archives/blog/19634'),
      note('辨認湖與昭和新山的方向', '停在展望台看洞爺湖及昭和新山。照片從纜車上拍攝，可先辨認湖景側的地形。', usu, usuLake),
      note('回山頂站再決定是否續走', '從展望台折回山頂站。若續走 USU360，再沿火口原展望台的指示往另一側。', usuTrail)
    ],
    '火口原展望台': [
      note('從山頂站找 USU360 指標', 'USU360 位在火口原展望台。出山頂站後走火口側的路線，依展望台指標上階梯。', usuCrater),
      note('到露台後在開放區觀景', '抵達露台後可看火口和太平洋方向。依現場告示停留在展望台及開放步道。', usuTrail),
      note('沿原路回山頂站', '看完回到山頂站搭下行纜車。若安排接 13:15 的巴士，預留搭纜車及步行到昭和新山站牌的時間。', usu)
    ]
  };
  window.folioGuideNotes['新千歲機場'] = window.folioGuideNotes['新千歲機場國內線'];
  window.folioGuideNotes['札幌站'] = window.folioGuideNotes['JR 札幌站'];
  window.folioGuideNotes['白絲瀑布站'] = window.folioGuideNotes['白絲瀑布站・札幌方向'];
})();
